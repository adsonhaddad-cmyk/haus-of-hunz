import { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  CheckSquare,
  Crown,
  Home,
  LayoutDashboard,
  LogOut,
  ShoppingCart,
  Sparkles,
  Wifi,
  WifiOff,
  X,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { AuthGate } from './components/AuthGate';
import { Avatar } from './components/Avatar';
import { DashboardView } from './components/DashboardView';
import { HouseView } from './components/HouseView';
import { LeaderboardView } from './components/LeaderboardView';
import { ShoppingView } from './components/ShoppingView';
import { TasksView } from './components/TasksView';
import { ToastContainer } from './components/ToastContainer';
import { SiliconeButton } from './components/ui/ClayPrimitives';
import { HausWordmark } from './components/ui/HausWordmark';
import { Mascot } from './components/ui/Mascots';
import {
  IOSInstallModal,
  OfflineBanner,
  UpdateAvailableBanner,
} from './components/ui/PWAComponents';
import { useHouseStore } from './hooks/useHouseStore';
import { usePWA } from './hooks/usePWA';
import { TabKey } from './types/household';

interface NavItem {
  key: TabKey;
  labelKey: string;
  icon: typeof LayoutDashboard;
}

const NAV_ITEMS: NavItem[] = [
  { key: 'dashboard', labelKey: 'nav.home', icon: LayoutDashboard },
  { key: 'tasks', labelKey: 'nav.chores', icon: CheckSquare },
  { key: 'shopping', labelKey: 'nav.shopping', icon: ShoppingCart },
  { key: 'leaderboard', labelKey: 'nav.leaderboard', icon: Crown },
  { key: 'house', labelKey: 'nav.ourHouse', icon: Home },
];

export default function App() {
  const { t, i18n } = useTranslation();
  const [activeTab, setActiveTab] = useState<TabKey>('dashboard');
  const [iosModalOpen, setIosModalOpen] = useState(false);

  const pwa = usePWA();
  const store = useHouseStore();

  if (store.isInitializing && !store.state) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 gap-5 text-center">
        <Mascot id="miss-mop" mood="proud" size="lg" />
        <HausWordmark
          variant="splash"
          tone="dark"
          showCrest={false}
          showTagline
          tagline={t('common.tagline')}
        />
        <p className="text-sm font-medium text-[#7965A5]">
          {t('common.loading')}
        </p>
      </div>
    );
  }

  if (store.needsOnboarding || !store.authUser || !store.state || !store.activeResident) {
    return (
      <>
        <AuthGate
          firebaseUser={store.firebaseUser}
          needsOnboarding={store.needsOnboarding}
          defaultInviteExists={store.defaultInviteExists}
          isMutating={store.isMutating}
          authError={store.authError}
          onSignInWithGoogle={store.signInWithGoogle}
          onLaunchHouse={store.launchHouse}
          onJoinHouse={store.joinHouseWithInvite}
          onLogout={store.logout}
          onChangeLanguage={store.changeLanguage}
        />
        <ToastContainer toasts={store.toasts} onDismiss={store.dismissToast} />
      </>
    );
  }

  const { state, activeResident } = store;

  const myPendingTaskCount = state.tasks.filter(
    (task) =>
      task.status === 'pending' && task.assignedToId === activeResident.id
  ).length;

  const pendingShoppingCount = state.shoppingItems.filter(
    (item) => item.status === 'pending'
  ).length;

  const unreadNotifCount = state.notifications.filter(
    (n) => n.recipientId === activeResident.id && !n.readAt
  ).length;

  return (
    <div className="min-h-screen text-[#38216B]">
      {/* Desktop Pastel Glass Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:fixed lg:inset-y-4 lg:left-4 lg:w-64 surface-glass rounded-[32px] z-30 overflow-hidden">
        <div className="px-6 pt-6 pb-5 border-b border-white/60">
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            aria-label={`${t('common.brandName')} — ${t('nav.home')}`}
            className="text-left block w-full focus:outline-none focus-visible:ring-2 focus-visible:ring-[#9672E8] rounded-xl"
          >
            <HausWordmark variant="sidebar" tone="dark" />
            {state.houseName && state.houseName !== 'HAUS OF HUNZ' && (
              <span className="text-xs text-[#7965A5] mt-1.5 block truncate">
                {state.houseName}
              </span>
            )}
          </button>

          <div className="mt-3 flex items-center gap-1.5 text-[11px] font-semibold text-[#7965A5]">
            {store.runtimeStatus.wsConnected ? (
              <>
                <Wifi className="w-3.5 h-3.5 text-[#1C7C54]" />
                <span className="text-[#1C7C54]">{t('common.online')}</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3.5 h-3.5 text-[#B33981]" />
                <span>{t('common.offline')}</span>
              </>
            )}
          </div>
        </div>

        <nav
          aria-label={t('nav.mainNavLabel')}
          className="flex-1 px-3.5 py-5 space-y-1.5"
        >
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.key;
            const count =
              item.key === 'tasks'
                ? myPendingTaskCount
                : item.key === 'shopping'
                  ? pendingShoppingCount
                  : item.key === 'dashboard'
                    ? unreadNotifCount
                    : 0;

            return (
              <button
                key={item.key}
                type="button"
                onClick={() => setActiveTab(item.key)}
                className={`w-full min-h-[46px] px-4 py-2.5 rounded-2xl text-sm font-semibold flex items-center justify-between transition-all whitespace-nowrap ${
                  isActive
                    ? 'btn-3d-lavender'
                    : 'text-[#38216B]/80 hover:bg-white/55 hover:text-[#4C269A]'
                }`}
              >
                <span className="flex items-center gap-3">
                  <Icon
                    className={`w-4.5 h-4.5 ${
                      isActive ? 'text-[#FFF8FF]' : 'text-[#7965A5]'
                    }`}
                  />
                  {t(item.labelKey)}
                </span>
                {count > 0 && (
                  <span
                    className={`font-mono-num text-xs font-semibold ${
                      isActive ? 'text-[#FFE7F5]' : 'text-[#7965A5]'
                    }`}
                  >
                    {count}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Signed-In Resident Footer (No simulated switcher) */}
        <div className="p-4 border-t border-white/60 bg-white/25 space-y-3">
          <p className="text-[11px] font-semibold text-[#7965A5] px-1">
            {t('nav.signedInAs')}
          </p>
          <div className="flex items-center justify-between gap-2 px-1">
            <div className="flex items-center gap-2.5 min-w-0">
              <Avatar
                resident={activeResident}
                size="sm"
                showOnlineDot={store.onlineResidentIds.includes(
                  activeResident.id
                )}
              />
              <div className="min-w-0">
                <p className="text-sm font-bold text-[#4C269A] truncate">
                  {activeResident.name}
                </p>
                <p className="font-mono-num text-[11px] font-semibold text-[#7965A5]">
                  {activeResident.points} {t('common.pts')}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => void store.logout()}
              aria-label={t('nav.signOut')}
              title={t('nav.signOut')}
              className="btn-3d-cloud min-h-[38px] min-w-[38px] rounded-xl inline-flex items-center justify-center text-[#7965A5] hover:text-[#B33981]"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Minimalist Header */}
      {activeTab !== 'dashboard' && (
        <header className="lg:hidden sticky top-0 z-30 h-14 px-4 flex items-center justify-between gap-3 bg-[#E6DCF9]/85 backdrop-blur-md border-b border-white/50">
          <button
            type="button"
            onClick={() => setActiveTab('dashboard')}
            aria-label={`${t('common.brandName')} — ${t('nav.home')}`}
            className="shrink-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-[#9672E8] rounded-xl"
          >
            <HausWordmark variant="compact" tone="dark" />
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('house')}
              className="btn-3d-cloud min-h-[40px] px-2.5 py-1 rounded-full flex items-center gap-2 shrink-0"
            >
              <Avatar
                resident={activeResident}
                size="xs"
                showOnlineDot={store.onlineResidentIds.includes(
                  activeResident.id
                )}
              />
              <span className="text-xs font-semibold text-[#38216B] whitespace-nowrap pr-0.5">
                {activeResident.name}
              </span>
            </button>
            <button
              type="button"
              onClick={() => void store.logout()}
              aria-label={t('nav.signOut')}
              className="btn-3d-cloud min-h-[40px] min-w-[40px] rounded-full inline-flex items-center justify-center text-[#7965A5]"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </header>
      )}

      {/* Main Content Area */}
      <main className="lg:pl-72 pb-28 lg:pb-12">
        <OfflineBanner visible={!pwa.isOnline || !store.runtimeStatus.online} />
        <UpdateAvailableBanner
          visible={pwa.needRefresh}
          onRefresh={() => void pwa.applyUpdate()}
        />

        <div className="max-w-6xl mx-auto px-3.5 sm:px-6 lg:px-8 py-4 sm:py-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={`${activeTab}-${i18n.language}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.16, ease: [0.16, 1, 0.3, 1] }}
            >
              {activeTab === 'dashboard' && (
                <DashboardView
                  state={state}
                  activeResident={activeResident}
                  onlineResidentIds={store.onlineResidentIds}
                  onCompleteTask={store.completeTask}
                  onSendPoke={store.sendPoke}
                  onRespondSwap={store.respondSwap}
                  onAddPinNote={store.addPinNote}
                  onUpdatePinNote={store.updatePinNote}
                  onTogglePinNote={store.togglePinNote}
                  onDeletePinNote={store.deletePinNote}
                  onMarkAllNotificationsRead={store.markAllNotificationsRead}
                  onNavigate={setActiveTab}
                />
              )}

              {activeTab === 'tasks' && (
                <TasksView
                  state={state}
                  activeResident={activeResident}
                  onlineResidentIds={store.onlineResidentIds}
                  onCompleteTask={store.completeTask}
                  onAddTask={store.addTask}
                  onUpdateTask={store.updateTask}
                  onPauseTask={store.pauseTask}
                  onResumeTask={store.resumeTask}
                  onSendPoke={store.sendPoke}
                  onProposeSwap={store.proposeSwap}
                  onDeleteTask={store.deleteTask}
                />
              )}

              {activeTab === 'shopping' && (
                <ShoppingView
                  state={state}
                  onAddShoppingItem={store.addShoppingItem}
                  onUpdateShoppingItem={store.updateShoppingItem}
                  onMarkBought={store.markShoppingBought}
                  onRestoreShoppingItem={store.restoreShoppingItem}
                  onDeleteShoppingItem={store.deleteShoppingItem}
                />
              )}

              {activeTab === 'leaderboard' && (
                <LeaderboardView
                  state={state}
                  activeResident={activeResident}
                  onlineResidentIds={store.onlineResidentIds}
                />
              )}

              {activeTab === 'house' && (
                <HouseView
                  key={`${activeResident.id}-${state.lastSyncedAt}`}
                  state={state}
                  activeResident={activeResident}
                  inviteCode={store.inviteCode}
                  onlineResidentIds={store.onlineResidentIds}
                  runtimeStatus={store.runtimeStatus}
                  legacyBackup={store.legacyBackup}
                  getLegacyFinanceBackupJson={store.getLegacyFinanceBackupJson}
                  isInstallable={pwa.isInstallable}
                  isInstalled={pwa.isInstalled}
                  isIOS={pwa.isIOS}
                  onPromptInstall={pwa.promptInstall}
                  onOpenIOSGuide={() => setIosModalOpen(true)}
                  onSubscribePush={store.subscribePush}
                  onUnsubscribePush={store.unsubscribePush}
                  onSendTestPush={store.sendTestPush}
                  onUpdateMyProfile={store.updateMyProfile}
                  onUpdateHouseSettings={store.updateHouseSettings}
                  onChangeLanguage={store.changeLanguage}
                  isHouseOwner={store.isHouseOwner}
                  userEmail={store.firebaseUser?.email || ''}
                  onResetDemo={store.resetDemoData}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Mobile Floating Capsule Bottom Navigation */}
      <nav
        aria-label={t('nav.bottomNavLabel')}
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 px-3 pb-safe pointer-events-none"
      >
        <div className="max-w-md mx-auto nav-capsule rounded-[32px] px-2 py-1.5 grid grid-cols-5 items-center pointer-events-auto">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => setActiveTab(item.key)}
                aria-current={isActive ? 'page' : undefined}
                className="min-h-[48px] flex flex-col items-center justify-center gap-0.5 rounded-[24px] transition-all relative"
              >
                <span
                  className={`w-9 h-9 rounded-full inline-flex items-center justify-center transition-all ${
                    isActive
                      ? 'bg-[#FFF8FF] text-[#4C269A] shadow-[0_6px_14px_-2px_rgba(56,33,107,0.38),inset_0_1.5px_2px_rgba(255,255,255,1)] -translate-y-0.5'
                      : 'text-[#FFF8FF]/85 hover:text-white'
                  }`}
                >
                  <Icon
                    className="w-4.5 h-4.5"
                    strokeWidth={isActive ? 2.4 : 1.9}
                  />
                </span>
                <span
                  className={`text-[10px] tracking-tight whitespace-nowrap ${
                    isActive
                      ? 'font-bold text-[#FFF8FF]'
                      : 'font-medium text-[#FFF8FF]/80'
                  }`}
                >
                  {t(item.labelKey)}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Realtime Poke & Shade Spotlight Modal */}
      <AnimatePresence>
        {store.pokeSpotlight && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={store.dismissPokeSpotlight}
              className="fixed inset-0 bg-[#38216B]/50 backdrop-blur-xs"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92 }}
              className="relative z-10 w-full max-w-md surface-clay rounded-[30px] p-6 text-center space-y-4 border border-[#ED82BE]"
            >
              <button
                type="button"
                onClick={store.dismissPokeSpotlight}
                aria-label={t('common.close')}
                className="absolute top-4 right-4 btn-3d-cloud min-h-[38px] min-w-[38px] rounded-full inline-flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="flex justify-center">
                <Mascot id="dusty-drama" mood="shady" size="xl" />
              </div>

              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FCE0F0] text-[#B33981] text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{t('toasts.pokeReceivedTitle')}</span>
              </div>

              <h3 className="font-editorial text-2xl font-bold text-[#38216B]">
                {store.pokeSpotlight.senderName}
              </h3>

              <p className="text-sm text-[#4C269A] leading-relaxed surface-inset rounded-2xl p-4">
                {store.pokeSpotlight.poke.message}
              </p>

              <div className="flex gap-3">
                <SiliconeButton
                  variant="cloud"
                  onClick={store.dismissPokeSpotlight}
                  className="flex-1"
                >
                  {t('common.close')}
                </SiliconeButton>
                <SiliconeButton
                  variant="pink"
                  onClick={() => {
                    store.dismissPokeSpotlight();
                    setActiveTab('tasks');
                  }}
                  className="flex-1"
                >
                  {t('dashboard.viewHousePlan')}
                </SiliconeButton>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <IOSInstallModal
        open={iosModalOpen}
        onClose={() => setIosModalOpen(false)}
      />

      <ToastContainer toasts={store.toasts} onDismiss={store.dismissToast} />
    </div>
  );
}
