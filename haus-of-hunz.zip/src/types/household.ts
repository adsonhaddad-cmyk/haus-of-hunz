export type TabKey =
  | 'dashboard'
  | 'tasks'
  | 'shopping'
  | 'leaderboard'
  | 'house';

export type TaskFrequency =
  | 'once'
  | 'daily'
  | 'weekly'
  | 'biweekly'
  | 'monthly'
  | 'custom';

export type TaskPriority = 'alta' | 'media' | 'normal';

export type TaskCategory =
  | 'Limpeza'
  | 'Cozinha'
  | 'Organização'
  | 'Manutenção'
  | 'Geral';

export type ShadeIntensity =
  | 'soft_serve'
  | 'a_little_shady'
  | 'full_ballroom';

export type SkinTone =
  | 'porcelain'
  | 'peach'
  | 'honey'
  | 'amber'
  | 'chestnut'
  | 'espresso';

export type HairStyle =
  | 'short_fade'
  | 'curly_crown'
  | 'sleek_bob'
  | 'waves'
  | 'buzz'
  | 'updo';

export type FacialHair = 'none' | 'stubble' | 'mustache' | 'beard';

export type ClothingStyle =
  | 'lavender_sweater'
  | 'silk_blazer'
  | 'sequin_top'
  | 'hoodie'
  | 'mesh_chic';

export type AccessoryStyle =
  | 'none'
  | 'cat_eye_shades'
  | 'pearls'
  | 'crown'
  | 'hoops'
  | 'headband';

export type AvatarExpression = 'smile' | 'smirk' | 'wink' | 'gasp' | 'serene';

export interface AvatarConfig {
  skinTone: SkinTone;
  hairStyle: HairStyle;
  facialHair: FacialHair;
  clothing: ClothingStyle;
  accessory: AccessoryStyle;
  expression: AvatarExpression;
  accentColor: string;
  customPhotoUrl?: string;
}

export interface TaskCompletionRecord {
  id: string;
  occurrenceId: string;
  completedById: string;
  completedAt: string;
  basePoints: number;
  penaltyPercent: number;
  penaltyPoints: number;
  pointsAwarded: number;
  wasOverdue: boolean;
  delayMinutes: number;
  occurrenceDate: string;
}

export interface HouseholdTask {
  id: string;
  title: string;
  description?: string;
  category: TaskCategory;
  points: number;
  priority: TaskPriority;
  frequency: TaskFrequency;
  customIntervalDays?: number;
  assignedToId: string;
  participantIds: string[];
  dueDate: string; // YYYY-MM-DD in household timezone
  dueTime: string; // HH:mm in household timezone
  dueAt: string; // Authoritative UTC ISO timestamp
  occurrenceId: string;
  occurrenceSeq: number;
  status: 'pending' | 'completed' | 'paused';
  pausedUntil?: string;
  pausedReason?: string;
  reassignedAt?: string;
  reassignedBeforeDeadline?: boolean;
  history: TaskCompletionRecord[];
  lastCompletedOccurrenceKey?: string;
  createdAt: string;
}

export type ShoppingUnit = 'un' | 'kg' | 'g' | 'L' | 'ml' | 'pct' | 'cx';

export type ShoppingCategory =
  | 'Mercado'
  | 'Limpeza'
  | 'Padaria'
  | 'Hortifruti'
  | 'Casa';

export interface ShoppingItem {
  id: string;
  name: string;
  quantity: number;
  unit: ShoppingUnit;
  category: ShoppingCategory;
  authorId: string;
  status: 'pending' | 'bought';
  buyerId?: string;
  boughtAt?: string;
  createdAt: string;
}

export interface PinNote {
  id: string;
  authorId: string;
  content: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Resident {
  id: string;
  name: string;
  handle: string;
  email: string;
  role: 'icon' | 'partner';
  avatarUrl?: string;
  avatarConfig: AvatarConfig;
  color: string;
  points: number;
  streak: number;
  shadeIntensity: ShadeIntensity;
  muteShadeNotifications: boolean;
  pushEnabled: boolean;
}

export interface PenaltyTier {
  maxDelayMinutes: number; // Infinity represented by 9999999 for JSON serialization
  deductionPercent: number;
}

export interface PenaltySettings {
  enabled: boolean;
  gracePeriodMinutes: number;
  tiers: PenaltyTier[];
  reminderFrequencyHours: number;
  maxPokesPerOccurrence: number;
}

export interface PointTransaction {
  id: string;
  residentId: string;
  taskId: string;
  taskTitle: string;
  occurrenceId: string;
  type: 'completion' | 'penalty' | 'bonus';
  basePoints: number;
  penaltyPercent: number;
  pointsDelta: number;
  penaltyDeducted: number;
  wasOverdue: boolean;
  delayMinutes: number;
  weekKey: string;
  createdAt: string;
}

export interface PokeRecord {
  id: string;
  taskId: string;
  taskTitle: string;
  occurrenceId: string;
  fromResidentId: string;
  toResidentId: string;
  intensity: ShadeIntensity;
  message: string;
  deliveredViaPush: boolean;
  createdAt: string;
}

export interface SwapRequest {
  id: string;
  taskId: string;
  taskTitle: string;
  fromResidentId: string;
  toResidentId: string;
  note?: string;
  status: 'pending' | 'accepted' | 'declined' | 'cancelled';
  createdAt: string;
  respondedAt?: string;
}

export interface InAppNotification {
  id: string;
  recipientId: string;
  senderId?: string;
  type: 'poke' | 'swap' | 'penalty' | 'achievement' | 'system';
  title: string;
  body: string;
  taskId?: string;
  intensity?: ShadeIntensity;
  readAt?: string;
  createdAt: string;
}

export interface HouseActivityLog {
  id: string;
  type: 'task' | 'shopping' | 'poke' | 'swap' | 'penalty' | 'house';
  actorId: string;
  summary: string;
  createdAt: string;
}

export type HouseStyle = 'loft' | 'apartment' | 'garden';

export interface HousePreferences {
  weeklyPointsGoal: number;
  reducedMotionOverride: boolean;
}

export interface HouseholdState {
  version: 3;
  householdId: string;
  houseName: string;
  tagline: string;
  houseStyle: HouseStyle;
  timeZone: string;
  preferences: HousePreferences;
  penaltySettings: PenaltySettings;
  residents: Resident[];
  tasks: HouseholdTask[];
  shoppingItems: ShoppingItem[];
  pinNotes: PinNote[];
  pointLedger: PointTransaction[];
  pokes: PokeRecord[];
  swapRequests: SwapRequest[];
  notifications: InAppNotification[];
  activityLog: HouseActivityLog[];
  lastSyncedAt: string;
}

export interface ToastMessage {
  id: string;
  title: string;
  subtitle?: string;
  pointsBadge?: string;
  tone: 'lavender' | 'pink' | 'neutral';
}

export interface AchievementBadge {
  id: string;
  titleKey: string;
  descKey: string;
  progressKey: string;
  unlocked: boolean;
  progressCurrent: number;
  progressTarget: number;
  iconKey:
    | 'mop'
    | 'crown'
    | 'kitchen'
    | 'exorcist'
    | 'diva'
    | 'untouchable'
    | 'redemption'
    | 'comeback'
    | 'spotless'
    | 'icon';
}

export interface WeeklyStandingsEntry {
  residentId: string;
  earnedPoints: number;
  completedCount: number;
  onTimeCount: number;
  overdueCount: number;
  penaltyPoints: number;
}

export interface WeeklyCeremonySummary {
  weekKey: string;
  winnerId: string | null;
  isTie: boolean;
  standings: WeeklyStandingsEntry[];
  totalCompleted: number;
  totalPenalties: number;
}

export interface AuthUserSummary {
  userId: string;
  residentId: string;
  householdId: string;
  name: string;
  email: string;
  handle: string;
}

export interface BackendRuntimeStatus {
  mode: 'firebase-firestore' | 'express-realtime';
  persistenceLabel: string;
  persistentCloudConfigured: boolean;
  vapidConfigured: boolean;
  wsConnected: boolean;
  online: boolean;
  activeConnections: number;
}
