import type { User as FirebaseUser } from 'firebase/auth';
import {
  collection,
  deleteField,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  Timestamp,
  where,
  writeBatch,
  type DocumentData,
  type FieldValue,
  type Unsubscribe,
} from 'firebase/firestore';
import { createInitialHouseholdState, DEFAULT_HOUSEHOLD_ID } from '../data/seedData';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  AvatarConfig,
  HouseActivityLog,
  HouseholdState,
  HouseholdTask,
  HousePreferences,
  HouseStyle,
  InAppNotification,
  PenaltySettings,
  PinNote,
  PointTransaction,
  PokeRecord,
  Resident,
  ShadeIntensity,
  ShoppingCategory,
  ShoppingItem,
  ShoppingUnit,
  SwapRequest,
  TaskCategory,
  TaskFrequency,
  TaskPriority,
} from '../types/household';
import { computeDueAtIso, getTodayYMD } from '../utils/dates';
import {
  applyTaskCompletion,
  buildShadeMessage,
  checkPokeEligibility,
} from '../utils/gameEngine';

export interface UserLinkDoc {
  uid: string;
  displayName: string;
  householdId: string;
  residentId: string;
}

export interface HouseholdInviteDoc {
  code: string;
  householdId: string;
  createdByUid: string;
}

export interface HouseholdMemberDoc {
  uid: string;
  householdId: string;
  residentId: string;
  role: 'owner' | 'partner';
  inviteCode?: string;
  memberUids: string[];
  joinedAt: string;
}

export interface HouseholdRealtimeMeta {
  householdOwnerUid: string;
  inviteCode: string;
  memberUids: string[];
  members: HouseholdMemberDoc[];
}

function clampString(val: unknown, maxLen: number, fallback = ''): string {
  const s = typeof val === 'string' ? val.trim() : fallback;
  return s.slice(0, maxLen);
}

function clampNum(val: unknown, min: number, max: number, fallback: number): number {
  const n = Number(val);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

function createId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 8);
  return `${prefix}-${Date.now().toString(36)}-${rand}`.replace(/[^a-zA-Z0-9_-]/g, '');
}

function tsToIso(val: unknown): string {
  if (val instanceof Timestamp) {
    return val.toDate().toISOString();
  }
  if (val && typeof val === 'object' && 'toDate' in val && typeof (val as { toDate: () => Date }).toDate === 'function') {
    return (val as { toDate: () => Date }).toDate().toISOString();
  }
  if (typeof val === 'string' && val.length > 0) {
    return val;
  }
  return new Date().toISOString();
}

function sanitizeAvatarConfig(cfg: AvatarConfig): AvatarConfig {
  const out: AvatarConfig = {
    skinTone: cfg.skinTone,
    hairStyle: cfg.hairStyle,
    facialHair: cfg.facialHair,
    clothing: cfg.clothing,
    accessory: cfg.accessory,
    expression: cfg.expression,
    accentColor: clampString(cfg.accentColor || '#9672E8', 20, '#9672E8'),
  };
  if (cfg.customPhotoUrl && cfg.customPhotoUrl.length <= 150000) {
    out.customPhotoUrl = cfg.customPhotoUrl;
  }
  return out;
}

function buildTaskFirestoreDoc(
  task: HouseholdTask,
  createdByUid: string,
  memberUids: string[],
  isCreate: boolean,
  existingCreatedAt?: FieldValue | Timestamp
): Record<string, unknown> {
  const docData: Record<string, unknown> = {
    id: task.id,
    title: clampString(task.title, 120, 'Chore'),
    category: task.category,
    points: clampNum(Math.round(task.points), 5, 200, 20),
    priority: task.priority,
    frequency: task.frequency,
    assignedToId: task.assignedToId,
    participantIds: task.participantIds.slice(0, 10),
    dueDate: task.dueDate,
    dueTime: task.dueTime,
    dueAt: clampString(task.dueAt, 40),
    occurrenceId: clampString(task.occurrenceId, 160),
    occurrenceSeq: clampNum(Math.round(task.occurrenceSeq), 1, 100000, 1),
    status: task.status,
    history: (task.history || []).slice(0, 50),
    createdByUid,
    memberUids: memberUids.slice(0, 10),
    createdAt: isCreate ? serverTimestamp() : existingCreatedAt || serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  if (task.description) {
    docData.description = clampString(task.description, 280);
  }
  if (task.frequency === 'custom' && task.customIntervalDays !== undefined) {
    docData.customIntervalDays = clampNum(Math.round(task.customIntervalDays), 1, 90, 3);
  }
  if (task.pausedUntil) {
    docData.pausedUntil = clampString(task.pausedUntil, 40);
  }
  if (task.pausedReason) {
    docData.pausedReason = clampString(task.pausedReason, 120);
  }
  if (task.reassignedAt) {
    docData.reassignedAt = clampString(task.reassignedAt, 40);
  }
  if (typeof task.reassignedBeforeDeadline === 'boolean') {
    docData.reassignedBeforeDeadline = task.reassignedBeforeDeadline;
  }
  if (task.lastCompletedOccurrenceKey) {
    docData.lastCompletedOccurrenceKey = clampString(task.lastCompletedOccurrenceKey, 160);
  }

  return docData;
}

export async function getUserLink(uid: string): Promise<UserLinkDoc | null> {
  const path = `users/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (!snap.exists()) return null;
    const d = snap.data();
    return {
      uid: String(d.uid),
      displayName: String(d.displayName),
      householdId: String(d.householdId),
      residentId: String(d.residentId),
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

export async function getPrivateUserEmail(uid: string): Promise<string> {
  const path = `users/${uid}/private/info`;
  try {
    const snap = await getDoc(doc(db, 'users', uid, 'private', 'info'));
    if (!snap.exists()) return '';
    return String(snap.data().email || '');
  } catch {
    return '';
  }
}

export async function checkInviteCode(rawCode: string): Promise<HouseholdInviteDoc | null> {
  const code = rawCode.trim().toUpperCase();
  if (!/^[A-Z0-9-]{4,32}$/.test(code)) return null;
  const path = `invites/${code}`;
  try {
    const snap = await getDoc(doc(db, 'invites', code));
    if (!snap.exists()) return null;
    const d = snap.data();
    return {
      code: String(d.code),
      householdId: String(d.householdId),
      createdByUid: String(d.createdByUid),
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }
}

/**
 * Bootstraps The House of Chores for the first verified partner (e.g., Adson).
 */
export async function bootstrapHouseOfChores(params: {
  user: FirebaseUser;
  chosenResidentId: 'res-adson' | 'res-arty';
  displayName?: string;
}): Promise<UserLinkDoc> {
  const { user, chosenResidentId, displayName } = params;
  const seed = createInitialHouseholdState(new Date());
  const householdId = DEFAULT_HOUSEHOLD_ID;
  const inviteCode = 'HOUSE-TENS';
  const memberUids = [user.uid];
  const cleanName = clampString(
    displayName || user.displayName || (chosenResidentId === 'res-adson' ? 'Adson' : 'Arty'),
    40,
    'Icon'
  );

  const batch = writeBatch(db);

  batch.set(doc(db, 'households', householdId), {
    id: householdId,
    houseName: clampString(seed.houseName, 60),
    tagline: clampString(seed.tagline, 100),
    houseStyle: seed.houseStyle,
    timeZone: clampString(seed.timeZone, 64),
    ownerUid: user.uid,
    inviteCode,
    preferences: seed.preferences,
    penaltySettings: seed.penaltySettings,
    memberUids,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  batch.set(doc(db, 'invites', inviteCode), {
    code: inviteCode,
    householdId,
    createdByUid: user.uid,
    createdAt: serverTimestamp(),
  });

  batch.set(doc(db, 'households', householdId, 'members', user.uid), {
    uid: user.uid,
    householdId,
    residentId: chosenResidentId,
    role: 'owner',
    inviteCode,
    memberUids,
    joinedAt: serverTimestamp(),
  });

  batch.set(doc(db, 'users', user.uid), {
    uid: user.uid,
    displayName: cleanName,
    householdId,
    residentId: chosenResidentId,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  batch.set(doc(db, 'users', user.uid, 'private', 'info'), {
    uid: user.uid,
    email: clampString(user.email || `${user.uid}@google-user`, 160),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  for (const res of seed.residents) {
    const isMe = res.id === chosenResidentId;
    batch.set(doc(db, 'households', householdId, 'residents', res.id), {
      id: res.id,
      uid: isMe ? user.uid : '',
      name: isMe && displayName ? cleanName : clampString(res.name, 40),
      handle: clampString(res.handle, 40),
      role: res.role,
      color: clampString(res.color, 20),
      points: res.points,
      streak: res.streak,
      shadeIntensity: res.shadeIntensity,
      muteShadeNotifications: res.muteShadeNotifications,
      pushEnabled: false,
      avatarConfig: sanitizeAvatarConfig(res.avatarConfig),
      memberUids,
      updatedAt: serverTimestamp(),
    });
  }

  for (const task of seed.tasks) {
    batch.set(
      doc(db, 'households', householdId, 'tasks', task.id),
      buildTaskFirestoreDoc(task, user.uid, memberUids, true)
    );
  }

  for (const item of seed.shoppingItems) {
    batch.set(doc(db, 'households', householdId, 'shoppingItems', item.id), {
      id: item.id,
      name: clampString(item.name, 100),
      quantity: clampNum(item.quantity, 0.1, 10000, 1),
      unit: item.unit,
      category: item.category,
      authorId: item.authorId,
      authorUid: user.uid,
      status: item.status,
      memberUids,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }

  for (const note of seed.pinNotes) {
    batch.set(doc(db, 'households', householdId, 'pinNotes', note.id), {
      id: note.id,
      authorId: note.authorId,
      authorUid: user.uid,
      content: clampString(note.content, 220),
      pinned: note.pinned,
      memberUids,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }

  for (const tx of seed.pointLedger) {
    batch.set(doc(db, 'households', householdId, 'pointLedger', tx.id), {
      id: tx.id,
      residentId: tx.residentId,
      taskId: tx.taskId,
      taskTitle: clampString(tx.taskTitle, 120),
      occurrenceId: clampString(tx.occurrenceId, 160),
      type: tx.type,
      basePoints: tx.basePoints,
      penaltyPercent: tx.penaltyPercent,
      pointsDelta: tx.pointsDelta,
      penaltyDeducted: tx.penaltyDeducted,
      wasOverdue: tx.wasOverdue,
      delayMinutes: tx.delayMinutes,
      weekKey: clampString(tx.weekKey, 16),
      actorUid: user.uid,
      memberUids,
      createdAt: serverTimestamp(),
    });
  }

  for (const log of seed.activityLog) {
    batch.set(doc(db, 'households', householdId, 'activityLog', log.id), {
      id: log.id,
      type: log.type,
      actorId: log.actorId,
      actorUid: user.uid,
      summary: clampString(log.summary, 200),
      memberUids,
      createdAt: serverTimestamp(),
    });
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `households/${householdId}`);
  }

  return {
    uid: user.uid,
    displayName: cleanName,
    householdId,
    residentId: chosenResidentId,
  };
}

/**
 * Joins an existing household using an invite code, claims the partner slot,
 * and appends the joining user's UID to household documents so realtime queries populate immediately.
 */
export async function joinHouseWithInviteCode(params: {
  user: FirebaseUser;
  inviteCode: string;
  preferredSlot: 'res-arty' | 'res-adson' | 'custom';
  displayName?: string;
}): Promise<UserLinkDoc> {
  const { user, inviteCode, preferredSlot, displayName } = params;
  const code = inviteCode.trim().toUpperCase();
  const invite = await checkInviteCode(code);
  if (!invite) {
    throw new Error('Invalid household invite code');
  }

  const { householdId, createdByUid } = invite;
  const provisionalResidentId =
    preferredSlot === 'custom' ? createId('res') : preferredSlot;
  const cleanName = clampString(
    displayName || user.displayName || (preferredSlot === 'res-adson' ? 'Adson' : 'Arty'),
    40,
    'Partner'
  );
  const initialMemberUids = Array.from(new Set([createdByUid, user.uid]));

  // Step 1: Atomically create membership gate + user link + private PII
  const step1Batch = writeBatch(db);
  step1Batch.set(doc(db, 'households', householdId, 'members', user.uid), {
    uid: user.uid,
    householdId,
    residentId: provisionalResidentId,
    role: 'partner',
    inviteCode: code,
    memberUids: initialMemberUids,
    joinedAt: serverTimestamp(),
  });
  step1Batch.set(doc(db, 'users', user.uid), {
    uid: user.uid,
    displayName: cleanName,
    householdId,
    residentId: provisionalResidentId,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  step1Batch.set(doc(db, 'users', user.uid, 'private', 'info'), {
    uid: user.uid,
    email: clampString(user.email || `${user.uid}@google-user`, 160),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  try {
    await step1Batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `households/${householdId}/members/${user.uid}`);
  }

  // Step 2: Now a verified household member — read household + seed/known docs, claim slot & sync memberUids
  let finalResidentId = provisionalResidentId;
  try {
    const syncBatch = writeBatch(db);
    let syncWrites = 0;

    const houseRef = doc(db, 'households', householdId);
    const houseSnap = await getDoc(houseRef);
    if (houseSnap.exists()) {
      const existingUids: string[] = Array.isArray(houseSnap.data().memberUids)
        ? houseSnap.data().memberUids
        : [];
      if (!existingUids.includes(user.uid)) {
        syncBatch.update(houseRef, {
          memberUids: [...existingUids, user.uid],
          updatedAt: serverTimestamp(),
        });
        syncWrites++;
      }
    }

    // Sync owner's member doc
    const ownerMemberRef = doc(db, 'households', householdId, 'members', createdByUid);
    const ownerMemberSnap = await getDoc(ownerMemberRef);
    if (ownerMemberSnap.exists()) {
      const existingUids: string[] = Array.isArray(ownerMemberSnap.data().memberUids)
        ? ownerMemberSnap.data().memberUids
        : [];
      if (!existingUids.includes(user.uid)) {
        syncBatch.update(ownerMemberRef, {
          memberUids: [...existingUids, user.uid],
        });
        syncWrites++;
      }
    }

    // Sync & claim resident slot
    const seedResidentIds = ['res-adson', 'res-arty'];
    let claimedSlot = false;

    for (const rId of seedResidentIds) {
      const rRef = doc(db, 'households', householdId, 'residents', rId);
      const rSnap = await getDoc(rRef);
      if (!rSnap.exists()) continue;
      const rData = rSnap.data();
      const existingUids: string[] = Array.isArray(rData.memberUids) ? rData.memberUids : [];
      const needsUidAppend = !existingUids.includes(user.uid);
      const nextUids = needsUidAppend ? [...existingUids, user.uid] : existingUids;

      if (rId === provisionalResidentId && rData.uid === '' && preferredSlot !== 'custom') {
        syncBatch.update(rRef, {
          uid: user.uid,
          ...(needsUidAppend ? { memberUids: nextUids } : {}),
          updatedAt: serverTimestamp(),
        });
        claimedSlot = true;
        syncWrites++;
      } else if (rId === provisionalResidentId && rData.uid === user.uid) {
        claimedSlot = true;
        if (needsUidAppend) {
          syncBatch.update(rRef, {
            memberUids: nextUids,
            updatedAt: serverTimestamp(),
          });
          syncWrites++;
        }
      } else if (needsUidAppend) {
        syncBatch.update(rRef, {
          memberUids: nextUids,
          updatedAt: serverTimestamp(),
        });
        syncWrites++;
      }
    }

    if (!claimedSlot) {
      // Both default slots were taken or custom selected: create dedicated ResidentProfile doc
      const customId = preferredSlot === 'custom' ? provisionalResidentId : createId('res');
      finalResidentId = customId;
      const handle = cleanName.toLowerCase().replace(/[^a-z0-9]/g, '') || 'icon';
      syncBatch.set(doc(db, 'households', householdId, 'residents', customId), {
        id: customId,
        uid: user.uid,
        name: cleanName,
        handle: clampString(handle, 40),
        role: 'partner',
        color: '#8EA8F5',
        points: 0,
        streak: 0,
        shadeIntensity: 'a_little_shady',
        muteShadeNotifications: false,
        pushEnabled: false,
        avatarConfig: {
          skinTone: 'honey',
          hairStyle: 'waves',
          facialHair: 'none',
          clothing: 'lavender_sweater',
          accessory: 'none',
          expression: 'smile',
          accentColor: '#8EA8F5',
        },
        memberUids: initialMemberUids,
        updatedAt: serverTimestamp(),
      });
      syncBatch.update(doc(db, 'users', user.uid), {
        residentId: customId,
        updatedAt: serverTimestamp(),
      });
      syncWrites += 2;
    }

    // Also sync known seed doc IDs so partner immediately sees chores/shopping/notes even if owner is offline
    const knownSeedDocs: Array<[string, string[]]> = [
      ['tasks', ['task-1', 'task-2', 'task-3', 'task-4', 'task-5']],
      ['shoppingItems', ['shop-1', 'shop-2', 'shop-3', 'shop-4', 'shop-5']],
      ['pinNotes', ['note-1', 'note-2']],
      ['pointLedger', ['tx-seed-1', 'tx-seed-2', 'tx-seed-3', 'tx-seed-4', 'tx-seed-5']],
      ['activityLog', ['log-seed-1', 'log-seed-2']],
    ];

    for (const [colName, ids] of knownSeedDocs) {
      const hasUpdatedAt = colName !== 'pointLedger' && colName !== 'activityLog';
      for (const id of ids) {
        const ref = doc(db, 'households', householdId, colName, id);
        const snap = await getDoc(ref);
        if (!snap.exists()) continue;
        const existingUids: string[] = Array.isArray(snap.data().memberUids)
          ? snap.data().memberUids
          : [];
        if (!existingUids.includes(user.uid)) {
          syncBatch.update(ref, {
            memberUids: [...existingUids, user.uid],
            ...(hasUpdatedAt ? { updatedAt: serverTimestamp() } : {}),
          });
          syncWrites++;
        }
      }
    }

    const joinLogId = createId('log');
    syncBatch.set(doc(db, 'households', householdId, 'activityLog', joinLogId), {
      id: joinLogId,
      type: 'house',
      actorId: finalResidentId,
      actorUid: user.uid,
      summary: clampString(`${cleanName} joined HAUS OF HUNZ`, 200),
      memberUids: initialMemberUids,
      createdAt: serverTimestamp(),
    });
    syncWrites++;

    if (syncWrites > 0) {
      await syncBatch.commit();
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `households/${householdId}`);
  }

  return {
    uid: user.uid,
    displayName: cleanName,
    householdId,
    residentId: finalResidentId,
  };
}

/**
 * Backfills any newly joined household member UIDs onto subcollection docs created prior to join.
 */
export async function syncMemberUidsAcrossHousehold(
  householdId: string,
  allMemberUids: string[],
  currentUid: string
): Promise<void> {
  if (allMemberUids.length <= 1) return;

  const collectionsWithUpdatedAt = [
    'residents',
    'tasks',
    'shoppingItems',
    'pinNotes',
    'swapRequests',
    'notifications',
  ];
  const immutableCollections = ['pointLedger', 'pokes', 'activityLog'];

  const batch = writeBatch(db);
  let updates = 0;

  try {
    const houseSnap = await getDoc(doc(db, 'households', householdId));
    if (houseSnap.exists()) {
      const existingUids: string[] = Array.isArray(houseSnap.data().memberUids)
        ? houseSnap.data().memberUids
        : [];
      const missing = allMemberUids.filter((u) => !existingUids.includes(u));
      if (missing.length === 1) {
        batch.update(doc(db, 'households', householdId), {
          memberUids: [...existingUids, missing[0]],
          updatedAt: serverTimestamp(),
        });
        updates++;
      }
    }

    for (const col of [...collectionsWithUpdatedAt, ...immutableCollections]) {
      const hasUpdatedAt = collectionsWithUpdatedAt.includes(col);
      const q = query(
        collection(db, 'households', householdId, col),
        where('memberUids', 'array-contains', currentUid)
      );
      const snap = await getDocs(q);
      for (const d of snap.docs) {
        const existingUids: string[] = Array.isArray(d.data().memberUids)
          ? d.data().memberUids
          : [];
        const missing = allMemberUids.filter((u) => !existingUids.includes(u));
        if (missing.length === 1 && updates < 400) {
          batch.update(d.ref, {
            memberUids: [...existingUids, missing[0]],
            ...(hasUpdatedAt ? { updatedAt: serverTimestamp() } : {}),
          });
          updates++;
        }
      }
    }

    if (updates > 0) {
      await batch.commit();
    }
  } catch {
    // Non-fatal background backfill; will retry on next member snapshot
  }
}

/**
 * Subscribes to all household documents and subcollections in real time via Firestore onSnapshot.
 */
export function subscribeToHouseholdRealtime(params: {
  householdId: string;
  uid: string;
  userEmail: string;
  onUpdate: (state: HouseholdState, meta: HouseholdRealtimeMeta) => void;
}): Unsubscribe {
  const { householdId, uid, userEmail, onUpdate } = params;

  let houseDocData: DocumentData | null = null;
  let members: HouseholdMemberDoc[] = [];
  let residents: Resident[] = [];
  let tasks: HouseholdTask[] = [];
  let shoppingItems: ShoppingItem[] = [];
  let pinNotes: PinNote[] = [];
  let pointLedger: PointTransaction[] = [];
  let pokes: PokeRecord[] = [];
  let swapRequests: SwapRequest[] = [];
  let notifications: InAppNotification[] = [];
  let activityLog: HouseActivityLog[] = [];
  let syncedMemberCount = 0;

  const emitIfReady = () => {
    if (!houseDocData) return;

    const allMemberUids = Array.from(
      new Set([
        ...(Array.isArray(houseDocData.memberUids)
          ? (houseDocData.memberUids as string[])
          : []),
        ...members.map((m) => m.uid),
      ])
    ).slice(0, 10);

    if (allMemberUids.length > syncedMemberCount && allMemberUids.length > 1) {
      syncedMemberCount = allMemberUids.length;
      void syncMemberUidsAcrossHousehold(householdId, allMemberUids, uid);
    }

    const rawHouseName = String(houseDocData.houseName || 'HAUS OF HUNZ');
    const rawTagline = String(
      houseDocData.tagline || 'Two icons. One haus. Endless shade.'
    );
    const assembled: HouseholdState = {
      version: 3,
      householdId,
      houseName:
        rawHouseName === 'The House of Chores' ? 'HAUS OF HUNZ' : rawHouseName,
      tagline:
        rawTagline === 'Two icons. One household. Zero excuses.'
          ? 'Two icons. One haus. Endless shade.'
          : rawTagline,
      houseStyle: (houseDocData.houseStyle as HouseStyle) || 'apartment',
      timeZone: String(houseDocData.timeZone || 'America/Sao_Paulo'),
      preferences: (houseDocData.preferences as HousePreferences) || {
        weeklyPointsGoal: 150,
        reducedMotionOverride: false,
      },
      penaltySettings: (houseDocData.penaltySettings as PenaltySettings),
      residents: [...residents].sort((a, b) => a.id.localeCompare(b.id)),
      tasks: [...tasks].sort((a, b) => a.dueAt.localeCompare(b.dueAt)),
      shoppingItems: [...shoppingItems].sort((a, b) =>
        b.createdAt.localeCompare(a.createdAt)
      ),
      pinNotes: [...pinNotes].sort((a, b) => {
        if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
        return b.createdAt.localeCompare(a.createdAt);
      }),
      pointLedger: [...pointLedger].sort((a, b) =>
        b.createdAt.localeCompare(a.createdAt)
      ),
      pokes: [...pokes].sort((a, b) => b.createdAt.localeCompare(a.createdAt)),
      swapRequests: [...swapRequests].sort((a, b) =>
        b.createdAt.localeCompare(a.createdAt)
      ),
      notifications: [...notifications].sort((a, b) =>
        b.createdAt.localeCompare(a.createdAt)
      ),
      activityLog: [...activityLog].sort((a, b) =>
        b.createdAt.localeCompare(a.createdAt)
      ),
      lastSyncedAt: tsToIso(houseDocData.updatedAt),
    };

    onUpdate(assembled, {
      householdOwnerUid: String(houseDocData.ownerUid || ''),
      inviteCode: String(houseDocData.inviteCode || 'HOUSE-TENS'),
      memberUids: allMemberUids,
      members,
    });
  };

  const unsubs: Unsubscribe[] = [];

  unsubs.push(
    onSnapshot(
      doc(db, 'households', householdId),
      (snap) => {
        if (!snap.exists()) return;
        houseDocData = snap.data();
        emitIfReady();
      },
      (err) => handleFirestoreError(err, OperationType.GET, `households/${householdId}`)
    )
  );

  const subQuery = (colName: string) =>
    query(
      collection(db, 'households', householdId, colName),
      where('memberUids', 'array-contains', uid)
    );

  unsubs.push(
    onSnapshot(
      subQuery('members'),
      (snap) => {
        members = snap.docs.map((d) => {
          const data = d.data();
          return {
            uid: String(data.uid),
            householdId: String(data.householdId),
            residentId: String(data.residentId),
            role: data.role as 'owner' | 'partner',
            inviteCode: data.inviteCode ? String(data.inviteCode) : undefined,
            memberUids: (data.memberUids as string[]) || [],
            joinedAt: tsToIso(data.joinedAt),
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/members`
        )
    )
  );

  unsubs.push(
    onSnapshot(
      subQuery('residents'),
      (snap) => {
        residents = snap.docs.map((d) => {
          const data = d.data();
          const isMe = data.uid === uid;
          return {
            id: String(data.id),
            name: String(data.name),
            handle: String(data.handle),
            email: isMe ? userEmail : `@${String(data.handle)}`,
            role: (data.role as 'icon' | 'partner') || 'partner',
            color: String(data.color || '#9672E8'),
            points: Number(data.points || 0),
            streak: Number(data.streak || 0),
            shadeIntensity: (data.shadeIntensity as ShadeIntensity) || 'a_little_shady',
            muteShadeNotifications: Boolean(data.muteShadeNotifications),
            pushEnabled: Boolean(data.pushEnabled),
            avatarConfig: data.avatarConfig as AvatarConfig,
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/residents`
        )
    )
  );

  unsubs.push(
    onSnapshot(
      subQuery('tasks'),
      (snap) => {
        tasks = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: String(data.id),
            title: String(data.title),
            description: data.description ? String(data.description) : undefined,
            category: data.category as TaskCategory,
            points: Number(data.points),
            priority: data.priority as TaskPriority,
            frequency: data.frequency as TaskFrequency,
            customIntervalDays:
              typeof data.customIntervalDays === 'number'
                ? data.customIntervalDays
                : undefined,
            assignedToId: String(data.assignedToId),
            participantIds: (data.participantIds as string[]) || [],
            dueDate: String(data.dueDate),
            dueTime: String(data.dueTime),
            dueAt: String(data.dueAt),
            occurrenceId: String(data.occurrenceId),
            occurrenceSeq: Number(data.occurrenceSeq || 1),
            status: data.status as 'pending' | 'completed' | 'paused',
            pausedUntil: data.pausedUntil ? String(data.pausedUntil) : undefined,
            pausedReason: data.pausedReason ? String(data.pausedReason) : undefined,
            reassignedAt: data.reassignedAt ? String(data.reassignedAt) : undefined,
            reassignedBeforeDeadline:
              typeof data.reassignedBeforeDeadline === 'boolean'
                ? data.reassignedBeforeDeadline
                : undefined,
            lastCompletedOccurrenceKey: data.lastCompletedOccurrenceKey
              ? String(data.lastCompletedOccurrenceKey)
              : undefined,
            history: (data.history as HouseholdTask['history']) || [],
            createdAt: tsToIso(data.createdAt),
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/tasks`
        )
    )
  );

  unsubs.push(
    onSnapshot(
      subQuery('shoppingItems'),
      (snap) => {
        shoppingItems = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: String(data.id),
            name: String(data.name),
            quantity: Number(data.quantity),
            unit: data.unit as ShoppingUnit,
            category: data.category as ShoppingCategory,
            authorId: String(data.authorId),
            status: data.status as 'pending' | 'bought',
            buyerId: data.buyerId ? String(data.buyerId) : undefined,
            boughtAt: data.boughtAt ? String(data.boughtAt) : undefined,
            createdAt: tsToIso(data.createdAt),
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/shoppingItems`
        )
    )
  );

  unsubs.push(
    onSnapshot(
      subQuery('pinNotes'),
      (snap) => {
        pinNotes = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: String(data.id),
            authorId: String(data.authorId),
            content: String(data.content),
            pinned: Boolean(data.pinned),
            createdAt: tsToIso(data.createdAt),
            updatedAt: tsToIso(data.updatedAt),
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/pinNotes`
        )
    )
  );

  unsubs.push(
    onSnapshot(
      subQuery('pointLedger'),
      (snap) => {
        pointLedger = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: String(data.id),
            residentId: String(data.residentId),
            taskId: String(data.taskId),
            taskTitle: String(data.taskTitle),
            occurrenceId: String(data.occurrenceId),
            type: data.type as PointTransaction['type'],
            basePoints: Number(data.basePoints),
            penaltyPercent: Number(data.penaltyPercent),
            pointsDelta: Number(data.pointsDelta),
            penaltyDeducted: Number(data.penaltyDeducted),
            wasOverdue: Boolean(data.wasOverdue),
            delayMinutes: Number(data.delayMinutes),
            weekKey: String(data.weekKey),
            createdAt: tsToIso(data.createdAt),
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/pointLedger`
        )
    )
  );

  unsubs.push(
    onSnapshot(
      subQuery('pokes'),
      (snap) => {
        pokes = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: String(data.id),
            taskId: String(data.taskId),
            taskTitle: String(data.taskTitle),
            occurrenceId: String(data.occurrenceId),
            fromResidentId: String(data.fromResidentId),
            toResidentId: String(data.toResidentId),
            intensity: data.intensity as ShadeIntensity,
            message: String(data.message),
            deliveredViaPush: Boolean(data.deliveredViaPush),
            createdAt: tsToIso(data.createdAt),
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/pokes`
        )
    )
  );

  unsubs.push(
    onSnapshot(
      subQuery('swapRequests'),
      (snap) => {
        swapRequests = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: String(data.id),
            taskId: String(data.taskId),
            taskTitle: String(data.taskTitle),
            fromResidentId: String(data.fromResidentId),
            toResidentId: String(data.toResidentId),
            note: data.note ? String(data.note) : undefined,
            status: data.status as SwapRequest['status'],
            createdAt: tsToIso(data.createdAt),
            respondedAt: data.respondedAt ? String(data.respondedAt) : undefined,
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/swapRequests`
        )
    )
  );

  unsubs.push(
    onSnapshot(
      subQuery('notifications'),
      (snap) => {
        notifications = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: String(data.id),
            recipientId: String(data.recipientId),
            senderId: data.senderId ? String(data.senderId) : undefined,
            type: data.type as InAppNotification['type'],
            title: String(data.title),
            body: String(data.body),
            taskId: data.taskId ? String(data.taskId) : undefined,
            intensity: data.intensity as ShadeIntensity | undefined,
            readAt: data.readAt ? String(data.readAt) : undefined,
            createdAt: tsToIso(data.createdAt),
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/notifications`
        )
    )
  );

  unsubs.push(
    onSnapshot(
      subQuery('activityLog'),
      (snap) => {
        activityLog = snap.docs.map((d) => {
          const data = d.data();
          return {
            id: String(data.id),
            type: data.type as HouseActivityLog['type'],
            actorId: String(data.actorId),
            summary: String(data.summary),
            createdAt: tsToIso(data.createdAt),
          };
        });
        emitIfReady();
      },
      (err) =>
        handleFirestoreError(
          err,
          OperationType.LIST,
          `households/${householdId}/activityLog`
        )
    )
  );

  return () => {
    unsubs.forEach((u) => u());
  };
}

// ---------- Household Mutations ----------

function addActivityToBatch(
  batch: ReturnType<typeof writeBatch>,
  householdId: string,
  memberUids: string[],
  actorId: string,
  actorUid: string,
  type: HouseActivityLog['type'],
  summary: string
): void {
  const logId = createId('log');
  batch.set(doc(db, 'households', householdId, 'activityLog', logId), {
    id: logId,
    type,
    actorId,
    actorUid,
    summary: clampString(summary, 200, 'Activity'),
    memberUids: memberUids.slice(0, 10),
    createdAt: serverTimestamp(),
  });
}

export async function addTaskFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResidentId: string,
  actorUid: string,
  payload: {
    title: string;
    description?: string;
    category: TaskCategory;
    points: number;
    priority: TaskPriority;
    frequency: TaskFrequency;
    customIntervalDays?: number;
    assignedToId: string;
    participantIds: string[];
    dueDate: string;
    dueTime: string;
  }
): Promise<void> {
  const title = clampString(payload.title, 120);
  if (!title) throw new Error('Chore title is required');

  const dueDate = payload.dueDate || getTodayYMD(state.timeZone);
  const dueTime = payload.dueTime || '20:00';
  const pool =
    payload.participantIds.length > 0
      ? payload.participantIds.filter((id) =>
          state.residents.some((r) => r.id === id)
        )
      : state.residents.map((r) => r.id);
  const assignedToId = pool.includes(payload.assignedToId)
    ? payload.assignedToId
    : pool[0];

  const taskId = createId('task');
  const newTask: HouseholdTask = {
    id: taskId,
    title,
    description: payload.description ? clampString(payload.description, 280) : undefined,
    category: payload.category || 'Limpeza',
    points: clampNum(Math.round(payload.points), 5, 200, 20),
    priority: payload.priority || 'media',
    frequency: payload.frequency || 'weekly',
    customIntervalDays:
      payload.frequency === 'custom'
        ? clampNum(Math.round(payload.customIntervalDays || 3), 1, 90, 3)
        : undefined,
    assignedToId,
    participantIds: pool,
    dueDate,
    dueTime,
    dueAt: computeDueAtIso(dueDate, dueTime, state.timeZone),
    occurrenceSeq: 1,
    occurrenceId: `${taskId}::${dueDate}::1`,
    status: 'pending',
    history: [],
    createdAt: new Date().toISOString(),
  };

  const batch = writeBatch(db);
  batch.set(
    doc(db, 'households', state.householdId, 'tasks', taskId),
    buildTaskFirestoreDoc(newTask, actorUid, memberUids, true)
  );
  addActivityToBatch(
    batch,
    state.householdId,
    memberUids,
    actorResidentId,
    actorUid,
    'task',
    `Added chore "${newTask.title}" (${newTask.points} pts)`
  );

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `households/${state.householdId}/tasks/${taskId}`);
  }
}

export async function updateTaskFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResidentId: string,
  actorUid: string,
  taskId: string,
  updates: {
    title?: string;
    description?: string;
    category?: TaskCategory;
    points?: number;
    priority?: TaskPriority;
    frequency?: TaskFrequency;
    customIntervalDays?: number;
    assignedToId?: string;
    participantIds?: string[];
    dueDate?: string;
    dueTime?: string;
  }
): Promise<void> {
  const existing = state.tasks.find((t) => t.id === taskId);
  if (!existing) throw new Error('Chore not found');

  const nextDueDate = updates.dueDate || existing.dueDate;
  const nextDueTime = updates.dueTime || existing.dueTime || '20:00';
  const nextFreq = updates.frequency || existing.frequency;
  const nextAssignee = updates.assignedToId || existing.assignedToId;
  const assigneeChanged = nextAssignee !== existing.assignedToId;

  const patch: Record<string, unknown> = {
    title: clampString(updates.title ?? existing.title, 120, existing.title),
    description:
      updates.description !== undefined
        ? updates.description.trim()
          ? clampString(updates.description, 280)
          : deleteField()
        : existing.description || deleteField(),
    category: updates.category ?? existing.category,
    points: clampNum(Math.round(updates.points ?? existing.points), 5, 200, existing.points),
    priority: updates.priority ?? existing.priority,
    frequency: nextFreq,
    customIntervalDays:
      nextFreq === 'custom'
        ? clampNum(Math.round(updates.customIntervalDays ?? existing.customIntervalDays ?? 3), 1, 90, 3)
        : deleteField(),
    assignedToId: nextAssignee,
    participantIds:
      updates.participantIds && updates.participantIds.length > 0
        ? updates.participantIds.slice(0, 10)
        : existing.participantIds,
    dueDate: nextDueDate,
    dueTime: nextDueTime,
    dueAt: computeDueAtIso(nextDueDate, nextDueTime, state.timeZone),
    updatedAt: serverTimestamp(),
  };

  if (assigneeChanged) {
    patch.reassignedAt = new Date().toISOString();
    patch.reassignedBeforeDeadline = Date.now() <= new Date(existing.dueAt).getTime();
  }

  const batch = writeBatch(db);
  batch.update(doc(db, 'households', state.householdId, 'tasks', taskId), patch);
  if (assigneeChanged) {
    const nextName = state.residents.find((r) => r.id === nextAssignee)?.name || 'Partner';
    addActivityToBatch(
      batch,
      state.householdId,
      memberUids,
      actorResidentId,
      actorUid,
      'task',
      `Reassigned "${patch.title}" to ${nextName}`
    );
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `households/${state.householdId}/tasks/${taskId}`);
  }
}

export async function pauseOrResumeTaskFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResidentId: string,
  actorUid: string,
  taskId: string,
  action: 'pause' | 'resume',
  pausedReason?: string,
  pausedUntil?: string
): Promise<void> {
  const existing = state.tasks.find((t) => t.id === taskId);
  if (!existing) throw new Error('Chore not found');

  const batch = writeBatch(db);
  const taskRef = doc(db, 'households', state.householdId, 'tasks', taskId);

  if (action === 'pause') {
    batch.update(taskRef, {
      status: 'paused',
      pausedUntil: pausedUntil ? clampString(pausedUntil, 40) : deleteField(),
      pausedReason: pausedReason ? clampString(pausedReason, 120) : deleteField(),
      updatedAt: serverTimestamp(),
    });
    addActivityToBatch(
      batch,
      state.householdId,
      memberUids,
      actorResidentId,
      actorUid,
      'task',
      `Paused "${existing.title}"${pausedReason ? ` (${clampString(pausedReason, 60)})` : ''}`
    );
  } else {
    batch.update(taskRef, {
      status: 'pending',
      pausedUntil: deleteField(),
      pausedReason: deleteField(),
      updatedAt: serverTimestamp(),
    });
    addActivityToBatch(
      batch,
      state.householdId,
      memberUids,
      actorResidentId,
      actorUid,
      'task',
      `Resumed "${existing.title}"`
    );
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `households/${state.householdId}/tasks/${taskId}`);
  }
}

export async function completeTaskFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResidentId: string,
  actorUid: string,
  taskId: string
): Promise<{
  pointsAwarded: number;
  penaltyPercent: number;
  nextResidentId: string;
  updatedTask: HouseholdTask;
}> {
  const task = state.tasks.find((t) => t.id === taskId);
  if (!task) throw new Error('Chore not found');

  const nowIso = new Date().toISOString();
  const result = applyTaskCompletion(
    task,
    state.residents,
    state.pointLedger,
    actorResidentId,
    nowIso,
    state.timeZone,
    state.penaltySettings
  );

  if (!result.completed || !result.transaction) {
    throw new Error(
      result.reason === 'paused' ? 'Chore is paused' : 'Chore occurrence already completed'
    );
  }

  const batch = writeBatch(db);
  const updatedTask = result.updatedTask;
  const executorResident = result.updatedResidents.find((r) => r.id === actorResidentId)!;
  const tx = result.transaction;

  batch.update(doc(db, 'households', state.householdId, 'tasks', taskId), {
    assignedToId: updatedTask.assignedToId,
    dueDate: updatedTask.dueDate,
    dueAt: clampString(updatedTask.dueAt, 40),
    occurrenceId: clampString(updatedTask.occurrenceId, 160),
    occurrenceSeq: updatedTask.occurrenceSeq,
    status: updatedTask.status,
    reassignedAt: updatedTask.reassignedAt || deleteField(),
    reassignedBeforeDeadline:
      typeof updatedTask.reassignedBeforeDeadline === 'boolean'
        ? updatedTask.reassignedBeforeDeadline
        : deleteField(),
    lastCompletedOccurrenceKey: updatedTask.lastCompletedOccurrenceKey
      ? clampString(updatedTask.lastCompletedOccurrenceKey, 160)
      : deleteField(),
    history: updatedTask.history.slice(0, 50),
    updatedAt: serverTimestamp(),
  });

  batch.update(doc(db, 'households', state.householdId, 'residents', actorResidentId), {
    points: executorResident.points,
    streak: executorResident.streak,
    updatedAt: serverTimestamp(),
  });

  batch.set(doc(db, 'households', state.householdId, 'pointLedger', tx.id), {
    id: tx.id,
    residentId: tx.residentId,
    taskId: tx.taskId,
    taskTitle: clampString(tx.taskTitle, 120),
    occurrenceId: clampString(tx.occurrenceId, 160),
    type: tx.type,
    basePoints: tx.basePoints,
    penaltyPercent: tx.penaltyPercent,
    pointsDelta: tx.pointsDelta,
    penaltyDeducted: tx.penaltyDeducted,
    wasOverdue: tx.wasOverdue,
    delayMinutes: tx.delayMinutes,
    weekKey: clampString(tx.weekKey, 16),
    actorUid,
    memberUids: memberUids.slice(0, 10),
    createdAt: serverTimestamp(),
  });

  if (result.penaltyPoints > 0) {
    const notifId = createId('notif');
    batch.set(doc(db, 'households', state.householdId, 'notifications', notifId), {
      id: notifId,
      recipientId: actorResidentId,
      actorUid,
      type: 'penalty',
      title: 'Not the deadline getting ghosted.',
      body: clampString(
        `"${task.title}" was completed late (-${result.penaltyPercent}%, ${result.penaltyPoints} pts deducted). You earned ${result.pointsAwarded} pts.`,
        280
      ),
      taskId: task.id,
      memberUids: memberUids.slice(0, 10),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }

  addActivityToBatch(
    batch,
    state.householdId,
    memberUids,
    actorResidentId,
    actorUid,
    result.penaltyPoints > 0 ? 'penalty' : 'task',
    result.penaltyPoints > 0
      ? `${executorResident.name} completed "${task.title}" late (-${result.penaltyPercent}% penalty, +${result.pointsAwarded} pts)`
      : `${executorResident.name} served "${task.title}" (+${result.pointsAwarded} pts)`
  );

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `households/${state.householdId}/tasks/${taskId}`);
  }

  return {
    pointsAwarded: result.pointsAwarded,
    penaltyPercent: result.penaltyPercent,
    nextResidentId: result.nextResidentId,
    updatedTask,
  };
}

export async function deleteTaskFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResidentId: string,
  actorUid: string,
  taskId: string
): Promise<void> {
  const target = state.tasks.find((t) => t.id === taskId);
  if (!target) throw new Error('Chore not found');

  const batch = writeBatch(db);
  batch.delete(doc(db, 'households', state.householdId, 'tasks', taskId));
  addActivityToBatch(
    batch,
    state.householdId,
    memberUids,
    actorResidentId,
    actorUid,
    'task',
    `Removed chore "${target.title}"`
  );

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `households/${state.householdId}/tasks/${taskId}`);
  }
}

export async function sendPokeFirestore(params: {
  state: HouseholdState;
  memberUids: string[];
  actorResident: Resident;
  actorUid: string;
  taskId: string;
  locale: string;
  dispatchPush: (recipientId: string, title: string, body: string, tag: string) => Promise<boolean>;
}): Promise<{ poke: PokeRecord; pushDelivered: boolean }> {
  const { state, memberUids, actorResident, actorUid, taskId, locale, dispatchPush } = params;
  const task = state.tasks.find((t) => t.id === taskId);
  if (!task) throw new Error('Chore not found');

  const recipient = state.residents.find((r) => r.id === task.assignedToId);
  if (!recipient) throw new Error('Assigned housemate not found');

  const nowMs = Date.now();
  const eligibility = checkPokeEligibility(
    task,
    actorResident.id,
    recipient,
    state.pokes,
    nowMs,
    state.penaltySettings
  );

  if (!eligibility.allowed) {
    throw new Error(eligibility.reason || 'Poke not permitted');
  }

  const intensity: ShadeIntensity = recipient.shadeIntensity;
  const message = buildShadeMessage(
    intensity,
    recipient.name,
    task.title,
    locale === 'pt-BR' ? 'pt-BR' : 'en-US',
    state.pokes.length
  );

  const pushDelivered = await dispatchPush(
    recipient.id,
    `${actorResident.name} threw some shade 💅`,
    message,
    `poke-${task.occurrenceId}`
  );

  const pokeId = createId('poke');
  const notifId = createId('notif');
  const nowIso = new Date(nowMs).toISOString();

  const poke: PokeRecord = {
    id: pokeId,
    taskId: task.id,
    taskTitle: clampString(task.title, 120),
    occurrenceId: clampString(task.occurrenceId, 160),
    fromResidentId: actorResident.id,
    toResidentId: recipient.id,
    intensity,
    message: clampString(message, 280),
    deliveredViaPush: pushDelivered,
    createdAt: nowIso,
  };

  const batch = writeBatch(db);
  batch.set(doc(db, 'households', state.householdId, 'pokes', pokeId), {
    ...poke,
    fromUid: actorUid,
    memberUids: memberUids.slice(0, 10),
    createdAt: serverTimestamp(),
  });
  batch.set(doc(db, 'households', state.householdId, 'notifications', notifId), {
    id: notifId,
    recipientId: recipient.id,
    senderId: actorResident.id,
    actorUid,
    type: 'poke',
    title: clampString(`You've been READ by ${actorResident.name}.`, 120),
    body: clampString(message, 280),
    taskId: task.id,
    intensity,
    memberUids: memberUids.slice(0, 10),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  addActivityToBatch(
    batch,
    state.householdId,
    memberUids,
    actorResident.id,
    actorUid,
    'poke',
    `Threw shade at ${recipient.name} over "${task.title}"`
  );

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `households/${state.householdId}/pokes/${pokeId}`);
  }

  return { poke, pushDelivered };
}

export async function proposeSwapFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResident: Resident,
  actorUid: string,
  taskId: string,
  note?: string
): Promise<void> {
  const task = state.tasks.find((t) => t.id === taskId);
  const partner = state.residents.find((r) => r.id !== actorResident.id);
  if (!task || !partner) throw new Error('Valid chore and partner required');

  const pending = state.swapRequests.find(
    (s) => s.taskId === task.id && s.status === 'pending'
  );
  if (pending) throw new Error('Swap request already pending');

  const swapId = createId('swap');
  const notifId = createId('notif');
  const cleanNote = note ? clampString(note, 120) : '';

  const batch = writeBatch(db);
  batch.set(doc(db, 'households', state.householdId, 'swapRequests', swapId), {
    id: swapId,
    taskId: task.id,
    taskTitle: clampString(task.title, 120),
    fromResidentId: actorResident.id,
    fromUid: actorUid,
    toResidentId: partner.id,
    ...(cleanNote ? { note: cleanNote } : {}),
    status: 'pending',
    memberUids: memberUids.slice(0, 10),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  batch.set(doc(db, 'households', state.householdId, 'notifications', notifId), {
    id: notifId,
    recipientId: partner.id,
    senderId: actorResident.id,
    actorUid,
    type: 'swap',
    title: clampString(`${actorResident.name} requested a chore swap`, 120),
    body: clampString(`"${task.title}"${cleanNote ? ` — "${cleanNote}"` : ''}`, 280),
    taskId: task.id,
    memberUids: memberUids.slice(0, 10),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  addActivityToBatch(
    batch,
    state.householdId,
    memberUids,
    actorResident.id,
    actorUid,
    'swap',
    `Requested swap with ${partner.name} for "${task.title}"`
  );

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `households/${state.householdId}/swapRequests/${swapId}`);
  }
}

export async function respondSwapFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResidentId: string,
  actorUid: string,
  swapId: string,
  decision: 'accept' | 'decline' | 'cancel'
): Promise<void> {
  const swap = state.swapRequests.find((s) => s.id === swapId);
  if (!swap || swap.status !== 'pending') throw new Error('Pending swap not found');

  const nowIso = new Date().toISOString();
  const batch = writeBatch(db);
  const swapRef = doc(db, 'households', state.householdId, 'swapRequests', swapId);

  if (decision === 'cancel' && swap.fromResidentId === actorResidentId) {
    batch.update(swapRef, {
      status: 'cancelled',
      respondedAt: nowIso,
      updatedAt: serverTimestamp(),
    });
  } else if (
    (decision === 'accept' || decision === 'decline') &&
    swap.toResidentId === actorResidentId
  ) {
    batch.update(swapRef, {
      status: decision === 'accept' ? 'accepted' : 'declined',
      respondedAt: nowIso,
      updatedAt: serverTimestamp(),
    });

    if (decision === 'accept') {
      const task = state.tasks.find((t) => t.id === swap.taskId);
      if (task) {
        const nextAssignee =
          task.assignedToId === swap.fromResidentId
            ? swap.toResidentId
            : swap.fromResidentId;
        batch.update(doc(db, 'households', state.householdId, 'tasks', task.id), {
          assignedToId: nextAssignee,
          reassignedAt: nowIso,
          reassignedBeforeDeadline: Date.now() <= new Date(task.dueAt).getTime(),
          updatedAt: serverTimestamp(),
        });
      }
      addActivityToBatch(
        batch,
        state.householdId,
        memberUids,
        actorResidentId,
        actorUid,
        'swap',
        `Accepted swap for "${swap.taskTitle}"`
      );
    } else {
      addActivityToBatch(
        batch,
        state.householdId,
        memberUids,
        actorResidentId,
        actorUid,
        'swap',
        `Declined swap for "${swap.taskTitle}"`
      );
    }
  } else {
    throw new Error('Not authorized to respond to this swap');
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `households/${state.householdId}/swapRequests/${swapId}`);
  }
}

export async function addShoppingItemFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResidentId: string,
  actorUid: string,
  payload: {
    name: string;
    quantity: number;
    unit: ShoppingUnit;
    category: ShoppingCategory;
  }
): Promise<void> {
  const name = clampString(payload.name, 100);
  if (!name) throw new Error('Item name is required');

  const itemId = createId('shop');
  const batch = writeBatch(db);
  batch.set(doc(db, 'households', state.householdId, 'shoppingItems', itemId), {
    id: itemId,
    name,
    quantity: clampNum(payload.quantity, 0.1, 10000, 1),
    unit: payload.unit || 'un',
    category: payload.category || 'Mercado',
    authorId: actorResidentId,
    authorUid: actorUid,
    status: 'pending',
    memberUids: memberUids.slice(0, 10),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  addActivityToBatch(
    batch,
    state.householdId,
    memberUids,
    actorResidentId,
    actorUid,
    'shopping',
    `Added "${name}" to shopping list`
  );

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `households/${state.householdId}/shoppingItems/${itemId}`);
  }
}

export async function updateShoppingItemFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResidentId: string,
  actorUid: string,
  itemId: string,
  payload:
    | { action: 'mark_bought' | 'restore' }
    | { name?: string; quantity?: number; unit?: ShoppingUnit; category?: ShoppingCategory }
): Promise<void> {
  const item = state.shoppingItems.find((i) => i.id === itemId);
  if (!item) throw new Error('Shopping item not found');

  const batch = writeBatch(db);
  const ref = doc(db, 'households', state.householdId, 'shoppingItems', itemId);

  if ('action' in payload && payload.action === 'mark_bought') {
    batch.update(ref, {
      status: 'bought',
      buyerId: actorResidentId,
      boughtAt: new Date().toISOString(),
      updatedAt: serverTimestamp(),
    });
    addActivityToBatch(
      batch,
      state.householdId,
      memberUids,
      actorResidentId,
      actorUid,
      'shopping',
      `Picked up "${item.name}"`
    );
  } else if ('action' in payload && payload.action === 'restore') {
    batch.update(ref, {
      status: 'pending',
      buyerId: deleteField(),
      boughtAt: deleteField(),
      updatedAt: serverTimestamp(),
    });
    addActivityToBatch(
      batch,
      state.householdId,
      memberUids,
      actorResidentId,
      actorUid,
      'shopping',
      `Restored "${item.name}" to shopping list`
    );
  } else {
    const updates = payload as {
      name?: string;
      quantity?: number;
      unit?: ShoppingUnit;
      category?: ShoppingCategory;
    };
    batch.update(ref, {
      name: clampString(updates.name ?? item.name, 100, item.name),
      quantity: clampNum(updates.quantity ?? item.quantity, 0.1, 10000, item.quantity),
      unit: updates.unit ?? item.unit,
      category: updates.category ?? item.category,
      updatedAt: serverTimestamp(),
    });
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `households/${state.householdId}/shoppingItems/${itemId}`);
  }
}

export async function deleteShoppingItemFirestore(
  state: HouseholdState,
  itemId: string
): Promise<void> {
  const batch = writeBatch(db);
  batch.delete(doc(db, 'households', state.householdId, 'shoppingItems', itemId));
  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `households/${state.householdId}/shoppingItems/${itemId}`);
  }
}

export async function addPinNoteFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResidentId: string,
  actorUid: string,
  content: string,
  pinned: boolean
): Promise<void> {
  const clean = clampString(content, 220);
  if (!clean) throw new Error('Note content required');
  const noteId = createId('note');

  const batch = writeBatch(db);
  batch.set(doc(db, 'households', state.householdId, 'pinNotes', noteId), {
    id: noteId,
    authorId: actorResidentId,
    authorUid: actorUid,
    content: clean,
    pinned: Boolean(pinned),
    memberUids: memberUids.slice(0, 10),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `households/${state.householdId}/pinNotes/${noteId}`);
  }
}

export async function updatePinNoteFirestore(
  state: HouseholdState,
  noteId: string,
  payload: { content?: string; togglePin?: boolean }
): Promise<void> {
  const existing = state.pinNotes.find((n) => n.id === noteId);
  if (!existing) throw new Error('Pin note not found');

  const batch = writeBatch(db);
  const ref = doc(db, 'households', state.householdId, 'pinNotes', noteId);
  if (payload.togglePin) {
    batch.update(ref, {
      pinned: !existing.pinned,
      updatedAt: serverTimestamp(),
    });
  } else if (payload.content !== undefined) {
    const clean = clampString(payload.content, 220);
    if (!clean) throw new Error('Note content required');
    batch.update(ref, {
      content: clean,
      updatedAt: serverTimestamp(),
    });
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `households/${state.householdId}/pinNotes/${noteId}`);
  }
}

export async function deletePinNoteFirestore(
  state: HouseholdState,
  noteId: string
): Promise<void> {
  const batch = writeBatch(db);
  batch.delete(doc(db, 'households', state.householdId, 'pinNotes', noteId));
  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `households/${state.householdId}/pinNotes/${noteId}`);
  }
}

export async function markAllNotificationsReadFirestore(
  state: HouseholdState,
  recipientResidentId: string
): Promise<void> {
  const unread = state.notifications.filter(
    (n) => n.recipientId === recipientResidentId && !n.readAt
  );
  if (unread.length === 0) return;

  const nowIso = new Date().toISOString();
  const batch = writeBatch(db);
  for (const n of unread) {
    batch.update(doc(db, 'households', state.householdId, 'notifications', n.id), {
      readAt: nowIso,
      updatedAt: serverTimestamp(),
    });
  }
  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `households/${state.householdId}/notifications`);
  }
}

export async function updateMyProfileFirestore(
  state: HouseholdState,
  resident: Resident,
  uid: string,
  payload: {
    name?: string;
    color?: string;
    shadeIntensity?: ShadeIntensity;
    muteShadeNotifications?: boolean;
    avatarConfig?: Partial<AvatarConfig>;
    pushEnabled?: boolean;
  }
): Promise<void> {
  const mergedAvatar = sanitizeAvatarConfig({
    ...resident.avatarConfig,
    ...(payload.avatarConfig || {}),
  });
  const nextName = clampString(payload.name ?? resident.name, 40, resident.name);

  const batch = writeBatch(db);
  batch.update(doc(db, 'households', state.householdId, 'residents', resident.id), {
    name: nextName,
    color: clampString(payload.color ?? mergedAvatar.accentColor, 20, resident.color),
    shadeIntensity: payload.shadeIntensity ?? resident.shadeIntensity,
    muteShadeNotifications:
      typeof payload.muteShadeNotifications === 'boolean'
        ? payload.muteShadeNotifications
        : resident.muteShadeNotifications,
    pushEnabled:
      typeof payload.pushEnabled === 'boolean'
        ? payload.pushEnabled
        : resident.pushEnabled,
    avatarConfig: mergedAvatar,
    updatedAt: serverTimestamp(),
  });

  if (payload.name && payload.name.trim() !== resident.name) {
    batch.update(doc(db, 'users', uid), {
      displayName: nextName,
      updatedAt: serverTimestamp(),
    });
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `households/${state.householdId}/residents/${resident.id}`);
  }
}

export async function updateHouseSettingsFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResident: Resident,
  actorUid: string,
  payload: {
    houseName?: string;
    tagline?: string;
    houseStyle?: HouseStyle;
    timeZone?: string;
    preferences?: Partial<HousePreferences>;
    penaltySettings?: Partial<PenaltySettings>;
  }
): Promise<void> {
  const nextTimeZone = clampString(payload.timeZone ?? state.timeZone, 64, state.timeZone);
  const nextPreferences: HousePreferences = {
    weeklyPointsGoal: clampNum(
      payload.preferences?.weeklyPointsGoal ?? state.preferences.weeklyPointsGoal,
      20,
      1000,
      150
    ),
    reducedMotionOverride:
      typeof payload.preferences?.reducedMotionOverride === 'boolean'
        ? payload.preferences.reducedMotionOverride
        : state.preferences.reducedMotionOverride,
  };

  const nextPenalty: PenaltySettings = {
    enabled:
      typeof payload.penaltySettings?.enabled === 'boolean'
        ? payload.penaltySettings.enabled
        : state.penaltySettings.enabled,
    gracePeriodMinutes: clampNum(
      payload.penaltySettings?.gracePeriodMinutes ?? state.penaltySettings.gracePeriodMinutes,
      0,
      720,
      60
    ),
    tiers:
      Array.isArray(payload.penaltySettings?.tiers) &&
      payload.penaltySettings.tiers.length > 0
        ? payload.penaltySettings.tiers.slice(0, 10)
        : state.penaltySettings.tiers,
    reminderFrequencyHours: clampNum(
      payload.penaltySettings?.reminderFrequencyHours ??
        state.penaltySettings.reminderFrequencyHours,
      1,
      72,
      12
    ),
    maxPokesPerOccurrence: clampNum(
      payload.penaltySettings?.maxPokesPerOccurrence ??
        state.penaltySettings.maxPokesPerOccurrence,
      1,
      5,
      2
    ),
  };

  const batch = writeBatch(db);
  batch.update(doc(db, 'households', state.householdId), {
    houseName: clampString(payload.houseName ?? state.houseName, 60, state.houseName),
    tagline: clampString(payload.tagline ?? state.tagline, 100, state.tagline),
    houseStyle: payload.houseStyle ?? state.houseStyle,
    timeZone: nextTimeZone,
    preferences: nextPreferences,
    penaltySettings: nextPenalty,
    updatedAt: serverTimestamp(),
  });

  if (payload.timeZone && payload.timeZone !== state.timeZone) {
    for (const task of state.tasks) {
      batch.update(doc(db, 'households', state.householdId, 'tasks', task.id), {
        dueAt: computeDueAtIso(task.dueDate, task.dueTime || '20:00', nextTimeZone),
        updatedAt: serverTimestamp(),
      });
    }
  }

  addActivityToBatch(
    batch,
    state.householdId,
    memberUids,
    actorResident.id,
    actorUid,
    'house',
    `${actorResident.name} updated household settings`
  );

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, `households/${state.householdId}`);
  }
}

export async function resetDemoDataFirestore(
  state: HouseholdState,
  memberUids: string[],
  actorResident: Resident,
  actorUid: string,
  householdOwnerUid: string
): Promise<void> {
  if (actorUid !== householdOwnerUid) {
    throw new Error('Only the household creator can reset demo data');
  }

  const fresh = createInitialHouseholdState(new Date());
  const batch = writeBatch(db);

  // Clear current subcollections (preserving residents & members)
  for (const t of state.tasks) {
    batch.delete(doc(db, 'households', state.householdId, 'tasks', t.id));
  }
  for (const s of state.shoppingItems) {
    batch.delete(doc(db, 'households', state.householdId, 'shoppingItems', s.id));
  }
  for (const n of state.pinNotes) {
    batch.delete(doc(db, 'households', state.householdId, 'pinNotes', n.id));
  }
  for (const tx of state.pointLedger) {
    batch.delete(doc(db, 'households', state.householdId, 'pointLedger', tx.id));
  }
  for (const p of state.pokes) {
    batch.delete(doc(db, 'households', state.householdId, 'pokes', p.id));
  }
  for (const sw of state.swapRequests) {
    batch.delete(doc(db, 'households', state.householdId, 'swapRequests', sw.id));
  }
  for (const notif of state.notifications) {
    batch.delete(doc(db, 'households', state.householdId, 'notifications', notif.id));
  }
  for (const log of state.activityLog) {
    batch.delete(doc(db, 'households', state.householdId, 'activityLog', log.id));
  }

  // Restore resident points & streaks
  for (const r of state.residents) {
    const seedRes = fresh.residents.find((sr) => sr.id === r.id);
    batch.update(doc(db, 'households', state.householdId, 'residents', r.id), {
      points: seedRes ? seedRes.points : 0,
      streak: seedRes ? seedRes.streak : 0,
      updatedAt: serverTimestamp(),
    });
  }

  // Re-seed tasks, shoppingItems, pinNotes, pointLedger, activityLog
  for (const task of fresh.tasks) {
    batch.set(
      doc(db, 'households', state.householdId, 'tasks', task.id),
      buildTaskFirestoreDoc(task, actorUid, memberUids, true)
    );
  }
  for (const item of fresh.shoppingItems) {
    batch.set(doc(db, 'households', state.householdId, 'shoppingItems', item.id), {
      id: item.id,
      name: clampString(item.name, 100),
      quantity: clampNum(item.quantity, 0.1, 10000, 1),
      unit: item.unit,
      category: item.category,
      authorId: item.authorId,
      authorUid: actorUid,
      status: item.status,
      memberUids: memberUids.slice(0, 10),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }
  for (const note of fresh.pinNotes) {
    batch.set(doc(db, 'households', state.householdId, 'pinNotes', note.id), {
      id: note.id,
      authorId: note.authorId,
      authorUid: actorUid,
      content: clampString(note.content, 220),
      pinned: note.pinned,
      memberUids: memberUids.slice(0, 10),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  }
  for (const tx of fresh.pointLedger) {
    batch.set(doc(db, 'households', state.householdId, 'pointLedger', tx.id), {
      id: tx.id,
      residentId: tx.residentId,
      taskId: tx.taskId,
      taskTitle: clampString(tx.taskTitle, 120),
      occurrenceId: clampString(tx.occurrenceId, 160),
      type: tx.type,
      basePoints: tx.basePoints,
      penaltyPercent: tx.penaltyPercent,
      pointsDelta: tx.pointsDelta,
      penaltyDeducted: tx.penaltyDeducted,
      wasOverdue: tx.wasOverdue,
      delayMinutes: tx.delayMinutes,
      weekKey: clampString(tx.weekKey, 16),
      actorUid,
      memberUids: memberUids.slice(0, 10),
      createdAt: serverTimestamp(),
    });
  }
  for (const log of fresh.activityLog) {
    batch.set(doc(db, 'households', state.householdId, 'activityLog', log.id), {
      id: log.id,
      type: log.type,
      actorId: log.actorId,
      actorUid,
      summary: clampString(log.summary, 200),
      memberUids: memberUids.slice(0, 10),
      createdAt: serverTimestamp(),
    });
  }

  try {
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `households/${state.householdId}`);
  }
}
