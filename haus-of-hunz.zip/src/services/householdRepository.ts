import { HouseholdState } from '../types/household';

const OFFLINE_CACHE_KEY = 'houseofchores_offline_cache_v3';
const LEGACY_STORAGE_KEY_V2 = 'casaemdia_state_v2';
const LEGACY_FINANCE_BACKUP_KEY = 'casaemdia_legacy_finances_backup_v1';

/**
 * Archives any legacy v2 financial data (expenses & settlements) into a recoverable backup key
 * without exposing financial screens or destroying user history.
 */
export function archiveLegacyFinancialDataIfPresent(): {
  archived: boolean;
  expenseCount: number;
  settlementCount: number;
} {
  if (typeof window === 'undefined') {
    return { archived: false, expenseCount: 0, settlementCount: 0 };
  }
  try {
    const rawV2 = window.localStorage.getItem(LEGACY_STORAGE_KEY_V2);
    if (!rawV2) return { archived: false, expenseCount: 0, settlementCount: 0 };

    const parsed = JSON.parse(rawV2) as {
      expenses?: unknown[];
      settlements?: unknown[];
    };
    const expenses = Array.isArray(parsed.expenses) ? parsed.expenses : [];
    const settlements = Array.isArray(parsed.settlements)
      ? parsed.settlements
      : [];

    if (expenses.length === 0 && settlements.length === 0) {
      return { archived: false, expenseCount: 0, settlementCount: 0 };
    }

    const existingBackup = window.localStorage.getItem(
      LEGACY_FINANCE_BACKUP_KEY
    );
    if (!existingBackup) {
      window.localStorage.setItem(
        LEGACY_FINANCE_BACKUP_KEY,
        JSON.stringify({
          archivedAt: new Date().toISOString(),
          sourceVersion: 2,
          expenses,
          settlements,
        })
      );
    }
    return {
      archived: true,
      expenseCount: expenses.length,
      settlementCount: settlements.length,
    };
  } catch {
    return { archived: false, expenseCount: 0, settlementCount: 0 };
  }
}

export function getLegacyFinanceBackupJson(): string | null {
  if (typeof window === 'undefined') return null;
  try {
    return window.localStorage.getItem(LEGACY_FINANCE_BACKUP_KEY);
  } catch {
    return null;
  }
}

export function saveOfflineHouseholdCache(state: HouseholdState): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(OFFLINE_CACHE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadOfflineHouseholdCache(): HouseholdState | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(OFFLINE_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as HouseholdState;
    if (parsed && parsed.version === 3 && Array.isArray(parsed.residents)) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}
