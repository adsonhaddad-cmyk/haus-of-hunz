import { FormEvent, useMemo, useState } from 'react';
import {
  ArrowRight,
  ArrowLeftRight,
  Bell,
  Check,
  CheckCheck,
  Clock,
  Edit3,
  Pin,
  PinOff,
  Send,
  ShoppingBag,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import {
  HouseholdState,
  PinNote,
  Resident,
  TabKey,
} from '../types/household';
import {
  formatLocalizedDate,
  formatLocalizedDateTime,
  formatLocalizedTime24or12,
  getISOWeekKey,
} from '../utils/dates';
import {
  buildWeeklyCeremonySummary,
  checkPokeEligibility,
  evaluateTaskOverdue,
} from '../utils/gameEngine';
import { Avatar } from './Avatar';
import {
  ClayCard,
  ClayProgressBar,
  ConfirmModal,
  EmptyState,
  SiliconeButton,
} from './ui/ClayPrimitives';
import { DreamyHomeHeroScene } from './ui/DreamyHomeHeroScene';
import { HausWordmark } from './ui/HausWordmark';
import { Mascot } from './ui/Mascots';
import { ThreeDIcon } from './ui/ThreeDIcons';

interface DashboardViewProps {
  state: HouseholdState;
  activeResident: Resident;
  onlineResidentIds: string[];
  onCompleteTask: (taskId: string) => Promise<void>;
  onSendPoke: (taskId: string) => Promise<void>;
  onRespondSwap: (
    swapId: string,
    decision: 'accept' | 'decline' | 'cancel'
  ) => Promise<void>;
  onAddPinNote: (content: string, pinned: boolean) => Promise<void>;
  onUpdatePinNote: (noteId: string, content: string) => Promise<void>;
  onTogglePinNote: (noteId: string) => Promise<void>;
  onDeletePinNote: (noteId: string) => Promise<void>;
  onMarkAllNotificationsRead: () => Promise<void>;
  onNavigate: (tab: TabKey) => void;
}

function formatDelayLabel(minutes: number): string {
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const rem = minutes % 60;
  return rem > 0 ? `${hours}h ${rem}m` : `${hours}h`;
}

export function DashboardView({
  state,
  activeResident,
  onlineResidentIds,
  onCompleteTask,
  onSendPoke,
  onRespondSwap,
  onAddPinNote,
  onUpdatePinNote,
  onTogglePinNote,
  onDeletePinNote,
  onMarkAllNotificationsRead,
  onNavigate,
}: DashboardViewProps) {
  const { t, i18n } = useTranslation();
  const locale = i18n.language;
  const nowMs = Date.now();

  const [noteContent, setNoteContent] = useState('');
  const [pinNewNote, setPinNewNote] = useState(false);
  const [editingNote, setEditingNote] = useState<PinNote | null>(null);
  const [editNoteText, setEditNoteText] = useState('');
  const [confirmDeleteNote, setConfirmDeleteNote] = useState<PinNote | null>(
    null
  );

  const residentMap = useMemo(() => {
    const map = new Map<string, Resident>();
    state.residents.forEach((r) => map.set(r.id, r));
    return map;
  }, [state.residents]);

  const myPendingTasks = useMemo(
    () =>
      state.tasks
        .filter(
          (task) =>
            task.status === 'pending' && task.assignedToId === activeResident.id
        )
        .sort(
          (a, b) => new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime()
        ),
    [state.tasks, activeResident.id]
  );

  const overduePartnerTasks = useMemo(
    () =>
      state.tasks.filter((task) => {
        if (task.status !== 'pending') return false;
        if (task.assignedToId === activeResident.id) return false;
        const evalResult = evaluateTaskOverdue(
          task,
          nowMs,
          state.penaltySettings
        );
        return evalResult.isOverdue;
      }),
    [state.tasks, activeResident.id, nowMs, state.penaltySettings]
  );

  const primaryOverdueTask = overduePartnerTasks[0] || null;
  const primaryOverdueRecipient = primaryOverdueTask
    ? residentMap.get(primaryOverdueTask.assignedToId)
    : undefined;
  const primaryPokeEligibility =
    primaryOverdueTask && primaryOverdueRecipient
      ? checkPokeEligibility(
          primaryOverdueTask,
          activeResident.id,
          primaryOverdueRecipient,
          state.pokes,
          nowMs,
          state.penaltySettings
        )
      : null;

  const myOverdueCount = useMemo(
    () =>
      myPendingTasks.filter(
        (task) =>
          evaluateTaskOverdue(task, nowMs, state.penaltySettings).isOverdue
      ).length,
    [myPendingTasks, nowMs, state.penaltySettings]
  );

  const nextSpotlightTask = myPendingTasks[0] || null;
  const spotlightOverdue = nextSpotlightTask
    ? evaluateTaskOverdue(nextSpotlightTask, nowMs, state.penaltySettings)
    : null;

  const weeklySummary = useMemo(
    () => buildWeeklyCeremonySummary(state, getISOWeekKey()),
    [state]
  );
  const weeklyGoal = Math.max(20, state.preferences.weeklyPointsGoal || 150);

  const pendingSwaps = useMemo(
    () =>
      state.swapRequests.filter(
        (s) =>
          s.status === 'pending' &&
          (s.toResidentId === activeResident.id ||
            s.fromResidentId === activeResident.id)
      ),
    [state.swapRequests, activeResident.id]
  );

  const myNotifications = useMemo(
    () =>
      state.notifications
        .filter((n) => n.recipientId === activeResident.id)
        .slice(0, 6),
    [state.notifications, activeResident.id]
  );
  const unreadNotifCount = myNotifications.filter((n) => !n.readAt).length;

  const pendingShopping = useMemo(
    () => state.shoppingItems.filter((item) => item.status === 'pending'),
    [state.shoppingItems]
  );

  const sortedNotes = useMemo(
    () =>
      [...state.pinNotes].sort((a, b) => {
        if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
        return (
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      }),
    [state.pinNotes]
  );

  const handleCreateNote = async (e: FormEvent) => {
    e.preventDefault();
    if (!noteContent.trim()) return;
    await onAddPinNote(noteContent.trim(), pinNewNote);
    setNoteContent('');
    setPinNewNote(false);
  };

  const handleSaveEditNote = async (e: FormEvent) => {
    e.preventDefault();
    if (!editingNote || !editNoteText.trim()) return;
    await onUpdatePinNote(editingNote.id, editNoteText.trim());
    setEditingNote(null);
    setEditNoteText('');
  };

  return (
    <div className="space-y-6">
      {/* 1. Dreamy Hero Card */}
      <ClayCard className="overflow-hidden">
        <div className="relative">
          <DreamyHomeHeroScene />

          {/* Floating Hero Header */}
          <div className="absolute inset-x-0 top-0 p-4 sm:p-6 flex items-start justify-between gap-3">
            <div className="max-w-lg">
              <div className="flex items-center gap-2.5 mb-1.5">
                <HausWordmark variant="compact" tone="light" />
                {state.houseName && state.houseName !== 'HAUS OF HUNZ' && (
                  <span className="text-[11px] font-semibold text-[#FFE3F4]/90 truncate">
                    · {state.houseName}
                  </span>
                )}
              </div>
              <h1 className="font-editorial text-2xl sm:text-4xl font-bold text-[#FFF8FF] leading-tight drop-shadow-md">
                {t('dashboard.heroTitle')}
              </h1>
              <p className="text-xs sm:text-sm text-[#F4E8FF] mt-1 drop-shadow-sm">
                {state.tagline || t('dashboard.heroSubtitle')}
              </p>
            </div>

            <button
              type="button"
              onClick={() => onNavigate('house')}
              aria-label={t('dashboard.profileAria')}
              className="btn-3d-cloud min-h-[44px] px-3 py-1.5 rounded-full flex items-center gap-2 shrink-0"
            >
              <Avatar
                resident={activeResident}
                size="xs"
                showOnlineDot={onlineResidentIds.includes(activeResident.id)}
              />
              <span className="text-xs font-semibold text-[#38216B] hidden sm:inline">
                {activeResident.name}
              </span>
            </button>
          </div>

          {/* Partner Presence Strip */}
          <div className="absolute left-4 sm:left-6 bottom-12 sm:bottom-14 flex items-center gap-2">
            {state.residents.map((resident) => (
              <div
                key={resident.id}
                className="px-2.5 py-1 rounded-full bg-[#FFF8FF]/85 backdrop-blur-md border border-white/80 flex items-center gap-1.5 shadow-sm"
              >
                <Avatar
                  resident={resident}
                  size="xs"
                  showOnlineDot={onlineResidentIds.includes(resident.id)}
                />
                <span className="text-[11px] font-semibold text-[#38216B]">
                  {resident.name}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Overlapping Spotlight Card */}
        <div className="-mt-8 relative z-10 px-4 sm:px-6 pb-5 sm:pb-6">
          <div className="surface-glass rounded-[24px] p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <Mascot
                id={
                  !nextSpotlightTask
                    ? 'miss-mop'
                    : spotlightOverdue?.isOverdue
                      ? 'madame-deadline'
                      : 'miss-mop'
                }
                mood={
                  !nextSpotlightTask
                    ? 'celebrating'
                    : spotlightOverdue?.isOverdue
                      ? 'panicked'
                      : 'proud'
                }
                size="md"
              />
              <div className="min-w-0">
                {nextSpotlightTask ? (
                  <>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-[#9672E8]">
                        {t('dashboard.nextUpFor', { name: activeResident.name })}
                      </span>
                      <span className="font-mono-num text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#EADCF8] text-[#4C269A]">
                        +{nextSpotlightTask.points} {t('common.pts')}
                      </span>
                    </div>
                    <h2 className="font-editorial text-lg sm:text-xl font-bold text-[#38216B] truncate mt-0.5">
                      {nextSpotlightTask.title}
                    </h2>
                    <p className="text-xs text-[#7965A5] mt-0.5 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#9672E8] shrink-0" />
                      <span>
                        {t('tasks.dueLabel', {
                          date: formatLocalizedDate(
                            nextSpotlightTask.dueDate,
                            locale
                          ),
                          time: formatLocalizedTime24or12(
                            nextSpotlightTask.dueTime || '20:00',
                            locale
                          ),
                        })}
                      </span>
                    </p>
                  </>
                ) : (
                  <>
                    <h2 className="font-editorial text-lg sm:text-xl font-bold text-[#38216B]">
                      {t('dashboard.allClearTitle')}
                    </h2>
                    <p className="text-xs sm:text-sm text-[#7965A5] mt-0.5">
                      {t('dashboard.allClearDesc')}
                    </p>
                  </>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2.5 shrink-0">
              {nextSpotlightTask ? (
                <SiliconeButton
                  variant="lavender"
                  onClick={() => void onCompleteTask(nextSpotlightTask.id)}
                >
                  <Check className="w-4 h-4" />
                  <span>{t('dashboard.markAsDone')}</span>
                </SiliconeButton>
              ) : (
                <SiliconeButton
                  variant="lavender"
                  onClick={() => onNavigate('tasks')}
                >
                  <span>{t('dashboard.viewHousePlan')}</span>
                  <ArrowRight className="w-4 h-4" />
                </SiliconeButton>
              )}
              <button
                type="button"
                onClick={() => onNavigate('tasks')}
                aria-label={t('dashboard.openAllChoresAria')}
                className="btn-3d-cloud min-h-[44px] min-w-[44px] rounded-2xl inline-flex items-center justify-center"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </ClayCard>

      {/* 2. Dusty Drama Overdue Alert & Quick Poke & Shade */}
      {primaryOverdueTask && primaryOverdueRecipient && (
        <ClayCard className="p-4 sm:p-5 border-[#ED82BE]/60">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3.5 min-w-0">
              <Mascot id="dusty-drama" mood="shady" size="md" />
              <div className="min-w-0">
                <p className="text-xs font-bold uppercase tracking-wider text-[#B33981]">
                  {t('dashboard.overdueAlertBanner')}
                </p>
                <p className="font-editorial text-lg font-bold text-[#38216B] mt-0.5">
                  {primaryOverdueTask.title}
                </p>
                <p className="text-xs text-[#7965A5] mt-0.5">
                  {t('dashboard.overdueAlertSub', {
                    count: overduePartnerTasks.length,
                  })}{' '}
                  · {primaryOverdueRecipient.name} (
                  {formatDelayLabel(
                    evaluateTaskOverdue(
                      primaryOverdueTask,
                      nowMs,
                      state.penaltySettings
                    ).delayMinutes
                  )}
                  )
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <SiliconeButton
                variant="pink"
                disabled={!primaryPokeEligibility?.allowed}
                onClick={() => void onSendPoke(primaryOverdueTask.id)}
              >
                <Sparkles className="w-4 h-4" />
                <span>
                  {primaryPokeEligibility?.allowed
                    ? t('dashboard.throwShadeBtn')
                    : primaryPokeEligibility?.reason === 'cooldown_active'
                      ? t('tasks.shadeCooldown', {
                          hours: Math.max(
                            1,
                            Math.ceil(
                              primaryPokeEligibility.cooldownRemainingMs /
                                3600000
                            )
                          ),
                        })
                      : primaryPokeEligibility?.reason === 'max_pokes_reached'
                        ? t('tasks.shadeMaxed')
                        : t('tasks.shadeMuted')}
                </span>
              </SiliconeButton>
              <SiliconeButton
                variant="cloud"
                onClick={() => onNavigate('tasks')}
              >
                <span>{t('dashboard.viewPlan')}</span>
              </SiliconeButton>
            </div>
          </div>
        </ClayCard>
      )}

      {/* 3. Pending Chore Swap Requests */}
      {pendingSwaps.length > 0 && (
        <ClayCard className="p-4 sm:p-5 space-y-3">
          <div className="flex items-center gap-2.5">
            <ThreeDIcon kind="calendar" size="sm" />
            <h2 className="font-editorial text-lg font-bold text-[#38216B]">
              {t('dashboard.pendingSwapTitle')}
            </h2>
          </div>
          <div className="space-y-2.5">
            {pendingSwaps.map((swap) => {
              const fromRes = residentMap.get(swap.fromResidentId);
              const isRecipient = swap.toResidentId === activeResident.id;
              return (
                <div
                  key={swap.id}
                  className="surface-inset rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <ArrowLeftRight className="w-4 h-4 text-[#9672E8] shrink-0" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#38216B] truncate">
                        {t('dashboard.pendingSwapDesc', {
                          from: fromRes?.name ?? t('common.partnerFallback'),
                          title: swap.taskTitle,
                        })}
                      </p>
                      {swap.note && (
                        <p className="text-xs text-[#7965A5] mt-0.5">
                          “{swap.note}”
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {isRecipient ? (
                      <>
                        <SiliconeButton
                          variant="lavender"
                          onClick={() => void onRespondSwap(swap.id, 'accept')}
                          className="min-h-[40px] py-1.5 px-3 text-xs"
                        >
                          {t('dashboard.acceptSwap')}
                        </SiliconeButton>
                        <SiliconeButton
                          variant="cloud"
                          onClick={() => void onRespondSwap(swap.id, 'decline')}
                          className="min-h-[40px] py-1.5 px-3 text-xs"
                        >
                          {t('dashboard.declineSwap')}
                        </SiliconeButton>
                      </>
                    ) : (
                      <SiliconeButton
                        variant="cloud"
                        onClick={() => void onRespondSwap(swap.id, 'cancel')}
                        className="min-h-[40px] py-1.5 px-3 text-xs"
                      >
                        {t('common.cancel')}
                      </SiliconeButton>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </ClayCard>
      )}

      {/* 4. Main Grid: Your Slate + House Standings + Alerts + Shopping */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Your Slate */}
        <ClayCard className="lg:col-span-7 p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <ThreeDIcon kind="cleaning" size="md" />
              <div>
                <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                  {t('dashboard.myChoresToday')}
                </h2>
                <p className="text-xs text-[#7965A5]">
                  {t('dashboard.myChoresSubtitle')}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {myOverdueCount > 0 && (
                <span className="font-mono-num text-xs font-semibold px-2.5 py-1 rounded-full bg-[#FCE0F0] text-[#B33981]">
                  {t('dashboard.overdueCount', { count: myOverdueCount })}
                </span>
              )}
              <button
                type="button"
                onClick={() => onNavigate('tasks')}
                className="text-xs font-semibold text-[#4C269A] hover:underline min-h-[36px] px-2"
              >
                {t('dashboard.viewPlan')}
              </button>
            </div>
          </div>

          {myPendingTasks.length === 0 ? (
            <EmptyState
              iconKind="rewards"
              title={t('dashboard.emptyTodayTitle')}
              description={t('dashboard.emptyTodayDesc', {
                name: activeResident.name,
              })}
              action={
                <SiliconeButton
                  variant="lavender"
                  onClick={() => onNavigate('tasks')}
                >
                  {t('dashboard.viewHousePlan')}
                </SiliconeButton>
              }
            />
          ) : (
            <div className="space-y-2.5">
              {myPendingTasks.slice(0, 4).map((task) => {
                const overdueEval = evaluateTaskOverdue(
                  task,
                  nowMs,
                  state.penaltySettings
                );
                return (
                  <div
                    key={task.id}
                    className="surface-inset rounded-2xl p-3.5 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="text-sm font-semibold text-[#38216B] truncate">
                          {task.title}
                        </p>
                        <span className="font-mono-num text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#FFF8FF] text-[#4C269A]">
                          {overdueEval.penaltyPoints > 0
                            ? `${overdueEval.netPoints}/${task.points} ${t('common.pts')}`
                            : `+${task.points} ${t('common.pts')}`}
                        </span>
                      </div>
                      <p className="text-xs text-[#7965A5] mt-1 flex flex-wrap items-center gap-2">
                        <span>
                          {t('tasks.dueLabel', {
                            date: formatLocalizedDate(task.dueDate, locale),
                            time: formatLocalizedTime24or12(
                              task.dueTime || '20:00',
                              locale
                            ),
                          })}
                        </span>
                        {overdueEval.isOverdue && (
                          <span className="font-semibold text-[#B33981]">
                            {overdueEval.isWithinGrace
                              ? t('tasks.graceBadge', {
                                  mins: overdueEval.delayMinutes,
                                })
                              : t('tasks.overdueBadge', {
                                  delay: formatDelayLabel(
                                    overdueEval.delayMinutes
                                  ),
                                  percent: overdueEval.penaltyPercent,
                                })}
                          </span>
                        )}
                      </p>
                    </div>

                    <SiliconeButton
                      variant="lavender"
                      onClick={() => void onCompleteTask(task.id)}
                      className="min-h-[44px] px-3.5 py-2 shrink-0"
                    >
                      <Check className="w-4 h-4" />
                      <span className="hidden sm:inline">
                        {t('dashboard.markAsDone')}
                      </span>
                    </SiliconeButton>
                  </div>
                );
              })}
            </div>
          )}
        </ClayCard>

        {/* Right Column: Standings + Shared Shopping Mini */}
        <div className="lg:col-span-5 space-y-5">
          <ClayCard className="p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <ThreeDIcon kind="achievements" size="md" />
                <div>
                  <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                    {t('dashboard.standingsTitle')}
                  </h2>
                  <p className="text-xs text-[#7965A5] font-mono-num">
                    {t('dashboard.weeklyGoal', { goal: weeklyGoal })}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => onNavigate('leaderboard')}
                className="text-xs font-semibold text-[#4C269A] hover:underline min-h-[36px] px-2"
              >
                {t('dashboard.openLeaderboard')}
              </button>
            </div>

            <div className="space-y-3">
              {weeklySummary.standings.map((entry, idx) => {
                const resident = residentMap.get(entry.residentId);
                if (!resident) return null;
                const pct = Math.min(
                  100,
                  Math.round((entry.earnedPoints / weeklyGoal) * 100)
                );
                return (
                  <div key={resident.id} className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="font-mono-num text-xs font-bold text-[#9672E8] w-4">
                          #{idx + 1}
                        </span>
                        <Avatar
                          resident={resident}
                          size="xs"
                          showOnlineDot={onlineResidentIds.includes(resident.id)}
                        />
                        <span className="text-sm font-semibold text-[#38216B] truncate">
                          {resident.name}
                        </span>
                      </div>
                      <span className="font-mono-num text-xs font-bold text-[#4C269A]">
                        {entry.earnedPoints} {t('common.pts')}
                      </span>
                    </div>
                    <ClayProgressBar
                      percent={pct}
                      color={
                        idx === 0
                          ? 'linear-gradient(90deg, #9672E8 0%, #ED82BE 100%)'
                          : 'linear-gradient(90deg, #8EA8F5 0%, #C5A6F5 100%)'
                      }
                    />
                  </div>
                );
              })}
            </div>
          </ClayCard>

          <ClayCard className="p-5 sm:p-6 space-y-3.5">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <ThreeDIcon kind="shopping" size="md" />
                <div>
                  <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                    {t('dashboard.shoppingList')}
                  </h2>
                  <p className="text-xs text-[#7965A5]">
                    {t('dashboard.pendingShopping', {
                      count: pendingShopping.length,
                    })}
                  </p>
                </div>
              </div>
              <SiliconeButton
                variant="cloud"
                onClick={() => onNavigate('shopping')}
                className="min-h-[40px] py-1.5 px-3 text-xs"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>{t('dashboard.openList')}</span>
              </SiliconeButton>
            </div>

            {pendingShopping.length === 0 ? (
              <p className="text-xs text-[#7965A5] surface-inset rounded-2xl p-3">
                {t('dashboard.emptyShoppingMini')}
              </p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {pendingShopping.slice(0, 5).map((item) => (
                  <span
                    key={item.id}
                    className="px-3 py-1.5 rounded-2xl surface-inset text-xs font-medium text-[#38216B]"
                  >
                    {item.name} ·{' '}
                    <span className="font-mono-num text-[#7965A5]">
                      {item.quantity} {t(`shopping.units.${item.unit}`)}
                    </span>
                  </span>
                ))}
              </div>
            )}
          </ClayCard>
        </div>
      </div>

      {/* 5. Bottom Grid: Notifications Inbox + House Pinboard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Shade & House Alerts */}
        <ClayCard className="lg:col-span-5 p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <ThreeDIcon kind="shade" size="md" />
              <div>
                <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                  {t('dashboard.notificationsTitle')}
                </h2>
              </div>
            </div>
            {unreadNotifCount > 0 && (
              <button
                type="button"
                onClick={() => void onMarkAllNotificationsRead()}
                className="min-h-[36px] px-2.5 text-xs font-semibold text-[#4C269A] hover:underline inline-flex items-center gap-1"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                {t('dashboard.markAllRead')}
              </button>
            )}
          </div>

          {myNotifications.length === 0 ? (
            <div className="surface-inset rounded-2xl p-4 flex items-center gap-3 text-xs text-[#7965A5]">
              <Bell className="w-4 h-4 text-[#9672E8] shrink-0" />
              <span>{t('dashboard.noNotifications')}</span>
            </div>
          ) : (
            <div className="space-y-2.5">
              {myNotifications.map((notif) => (
                <div
                  key={notif.id}
                  className={`rounded-2xl p-3.5 border transition-colors ${
                    notif.readAt
                      ? 'surface-inset border-transparent opacity-80'
                      : 'bg-[#FFF8FF] border-[#ED82BE]/60 shadow-sm'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-xs font-bold text-[#4C269A]">
                      {notif.title}
                    </p>
                    <span className="text-[10px] font-mono-num text-[#7965A5] shrink-0">
                      {formatLocalizedDateTime(
                        notif.createdAt,
                        locale,
                        state.timeZone
                      )}
                    </span>
                  </div>
                  <p className="text-xs text-[#38216B] mt-1 leading-relaxed">
                    {notif.body}
                  </p>
                </div>
              ))}
            </div>
          )}
        </ClayCard>

        {/* House Pinboard */}
        <ClayCard className="lg:col-span-7 p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <ThreeDIcon kind="notes" size="md" />
              <div>
                <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                  {t('dashboard.houseNotes')}
                </h2>
                <p className="text-xs text-[#7965A5]">
                  {t('dashboard.houseNotesSubtitle')}
                </p>
              </div>
            </div>
            <span className="font-mono-num text-xs font-semibold text-[#7965A5]">
              {t('common.noteCount', { count: sortedNotes.length })}
            </span>
          </div>

          <form
            onSubmit={(e) => void handleCreateNote(e)}
            className="flex flex-col sm:flex-row gap-2.5"
          >
            <input
              type="text"
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              aria-label={t('dashboard.newNoteAria')}
              placeholder={t('dashboard.notePlaceholder', {
                name: activeResident.name,
              })}
              className="flex-1 min-h-[46px] px-4 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B] placeholder:text-[#7965A5]/70 focus:outline-none focus:ring-2 focus:ring-[#9672E8]"
            />
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setPinNewNote((p) => !p)}
                aria-label={t('dashboard.pinImportant')}
                className={`min-h-[46px] min-w-[46px] rounded-2xl inline-flex items-center justify-center transition-all ${
                  pinNewNote ? 'btn-3d-pink' : 'btn-3d-cloud text-[#7965A5]'
                }`}
              >
                <Pin className="w-4 h-4" />
              </button>
              <SiliconeButton type="submit" variant="lavender" className="flex-1 sm:flex-initial">
                <Send className="w-4 h-4" />
                <span>{t('dashboard.postNote')}</span>
              </SiliconeButton>
            </div>
          </form>

          {sortedNotes.length === 0 ? (
            <EmptyState
              iconKind="notes"
              title={t('dashboard.emptyNotesTitle')}
              description={t('dashboard.emptyNotesDesc')}
            />
          ) : (
            <div className="space-y-2.5">
              {sortedNotes.map((note) => {
                const author = residentMap.get(note.authorId);
                const isEditing = editingNote?.id === note.id;
                return (
                  <div
                    key={note.id}
                    className={`rounded-2xl p-3.5 ${
                      note.pinned
                        ? 'bg-[#FFF8FF] border border-[#ED82BE]/60 shadow-sm'
                        : 'surface-inset'
                    }`}
                  >
                    {isEditing ? (
                      <form
                        onSubmit={(e) => void handleSaveEditNote(e)}
                        className="flex flex-col sm:flex-row gap-2"
                      >
                        <input
                          type="text"
                          value={editNoteText}
                          onChange={(e) => setEditNoteText(e.target.value)}
                          className="flex-1 min-h-[42px] px-3 py-2 rounded-xl surface-inset text-sm text-[#38216B]"
                        />
                        <div className="flex gap-2">
                          <SiliconeButton
                            type="submit"
                            variant="lavender"
                            className="min-h-[42px] py-1.5 px-3 text-xs"
                          >
                            {t('common.save')}
                          </SiliconeButton>
                          <SiliconeButton
                            variant="cloud"
                            onClick={() => setEditingNote(null)}
                            className="min-h-[42px] py-1.5 px-3 text-xs"
                          >
                            {t('common.cancel')}
                          </SiliconeButton>
                        </div>
                      </form>
                    ) : (
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-2.5 min-w-0">
                          <Avatar resident={author} size="xs" />
                          <div className="min-w-0">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="text-xs font-bold text-[#4C269A]">
                                {author?.name ?? t('common.partnerFallback')}
                              </span>
                              {note.pinned && (
                                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#FCE0F0] text-[#B33981]">
                                  {t('dashboard.pinnedTag')}
                                </span>
                              )}
                              <span className="text-[10px] font-mono-num text-[#7965A5]">
                                {formatLocalizedDateTime(
                                  note.createdAt,
                                  locale,
                                  state.timeZone
                                )}
                              </span>
                            </div>
                            <p className="text-sm text-[#38216B] mt-1 leading-relaxed">
                              {note.content}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => void onTogglePinNote(note.id)}
                            aria-label={
                              note.pinned
                                ? t('dashboard.unpinNoteAria')
                                : t('dashboard.pinNoteAria')
                            }
                            className="min-h-[38px] min-w-[38px] rounded-xl hover:bg-white/70 inline-flex items-center justify-center text-[#7965A5]"
                          >
                            {note.pinned ? (
                              <PinOff className="w-3.5 h-3.5 text-[#ED82BE]" />
                            ) : (
                              <Pin className="w-3.5 h-3.5" />
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingNote(note);
                              setEditNoteText(note.content);
                            }}
                            aria-label={t('dashboard.editNoteAria')}
                            className="min-h-[38px] min-w-[38px] rounded-xl hover:bg-white/70 inline-flex items-center justify-center text-[#7965A5]"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteNote(note)}
                            aria-label={t('dashboard.deleteNoteAria')}
                            className="min-h-[38px] min-w-[38px] rounded-xl hover:bg-white/70 inline-flex items-center justify-center text-[#B33981]"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </ClayCard>
      </div>

      <ConfirmModal
        open={Boolean(confirmDeleteNote)}
        title={t('dashboard.deleteNoteTitle')}
        description={t('dashboard.deleteNoteDesc')}
        confirmLabel={t('common.delete')}
        onConfirm={() => {
          if (confirmDeleteNote) {
            void onDeletePinNote(confirmDeleteNote.id);
          }
          setConfirmDeleteNote(null);
        }}
        onCancel={() => setConfirmDeleteNote(null)}
      />
    </div>
  );
}
