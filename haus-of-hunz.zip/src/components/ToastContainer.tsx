import { AnimatePresence, motion } from 'motion/react';
import { CheckCircle2, Info, Sparkles, X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { ToastMessage } from '../types/household';

interface ToastContainerProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export function ToastContainer({ toasts, onDismiss }: ToastContainerProps) {
  const { t } = useTranslation();

  return (
    <div
      aria-live="polite"
      className="fixed bottom-24 left-4 right-4 z-50 flex flex-col items-center gap-2 pointer-events-none lg:bottom-auto lg:top-6 lg:left-auto lg:right-6 lg:w-96 lg:items-end"
    >
      <AnimatePresence initial={false}>
        {toasts.map((toast) => (
          <motion.div
            key={toast.id}
            initial={{ opacity: 0, y: 18, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.95 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
            style={{
              background:
                toast.tone === 'pink'
                  ? 'linear-gradient(145deg, #5F33B5 0%, #4C269A 100%)'
                  : 'linear-gradient(145deg, #4C269A 0%, #38216B 100%)',
              boxShadow:
                '0 18px 32px -10px rgba(56, 33, 107, 0.45), inset 0 1.5px 2px rgba(255, 255, 255, 0.28)',
            }}
            className="pointer-events-auto w-full max-w-sm text-[#FFF8FF] rounded-[22px] px-4 py-3.5 border border-white/25 flex items-start gap-3"
          >
            <div className="mt-0.5 shrink-0">
              {toast.tone === 'pink' ? (
                <Sparkles className="w-5 h-5 text-[#F5B5DA]" />
              ) : toast.tone === 'lavender' ? (
                <CheckCircle2 className="w-5 h-5 text-[#C5A6F5]" />
              ) : (
                <Info className="w-5 h-5 text-[#EADCF8]" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-semibold leading-snug text-[#FFF8FF]">
                  {toast.title}
                </p>
                {toast.pointsBadge && (
                  <span className="shrink-0 font-mono-num text-xs font-semibold text-[#FFC3A6]">
                    {toast.pointsBadge}
                  </span>
                )}
              </div>
              {toast.subtitle && (
                <p className="text-xs text-[#EADCF8] mt-0.5 leading-relaxed">
                  {toast.subtitle}
                </p>
              )}
            </div>
            <button
              type="button"
              onClick={() => onDismiss(toast.id)}
              aria-label={t('common.close')}
              className="shrink-0 -mr-1 -mt-1 p-1.5 text-[#C5A6F5] hover:text-white rounded-full transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
