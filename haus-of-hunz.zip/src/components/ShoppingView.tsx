import { FormEvent, useMemo, useState } from 'react';
import {
  Check,
  Edit3,
  Layers,
  List,
  Plus,
  RotateCcw,
  Trash2,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import {
  HouseholdState,
  Resident,
  ShoppingCategory,
  ShoppingItem,
  ShoppingUnit,
} from '../types/household';
import { Avatar } from './Avatar';
import {
  ClayCard,
  ConfirmModal,
  EmptyState,
  SiliconeButton,
} from './ui/ClayPrimitives';
import { Mascot } from './ui/Mascots';
import { ThreeDIcon } from './ui/ThreeDIcons';

interface ShoppingViewProps {
  state: HouseholdState;
  onAddShoppingItem: (payload: {
    name: string;
    quantity: number;
    unit: ShoppingUnit;
    category: ShoppingCategory;
  }) => Promise<void>;
  onUpdateShoppingItem: (
    itemId: string,
    updates: {
      name?: string;
      quantity?: number;
      unit?: ShoppingUnit;
      category?: ShoppingCategory;
    }
  ) => Promise<void>;
  onMarkBought: (itemId: string) => Promise<void>;
  onRestoreShoppingItem: (itemId: string) => Promise<void>;
  onDeleteShoppingItem: (itemId: string) => Promise<void>;
}

const CATEGORIES: ShoppingCategory[] = [
  'Mercado',
  'Limpeza',
  'Padaria',
  'Hortifruti',
  'Casa',
];

const UNITS: ShoppingUnit[] = ['un', 'kg', 'g', 'L', 'ml', 'pct', 'cx'];

export function ShoppingView({
  state,
  onAddShoppingItem,
  onUpdateShoppingItem,
  onMarkBought,
  onRestoreShoppingItem,
  onDeleteShoppingItem,
}: ShoppingViewProps) {
  const { t } = useTranslation();

  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState<string>('1');
  const [unit, setUnit] = useState<ShoppingUnit>('un');
  const [category, setCategory] = useState<ShoppingCategory>('Mercado');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [activeCatFilter, setActiveCatFilter] = useState<
    ShoppingCategory | 'all'
  >('all');
  const [groupByCat, setGroupByCat] = useState(false);
  const [confirmDeleteItem, setConfirmDeleteItem] =
    useState<ShoppingItem | null>(null);

  const residentMap = useMemo(() => {
    const map = new Map<string, Resident>();
    state.residents.forEach((r) => map.set(r.id, r));
    return map;
  }, [state.residents]);

  const pendingItems = useMemo(
    () =>
      state.shoppingItems.filter(
        (i) =>
          i.status === 'pending' &&
          (activeCatFilter === 'all' || i.category === activeCatFilter)
      ),
    [state.shoppingItems, activeCatFilter]
  );

  const boughtItems = useMemo(
    () => state.shoppingItems.filter((i) => i.status === 'bought'),
    [state.shoppingItems]
  );

  const totalPendingCount = useMemo(
    () => state.shoppingItems.filter((i) => i.status === 'pending').length,
    [state.shoppingItems]
  );

  const groupedPending = useMemo(() => {
    const groups = new Map<ShoppingCategory, ShoppingItem[]>();
    for (const item of pendingItems) {
      const list = groups.get(item.category) || [];
      list.push(item);
      groups.set(item.category, list);
    }
    return Array.from(groups.entries());
  }, [pendingItems]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const qty = Math.max(0.1, Number(quantity.replace(',', '.')) || 1);

    if (editingId) {
      await onUpdateShoppingItem(editingId, {
        name: name.trim(),
        quantity: qty,
        unit,
        category,
      });
      setEditingId(null);
    } else {
      await onAddShoppingItem({
        name: name.trim(),
        quantity: qty,
        unit,
        category,
      });
    }

    setName('');
    setQuantity('1');
  };

  const startEdit = (item: ShoppingItem) => {
    setEditingId(item.id);
    setName(item.name);
    setQuantity(String(item.quantity));
    setUnit(item.unit);
    setCategory(item.category);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setName('');
    setQuantity('1');
    setUnit('un');
    setCategory('Mercado');
  };

  const renderPendingRow = (item: ShoppingItem) => {
    const author = residentMap.get(item.authorId);
    return (
      <div
        key={item.id}
        className="surface-inset rounded-2xl p-3.5 flex items-center justify-between gap-3"
      >
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => void onMarkBought(item.id)}
            aria-label={t('shopping.markBoughtAria', { name: item.name })}
            className="btn-3d-cloud min-h-[42px] min-w-[42px] rounded-2xl inline-flex items-center justify-center shrink-0 text-[#4C269A]"
          >
            <Check className="w-4 h-4" />
          </button>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-sm font-semibold text-[#38216B] truncate">
                {item.name}
              </p>
              <span className="font-mono-num text-xs font-bold px-2 py-0.5 rounded-full bg-[#FFF8FF] text-[#4C269A]">
                {item.quantity} {t(`shopping.units.${item.unit}`)}
              </span>
            </div>
            <div className="flex items-center gap-2 mt-1 text-xs text-[#7965A5]">
              <Avatar resident={author} size="xs" />
              <span>{author?.name ?? t('common.partnerFallback')}</span>
              <span>·</span>
              <span>{t(`shopping.categories.${item.category}`)}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => startEdit(item)}
            aria-label={t('shopping.editItemAria', { name: item.name })}
            className="min-h-[40px] min-w-[40px] rounded-xl hover:bg-white/70 inline-flex items-center justify-center text-[#7965A5]"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => setConfirmDeleteItem(item)}
            aria-label={t('shopping.removeItemAria', { name: item.name })}
            className="min-h-[40px] min-w-[40px] rounded-xl hover:bg-white/70 inline-flex items-center justify-center text-[#B33981]"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <ThreeDIcon kind="shopping" size="lg" />
          <div>
            <h1 className="font-editorial text-2xl sm:text-3xl font-bold text-[#38216B]">
              {t('shopping.pageTitle')}
            </h1>
            <p className="text-xs sm:text-sm text-[#7965A5]">
              {t('shopping.pageSubtitle')}
            </p>
          </div>
        </div>

        <SiliconeButton
          variant="cloud"
          onClick={() => setGroupByCat((prev) => !prev)}
        >
          {groupByCat ? (
            <>
              <List className="w-4 h-4" />
              <span>{t('shopping.groupedOff')}</span>
            </>
          ) : (
            <>
              <Layers className="w-4 h-4" />
              <span>{t('shopping.groupedOn')}</span>
            </>
          )}
        </SiliconeButton>
      </div>

      {/* Grocery Diva Banner */}
      <ClayCard variant="glass" className="p-4 flex items-center gap-3.5">
        <Mascot
          id="grocery-diva"
          mood={totalPendingCount === 0 ? 'celebrating' : 'proud'}
          size="sm"
        />
        <p className="text-xs sm:text-sm font-medium text-[#4C269A]">
          {totalPendingCount === 0
            ? t('shopping.divaCheering')
            : t('dashboard.pendingShopping', { count: totalPendingCount })}
        </p>
      </ClayCard>

      {/* Add / Edit Form */}
      <ClayCard className="p-5 sm:p-6 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <h2 className="font-editorial text-xl font-bold text-[#38216B]">
            {editingId
              ? t('shopping.editingItem', { name })
              : t('shopping.addItemTitle')}
          </h2>
          {editingId && (
            <button
              type="button"
              onClick={cancelEdit}
              className="text-xs font-semibold text-[#B33981] hover:underline"
            >
              {t('shopping.cancelEdit')}
            </button>
          )}
        </div>

        <form
          onSubmit={(e) => void handleSubmit(e)}
          className="grid grid-cols-1 sm:grid-cols-12 gap-3"
        >
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            aria-label={t('shopping.nameAria')}
            placeholder={t('shopping.namePlaceholder')}
            required
            className="sm:col-span-5 min-h-[46px] px-4 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
          />

          <input
            type="number"
            min="0.1"
            step="0.1"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            aria-label={t('shopping.qtyAria')}
            placeholder={t('shopping.qtyPlaceholder')}
            className="sm:col-span-2 min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm font-mono-num text-[#38216B]"
          />

          <select
            value={unit}
            onChange={(e) => setUnit(e.target.value as ShoppingUnit)}
            aria-label={t('shopping.unitAria')}
            className="sm:col-span-2 min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
          >
            {UNITS.map((u) => (
              <option key={u} value={u}>
                {t(`shopping.units.${u}`)}
              </option>
            ))}
          </select>

          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as ShoppingCategory)}
            aria-label={t('shopping.categoryAria')}
            className="sm:col-span-3 min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {t(`shopping.categories.${c}`)}
              </option>
            ))}
          </select>

          <div className="sm:col-span-12 flex justify-end">
            <SiliconeButton type="submit" variant="lavender">
              <Plus className="w-4 h-4" />
              <span>{editingId ? t('common.save') : t('common.add')}</span>
            </SiliconeButton>
          </div>
        </form>
      </ClayCard>

      {/* Category Filter Pills */}
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setActiveCatFilter('all')}
          className={`min-h-[40px] px-4 py-1.5 rounded-2xl text-xs font-semibold transition-all ${
            activeCatFilter === 'all'
              ? 'btn-3d-lavender'
              : 'btn-3d-cloud text-[#4C269A]'
          }`}
        >
          {t('shopping.allCategories')}
        </button>
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setActiveCatFilter(cat)}
            className={`min-h-[40px] px-4 py-1.5 rounded-2xl text-xs font-semibold transition-all ${
              activeCatFilter === cat
                ? 'btn-3d-lavender'
                : 'btn-3d-cloud text-[#4C269A]'
            }`}
          >
            {t(`shopping.categories.${cat}`)}
          </button>
        ))}
      </div>

      {/* Main Split Grid: To Pick Up & Recently Picked Up */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <ClayCard className="lg:col-span-7 p-5 sm:p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-editorial text-xl font-bold text-[#38216B]">
              {t('shopping.needToBuy')}
            </h2>
            <span className="font-mono-num text-xs font-bold text-[#7965A5]">
              {t('common.itemCount', { count: pendingItems.length })}
            </span>
          </div>

          {pendingItems.length === 0 ? (
            <EmptyState
              iconKind="shopping"
              title={t('shopping.emptyPendingTitle')}
              description={t('shopping.emptyPendingDesc')}
            />
          ) : groupByCat ? (
            <div className="space-y-4">
              {groupedPending.map(([cat, list]) => (
                <div key={cat} className="space-y-2">
                  <p className="text-xs font-bold uppercase tracking-wider text-[#9672E8]">
                    {t(`shopping.categories.${cat}`)}
                  </p>
                  <div className="space-y-2">{list.map(renderPendingRow)}</div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-2.5">
              {pendingItems.map(renderPendingRow)}
            </div>
          )}
        </ClayCard>

        <ClayCard className="lg:col-span-5 p-5 sm:p-6 space-y-4">
          <div>
            <h2 className="font-editorial text-xl font-bold text-[#38216B]">
              {t('shopping.recentlyBought')}
            </h2>
            <p className="text-xs text-[#7965A5]">
              {t('shopping.recentlyBoughtSubtitle')}
            </p>
          </div>

          {boughtItems.length === 0 ? (
            <EmptyState
              iconKind="rewards"
              title={t('shopping.emptyBoughtTitle')}
              description={t('shopping.emptyBoughtDesc')}
            />
          ) : (
            <div className="space-y-2.5">
              {boughtItems.map((item) => {
                const buyer = item.buyerId
                  ? residentMap.get(item.buyerId)
                  : residentMap.get(item.authorId);
                return (
                  <div
                    key={item.id}
                    className="surface-inset rounded-2xl p-3.5 flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#38216B] line-through decoration-[#9672E8]/60 truncate">
                        {item.name}
                      </p>
                      <p className="text-xs text-[#7965A5] mt-0.5">
                        {item.quantity} {t(`shopping.units.${item.unit}`)} ·{' '}
                        {t('shopping.boughtBy', {
                          name: buyer?.name ?? t('common.partnerFallback'),
                        })}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <SiliconeButton
                        variant="cloud"
                        onClick={() => void onRestoreShoppingItem(item.id)}
                        className="min-h-[38px] py-1.5 px-3 text-xs"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>{t('common.restore')}</span>
                      </SiliconeButton>
                      <button
                        type="button"
                        onClick={() => setConfirmDeleteItem(item)}
                        aria-label={t('shopping.removeItemAria', {
                          name: item.name,
                        })}
                        className="min-h-[38px] min-w-[38px] rounded-xl hover:bg-white/70 inline-flex items-center justify-center text-[#B33981]"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ClayCard>
      </div>

      <ConfirmModal
        open={Boolean(confirmDeleteItem)}
        title={t('shopping.deleteTitle')}
        description={t('shopping.deleteDesc', {
          name: confirmDeleteItem?.name ?? '',
        })}
        confirmLabel={t('common.remove')}
        onConfirm={() => {
          if (confirmDeleteItem) {
            void onDeleteShoppingItem(confirmDeleteItem.id);
          }
          setConfirmDeleteItem(null);
        }}
        onCancel={() => setConfirmDeleteItem(null)}
      />
    </div>
  );
}
