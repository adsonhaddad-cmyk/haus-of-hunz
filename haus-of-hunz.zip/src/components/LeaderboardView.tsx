import { useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Award, Crown, Flame, History, Sparkles, Trophy, X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import ballroomStageImg from '../assets/images/ballroom_trophy_stage_1794694183326.jpg';
import { HouseholdState, Resident } from '../types/household';
import { formatLocalizedDateTime, getISOWeekKey } from '../utils/dates';
import {
  buildWeeklyCeremonySummary,
  evaluateResidentAchievements,
} from '../utils/gameEngine';
import { Avatar } from './Avatar';
import {
  ClayCard,
  ClayProgressBar,
  SiliconeButton,
} from './ui/ClayPrimitives';
import { Mascot } from './ui/Mascots';
import { ThreeDIcon } from './ui/ThreeDIcons';

interface LeaderboardViewProps {
  state: HouseholdState;
  activeResident: Resident;
  onlineResidentIds: string[];
}

export function LeaderboardView({
  state,
  activeResident,
  onlineResidentIds,
}: LeaderboardViewProps) {
  const { t, i18n } = useTranslation();
  const locale = i18n.language;
  const currentWeek = getISOWeekKey();
  const [ceremonyOpen, setCeremonyOpen] = useState(false);

  const residentMap = useMemo(() => {
    const map = new Map<string, Resident>();
    state.residents.forEach((r) => map.set(r.id, r));
    return map;
  }, [state.residents]);

  const weeklySummary = useMemo(
    () => buildWeeklyCeremonySummary(state, currentWeek),
    [state, currentWeek]
  );

  const achievements = useMemo(
    () => evaluateResidentAchievements(activeResident, state),
    [activeResident, state]
  );

  const weeklyGoal = Math.max(20, state.preferences.weeklyPointsGoal || 150);
  const leaderResident = weeklySummary.winnerId
    ? residentMap.get(weeklySummary.winnerId)
    : undefined;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <ThreeDIcon kind="achievements" size="lg" />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-editorial text-2xl sm:text-3xl font-bold text-[#38216B]">
                {t('leaderboard.pageTitle')}
              </h1>
              <span className="font-mono-num text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#EADCF8] text-[#4C269A]">
                {t('leaderboard.weekTag', { week: currentWeek })}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-[#7965A5]">
              {t('leaderboard.pageSubtitle')}
            </p>
          </div>
        </div>

        <SiliconeButton
          variant="pink"
          onClick={() => setCeremonyOpen(true)}
        >
          <Crown className="w-4 h-4" />
          <span>{t('leaderboard.openCeremonyBtn')}</span>
        </SiliconeButton>
      </div>

      {/* Spotlight Banner with Sir Scrub-a-Lot */}
      <ClayCard className="p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <Mascot
            id="sir-scrub"
            mood={weeklySummary.totalCompleted > 0 ? 'celebrating' : 'idle'}
            size="lg"
          />
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-[#9672E8]">
              {t('leaderboard.weekTag', { week: currentWeek })}
            </p>
            <h2 className="font-editorial text-xl sm:text-2xl font-bold text-[#38216B] mt-0.5">
              {weeklySummary.isTie
                ? t('leaderboard.tiedMessage')
                : leaderResident
                  ? t('leaderboard.leadingMessage', {
                      name: leaderResident.name,
                    })
                  : t('leaderboard.noPointsYet')}
            </h2>
          </div>
        </div>
        {leaderResident && (
          <div className="flex items-center gap-2.5 surface-inset px-4 py-2.5 rounded-2xl shrink-0">
            <Crown className="w-5 h-5 text-[#E89B3C]" />
            <Avatar
              resident={leaderResident}
              size="sm"
              showOnlineDot={onlineResidentIds.includes(leaderResident.id)}
            />
            <span className="font-bold text-sm text-[#4C269A]">
              {leaderResident.name}
            </span>
          </div>
        )}
      </ClayCard>

      {/* Weekly Standings Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {weeklySummary.standings.map((entry, idx) => {
          const resident = residentMap.get(entry.residentId);
          if (!resident) return null;
          const pct = Math.min(
            100,
            Math.round((entry.earnedPoints / weeklyGoal) * 100)
          );
          const isLeader =
            (idx === 0 && entry.earnedPoints > 0 && !weeklySummary.isTie) ||
            (weeklySummary.isTie && entry.earnedPoints > 0);

          return (
            <ClayCard
              key={resident.id}
              className={`p-5 sm:p-6 space-y-4 ${
                isLeader ? 'border-[#ED82BE]/70' : ''
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative">
                    <Avatar
                      resident={resident}
                      size="lg"
                      showOnlineDot={onlineResidentIds.includes(resident.id)}
                    />
                    <span className="absolute -top-1.5 -left-1.5 w-6 h-6 rounded-full btn-3d-lavender text-[11px] font-mono-num font-bold inline-flex items-center justify-center">
                      #{idx + 1}
                    </span>
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-editorial text-xl font-bold text-[#38216B] truncate">
                        {resident.name}
                      </h3>
                      {isLeader && (
                        <Crown className="w-4 h-4 text-[#E89B3C] shrink-0" />
                      )}
                    </div>
                    <p className="text-xs text-[#7965A5] flex items-center gap-1.5 mt-0.5">
                      <Flame className="w-3.5 h-3.5 text-[#ED82BE]" />
                      <span className="font-mono-num">
                        {t('dashboard.streakCount', { count: resident.streak })}
                      </span>
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <p className="font-mono-num text-2xl font-bold text-[#4C269A]">
                    {entry.earnedPoints}
                  </p>
                  <p className="text-[11px] font-semibold text-[#7965A5]">
                    {t('common.pts')}
                  </p>
                </div>
              </div>

              <ClayProgressBar
                percent={pct}
                color={
                  idx === 0
                    ? 'linear-gradient(90deg, #9672E8 0%, #ED82BE 100%)'
                    : 'linear-gradient(90deg, #8EA8F5 0%, #C5A6F5 100%)'
                }
              />

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                <div className="surface-inset rounded-xl p-2">
                  <p className="font-mono-num text-sm font-bold text-[#38216B]">
                    {entry.completedCount}
                  </p>
                  <p className="text-[11px] text-[#7965A5]">
                    {t('leaderboard.completedStat', {
                      count: entry.completedCount,
                    }).replace(String(entry.completedCount), '').trim()}
                  </p>
                </div>
                <div className="surface-inset rounded-xl p-2">
                  <p className="font-mono-num text-sm font-bold text-[#1C7C54]">
                    {entry.onTimeCount}
                  </p>
                  <p className="text-[11px] text-[#7965A5]">
                    {t('leaderboard.onTimeStat', {
                      count: entry.onTimeCount,
                    }).replace(String(entry.onTimeCount), '').trim()}
                  </p>
                </div>
                <div className="surface-inset rounded-xl p-2">
                  <p className="font-mono-num text-sm font-bold text-[#B33981]">
                    {entry.overdueCount}
                  </p>
                  <p className="text-[11px] text-[#7965A5]">
                    {t('leaderboard.overdueStat', {
                      count: entry.overdueCount,
                    }).replace(String(entry.overdueCount), '').trim()}
                  </p>
                </div>
                <div className="surface-inset rounded-xl p-2">
                  <p className="font-mono-num text-sm font-bold text-[#9F2E71]">
                    -{entry.penaltyPoints}
                  </p>
                  <p className="text-[11px] text-[#7965A5]">
                    {t('common.pts')}
                  </p>
                </div>
              </div>
            </ClayCard>
          );
        })}
      </div>

      {/* 10 Ballroom Honors & Badges */}
      <ClayCard className="p-5 sm:p-6 space-y-4">
        <div className="flex items-center gap-3">
          <ThreeDIcon kind="rewards" size="md" />
          <div>
            <h2 className="font-editorial text-xl font-bold text-[#38216B]">
              {t('leaderboard.achievementsTitle')}
            </h2>
            <p className="text-xs text-[#7965A5]">
              {t('leaderboard.achievementsSubtitle')} ({activeResident.name})
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {achievements.map((badge) => {
            const pct = Math.round(
              (badge.progressCurrent / Math.max(1, badge.progressTarget)) * 100
            );
            return (
              <div
                key={badge.id}
                className={`rounded-2xl p-3.5 flex flex-col justify-between gap-2.5 border transition-all ${
                  badge.unlocked
                    ? 'bg-[#FFF8FF] border-[#ED82BE]/70 shadow-sm'
                    : 'surface-inset border-transparent opacity-80'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`w-8 h-8 rounded-xl inline-flex items-center justify-center ${
                        badge.unlocked
                          ? 'btn-3d-pink'
                          : 'bg-[#EADCF8] text-[#7965A5]'
                      }`}
                    >
                      {badge.unlocked ? (
                        <Trophy className="w-4 h-4" />
                      ) : (
                        <Award className="w-4 h-4" />
                      )}
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                        badge.unlocked
                          ? 'bg-[#FCE0F0] text-[#B33981]'
                          : 'bg-white/70 text-[#7965A5]'
                      }`}
                    >
                      {badge.unlocked
                        ? t('leaderboard.unlockedLabel')
                        : t('leaderboard.lockedLabel')}
                    </span>
                  </div>
                  <p className="font-editorial text-base font-bold text-[#38216B] pt-1">
                    {t(badge.titleKey)}
                  </p>
                  <p className="text-xs text-[#7965A5] leading-snug">
                    {t(badge.descKey)}
                  </p>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-mono-num font-semibold text-[#4C269A]">
                    <span>
                      {t(badge.progressKey, {
                        current: badge.progressCurrent,
                        target: badge.progressTarget,
                      })}
                    </span>
                    <span>{pct}%</span>
                  </div>
                  <ClayProgressBar percent={pct} />
                </div>
              </div>
            );
          })}
        </div>
      </ClayCard>

      {/* Immutable Point & Penalty Ledger */}
      <ClayCard className="p-5 sm:p-6 space-y-4">
        <div className="flex items-center gap-3">
          <span className="w-10 h-10 rounded-2xl btn-3d-lavender inline-flex items-center justify-center shrink-0">
            <History className="w-5 h-5" />
          </span>
          <h2 className="font-editorial text-xl font-bold text-[#38216B]">
            {t('leaderboard.ledgerTitle')}
          </h2>
        </div>

        {state.pointLedger.length === 0 ? (
          <p className="text-xs text-[#7965A5] surface-inset rounded-2xl p-4">
            {t('leaderboard.ledgerEmpty')}
          </p>
        ) : (
          <div className="space-y-2">
            {state.pointLedger.slice(0, 20).map((tx) => {
              const who = residentMap.get(tx.residentId);
              return (
                <div
                  key={tx.id}
                  className="surface-inset rounded-2xl px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <Avatar resident={who} size="xs" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-[#38216B] truncate">
                        {who?.name ?? t('common.partnerFallback')} ·{' '}
                        {tx.taskTitle}
                      </p>
                      <p className="text-xs text-[#7965A5] font-mono-num">
                        {formatLocalizedDateTime(
                          tx.createdAt,
                          locale,
                          state.timeZone
                        )}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
                    {tx.penaltyDeducted > 0 && (
                      <span className="font-mono-num text-xs font-semibold px-2.5 py-0.5 rounded-full bg-[#FCE0F0] text-[#B33981]">
                        -{tx.penaltyPercent}% (-{tx.penaltyDeducted}{' '}
                        {t('common.pts')})
                      </span>
                    )}
                    <span className="font-mono-num text-sm font-bold px-3 py-1 rounded-full bg-[#FFF8FF] text-[#4C269A]">
                      +{tx.pointsDelta} {t('common.pts')}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ClayCard>

      {/* Weekly Ballroom Ceremony Modal */}
      <AnimatePresence>
        {ceremonyOpen && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setCeremonyOpen(false)}
              className="fixed inset-0 bg-[#38216B]/55 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, y: 28, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 18, scale: 0.96 }}
              transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
              className="relative z-10 w-full sm:max-w-xl surface-clay rounded-t-[32px] sm:rounded-[32px] overflow-hidden"
            >
              <div className="relative h-48 sm:h-56 overflow-hidden">
                <img
                  src={ballroomStageImg}
                  alt={t('leaderboard.ceremonyTitle')}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#38216B]/95 via-[#4C269A]/40 to-transparent" />
                <button
                  type="button"
                  onClick={() => setCeremonyOpen(false)}
                  aria-label={t('common.close')}
                  className="absolute top-4 right-4 btn-3d-cloud min-h-[40px] min-w-[40px] rounded-full inline-flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
                <div className="absolute bottom-4 left-5 right-5 flex items-end justify-between gap-3">
                  <div>
                    <p className="text-[11px] font-bold uppercase tracking-widest text-[#F5B5DA]">
                      {t('leaderboard.ceremonySubtitle', { week: currentWeek })}
                    </p>
                    <h2 className="font-editorial text-2xl sm:text-3xl font-bold text-[#FFF8FF]">
                      {t('leaderboard.ceremonyTitle')}
                    </h2>
                  </div>
                  <Mascot id="miss-mop" mood="celebrating" size="md" />
                </div>
              </div>

              <div className="p-6 space-y-5">
                <div className="flex items-center gap-3 surface-inset rounded-2xl p-4">
                  <Sparkles className="w-5 h-5 text-[#ED82BE] shrink-0" />
                  <p className="font-editorial text-lg font-bold text-[#4C269A]">
                    {weeklySummary.isTie
                      ? t('leaderboard.ceremonyTieCallout')
                      : leaderResident
                        ? `${leaderResident.name} — ${t('leaderboard.ceremonyWinnerCallout')}`
                        : t('leaderboard.noPointsYet')}
                  </p>
                </div>

                <div className="space-y-2.5">
                  {weeklySummary.standings.map((entry, idx) => {
                    const resident = residentMap.get(entry.residentId);
                    if (!resident) return null;
                    return (
                      <div
                        key={resident.id}
                        className="surface-inset rounded-2xl p-3.5 flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <span className="font-mono-num text-sm font-bold text-[#9672E8]">
                            #{idx + 1}
                          </span>
                          <Avatar resident={resident} size="sm" />
                          <div>
                            <p className="text-sm font-bold text-[#38216B]">
                              {resident.name}
                            </p>
                            <p className="text-xs text-[#7965A5]">
                              {t('leaderboard.completedStat', {
                                count: entry.completedCount,
                              })}{' '}
                              ·{' '}
                              {t('leaderboard.onTimeStat', {
                                count: entry.onTimeCount,
                              })}
                            </p>
                          </div>
                        </div>
                        <span className="font-mono-num text-lg font-bold text-[#4C269A]">
                          {entry.earnedPoints} {t('common.pts')}
                        </span>
                      </div>
                    );
                  })}
                </div>

                <SiliconeButton
                  variant="lavender"
                  onClick={() => setCeremonyOpen(false)}
                  className="w-full"
                >
                  {t('leaderboard.ceremonyClose')}
                </SiliconeButton>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
