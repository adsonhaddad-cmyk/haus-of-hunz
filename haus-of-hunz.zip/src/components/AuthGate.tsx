import { FormEvent, useState } from 'react';
import type { User as FirebaseUser } from 'firebase/auth';
import {
  Check,
  Globe,
  KeyRound,
  LogOut,
  Sparkles,
  UserCheck,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import heroBallroomImg from '../assets/images/house_hero_ballroom_1794694182411.jpg';
import { SupportedLocale } from '../i18n';
import { ClayCard, SiliconeButton } from './ui/ClayPrimitives';
import { HausWordmark } from './ui/HausWordmark';
import { Mascot } from './ui/Mascots';

interface AuthGateProps {
  firebaseUser: FirebaseUser | null;
  needsOnboarding: boolean;
  defaultInviteExists: boolean | null;
  isMutating: boolean;
  authError: string | null;
  onSignInWithGoogle: () => Promise<boolean>;
  onLaunchHouse: (
    chosenResidentId: 'res-adson' | 'res-arty',
    displayName?: string
  ) => Promise<boolean>;
  onJoinHouse: (payload: {
    inviteCode: string;
    preferredSlot: 'res-arty' | 'res-adson' | 'custom';
    displayName?: string;
  }) => Promise<boolean>;
  onLogout: () => Promise<void>;
  onChangeLanguage: (locale: SupportedLocale) => void;
}

export function AuthGate({
  firebaseUser,
  needsOnboarding,
  defaultInviteExists,
  isMutating,
  authError,
  onSignInWithGoogle,
  onLaunchHouse,
  onJoinHouse,
  onLogout,
  onChangeLanguage,
}: AuthGateProps) {
  const { t, i18n } = useTranslation();

  const [launchSlot, setLaunchSlot] = useState<'res-adson' | 'res-arty'>(
    'res-adson'
  );
  const [joinSlot, setJoinSlot] = useState<'res-arty' | 'res-adson' | 'custom'>(
    'res-arty'
  );
  const [inviteCode, setInviteCode] = useState('HOUSE-TENS');
  const [displayName, setDisplayName] = useState('');

  const handleLaunchSubmit = async (e: FormEvent) => {
    e.preventDefault();
    await onLaunchHouse(launchSlot, displayName.trim() || undefined);
  };

  const handleJoinSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!inviteCode.trim()) return;
    await onJoinHouse({
      inviteCode: inviteCode.trim().toUpperCase(),
      preferredSlot: joinSlot,
      displayName: displayName.trim() || undefined,
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-6">
      <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Left Brand Showcase Card */}
        <ClayCard className="lg:col-span-6 overflow-hidden flex flex-col justify-between relative min-h-[260px]">
          <div className="relative h-56 sm:h-64 lg:h-72 overflow-hidden">
            <img
              src={heroBallroomImg}
              alt={t('common.brandName')}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#38216B]/90 via-[#4C269A]/35 to-transparent" />
            <div className="absolute top-4 right-4 flex items-center gap-1.5">
              <button
                type="button"
                onClick={() =>
                  onChangeLanguage(i18n.language === 'pt-BR' ? 'en-US' : 'pt-BR')
                }
                className="min-h-[38px] px-3 py-1.5 rounded-full btn-3d-cloud text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Globe className="w-3.5 h-3.5 text-[#9672E8]" />
                {i18n.language === 'pt-BR' ? 'PT-BR' : 'EN-US'}
              </button>
            </div>
            <div className="absolute bottom-4 left-5 right-5 flex items-end justify-between gap-3">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-widest text-[#F5B5DA] mb-1">
                  Adson & Arty
                </p>
                <h1 className="sr-only">{t('auth.welcomeTitle')}</h1>
                <HausWordmark
                  variant="hero"
                  tone="light"
                  showCrest={false}
                  showTagline
                  tagline={t('auth.welcomeSubtitle')}
                />
              </div>
              <Mascot id="miss-mop" mood="proud" size="md" className="shrink-0" />
            </div>
          </div>

          <div className="p-5 sm:p-6 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#9672E8]">
              <Sparkles className="w-4 h-4 text-[#ED82BE]" />
              <span>{t('auth.quickDemoHeading')}</span>
            </div>
            <p className="text-xs text-[#7965A5] leading-relaxed">
              {t('auth.quickDemoNote')}
            </p>
          </div>
        </ClayCard>

        {/* Right Firebase Google Auth / Onboarding Card */}
        <ClayCard className="lg:col-span-6 p-6 sm:p-7 flex flex-col justify-center space-y-5">
          {authError && (
            <div
              role="alert"
              className="px-4 py-3 rounded-2xl bg-[#FCE0F0] border border-[#ED82BE]/60 text-xs font-semibold text-[#9F2E71]"
            >
              {authError}
            </div>
          )}

          {!firebaseUser || !needsOnboarding ? (
            <div className="space-y-5">
              <div className="space-y-2">
                <h2 className="font-editorial text-2xl font-bold text-[#38216B]">
                  {t('auth.signInTab')}
                </h2>
                <p className="text-xs sm:text-sm text-[#7965A5] leading-relaxed">
                  {t('auth.googleSignInHint')}
                </p>
              </div>

              <SiliconeButton
                type="button"
                variant="lavender"
                disabled={isMutating}
                onClick={() => void onSignInWithGoogle()}
                className="w-full min-h-[52px] text-sm sm:text-base"
              >
                <svg
                  className="w-5 h-5 shrink-0"
                  viewBox="0 0 24 24"
                  aria-hidden="true"
                >
                  <path
                    fill="currentColor"
                    d="M21.35 11.1h-9.17v2.98h5.27c-.23 1.47-1.69 4.31-5.27 4.31-3.17 0-5.76-2.62-5.76-5.86s2.59-5.86 5.76-5.86c1.81 0 3.02.77 3.71 1.43l2.53-2.44C16.79 4.15 14.69 3.25 12.18 3.25 7.09 3.25 2.95 7.4 2.95 12.5s4.14 9.25 9.23 9.25c5.33 0 8.86-3.75 8.86-9.03 0-.61-.07-1.08-.15-1.62Z"
                  />
                </svg>
                <span>{t('auth.signInWithGoogle')}</span>
              </SiliconeButton>

              <div className="surface-inset rounded-2xl p-4 flex items-center justify-between gap-3">
                <span className="text-xs font-semibold text-[#7965A5]">
                  {t('auth.inviteCodeLabel')}
                </span>
                <span className="font-mono-num text-sm font-bold text-[#4C269A]">
                  HOUSE-TENS
                </span>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between gap-3 surface-inset rounded-2xl px-4 py-3">
                <div className="min-w-0">
                  <p className="text-xs font-bold text-[#4C269A] truncate">
                    {firebaseUser.displayName || firebaseUser.email}
                  </p>
                  <p className="text-[11px] text-[#7965A5] truncate">
                    {firebaseUser.email}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => void onLogout()}
                  className="btn-3d-cloud min-h-[36px] px-3 py-1 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{t('auth.switchGoogleAccount')}</span>
                </button>
              </div>

              <div>
                <h2 className="font-editorial text-2xl font-bold text-[#38216B]">
                  {t('auth.onboardingTitle')}
                </h2>
                <p className="text-xs sm:text-sm text-[#7965A5] mt-1 leading-relaxed">
                  {defaultInviteExists
                    ? t('auth.onboardingJoinDesc')
                    : t('auth.onboardingLaunchDesc')}
                </p>
              </div>

              {defaultInviteExists === false ? (
                <form
                  onSubmit={(e) => void handleLaunchSubmit(e)}
                  className="space-y-4"
                >
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-[#7965A5]">
                      {t('auth.claimSlotLabel')}
                    </p>
                    <div className="grid grid-cols-2 gap-2.5">
                      {(['res-adson', 'res-arty'] as const).map((slot) => {
                        const selected = launchSlot === slot;
                        return (
                          <button
                            key={slot}
                            type="button"
                            onClick={() => setLaunchSlot(slot)}
                            className={`min-h-[48px] px-4 py-2.5 rounded-2xl text-sm font-bold inline-flex items-center justify-center gap-2 transition-all ${
                              selected
                                ? slot === 'res-adson'
                                  ? 'btn-3d-lavender'
                                  : 'btn-3d-pink'
                                : 'btn-3d-cloud text-[#38216B]'
                            }`}
                          >
                            {selected && <Check className="w-4 h-4" />}
                            <span>
                              {slot === 'res-adson'
                                ? t('auth.claimAdson')
                                : t('auth.claimArty')}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#7965A5] mb-1.5">
                      {t('auth.nameLabel')}
                    </label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder={
                        launchSlot === 'res-adson' ? 'Adson' : 'Arty'
                      }
                      maxLength={40}
                      className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B] focus:outline-none focus:ring-2 focus:ring-[#9672E8]"
                    />
                  </div>

                  <SiliconeButton
                    type="submit"
                    variant="lavender"
                    disabled={isMutating}
                    className="w-full min-h-[50px]"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>{t('auth.launchHouseBtn')}</span>
                  </SiliconeButton>
                </form>
              ) : (
                <form
                  onSubmit={(e) => void handleJoinSubmit(e)}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-xs font-semibold text-[#7965A5] mb-1.5">
                      {t('auth.inviteCodeLabel')}
                    </label>
                    <div className="relative">
                      <KeyRound className="w-4 h-4 text-[#ED82BE] absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={inviteCode}
                        onChange={(e) => setInviteCode(e.target.value)}
                        placeholder={t('auth.inviteCodePlaceholder')}
                        required
                        maxLength={32}
                        className="w-full min-h-[46px] pl-10 pr-4 py-2.5 rounded-2xl surface-inset text-sm font-mono-num uppercase text-[#38216B] focus:outline-none focus:ring-2 focus:ring-[#9672E8]"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-[#7965A5]">
                      {t('auth.claimSlotLabel')}
                    </p>
                    <div className="grid grid-cols-3 gap-2">
                      {(
                        [
                          { id: 'res-arty', label: t('auth.claimArty') },
                          { id: 'res-adson', label: t('auth.claimAdson') },
                          { id: 'custom', label: t('auth.claimCustom') },
                        ] as const
                      ).map((opt) => {
                        const selected = joinSlot === opt.id;
                        return (
                          <button
                            key={opt.id}
                            type="button"
                            onClick={() => setJoinSlot(opt.id)}
                            className={`min-h-[44px] px-2.5 py-2 rounded-2xl text-xs font-bold inline-flex items-center justify-center gap-1.5 transition-all ${
                              selected
                                ? 'btn-3d-pink'
                                : 'btn-3d-cloud text-[#38216B]'
                            }`}
                          >
                            <span>{opt.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {joinSlot === 'custom' && (
                    <div>
                      <label className="block text-xs font-semibold text-[#7965A5] mb-1.5">
                        {t('auth.nameLabel')}
                      </label>
                      <input
                        type="text"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        placeholder={t('auth.namePlaceholder')}
                        required
                        maxLength={40}
                        className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B] focus:outline-none focus:ring-2 focus:ring-[#9672E8]"
                      />
                    </div>
                  )}

                  <SiliconeButton
                    type="submit"
                    variant="pink"
                    disabled={isMutating}
                    className="w-full min-h-[50px]"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>{t('auth.joinHouseBtn')}</span>
                  </SiliconeButton>
                </form>
              )}
            </div>
          )}
        </ClayCard>
      </div>
    </div>
  );
}
