import { ChangeEvent, FormEvent, useMemo, useState } from 'react';
import {
  Bell,
  BellOff,
  Check,
  Copy,
  Download,
  Globe,
  Radio,
  RotateCcw,
  Send,
  ShieldCheck,
  Sliders,
  Smartphone,
  Sparkles,
  Upload,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { SupportedLocale } from '../i18n';
import { LegacyFinanceBackupInfo } from '../hooks/useHouseStore';
import {
  AccessoryStyle,
  AvatarConfig,
  AvatarExpression,
  BackendRuntimeStatus,
  ClothingStyle,
  FacialHair,
  HairStyle,
  HouseholdState,
  HousePreferences,
  HouseStyle,
  PenaltySettings,
  Resident,
  ShadeIntensity,
  SkinTone,
} from '../types/household';
import { formatLocalizedDateTime } from '../utils/dates';
import { getBrowserPushPermission } from '../utils/pushClient';
import { Avatar } from './Avatar';
import {
  ClayCard,
  ConfirmModal,
  SiliconeButton,
} from './ui/ClayPrimitives';
import { ThreeDIcon } from './ui/ThreeDIcons';

interface HouseViewProps {
  state: HouseholdState;
  activeResident: Resident;
  inviteCode: string;
  onlineResidentIds: string[];
  runtimeStatus: BackendRuntimeStatus;
  legacyBackup: LegacyFinanceBackupInfo;
  getLegacyFinanceBackupJson: () => string | null;
  isInstallable: boolean;
  isInstalled: boolean;
  isIOS: boolean;
  onPromptInstall: () => Promise<boolean>;
  onOpenIOSGuide: () => void;
  onSubscribePush: () => Promise<void>;
  onUnsubscribePush: () => Promise<void>;
  onSendTestPush: () => Promise<boolean>;
  onUpdateMyProfile: (payload: {
    name?: string;
    color?: string;
    shadeIntensity?: ShadeIntensity;
    muteShadeNotifications?: boolean;
    avatarConfig?: Partial<AvatarConfig>;
  }) => Promise<void>;
  onUpdateHouseSettings: (payload: {
    houseName?: string;
    tagline?: string;
    houseStyle?: HouseStyle;
    timeZone?: string;
    preferences?: Partial<HousePreferences>;
    penaltySettings?: Partial<PenaltySettings>;
  }) => Promise<void>;
  onChangeLanguage: (locale: SupportedLocale) => void;
  isHouseOwner: boolean;
  userEmail: string;
  onResetDemo: () => Promise<void>;
}

const SKIN_TONES: SkinTone[] = [
  'porcelain',
  'peach',
  'honey',
  'amber',
  'chestnut',
  'espresso',
];

const HAIR_STYLES: HairStyle[] = [
  'short_fade',
  'curly_crown',
  'sleek_bob',
  'waves',
  'buzz',
  'updo',
];

const FACIAL_HAIRS: FacialHair[] = ['none', 'stubble', 'mustache', 'beard'];

const CLOTHING_STYLES: ClothingStyle[] = [
  'lavender_sweater',
  'silk_blazer',
  'sequin_top',
  'hoodie',
  'mesh_chic',
];

const ACCESSORIES: AccessoryStyle[] = [
  'none',
  'cat_eye_shades',
  'pearls',
  'crown',
  'hoops',
  'headband',
];

const EXPRESSIONS: AvatarExpression[] = [
  'smile',
  'smirk',
  'wink',
  'gasp',
  'serene',
];

const ACCENT_SWATCHES = ['#9672E8', '#ED82BE', '#8EA8F5', '#FFC3A6', '#4C269A'];

const TIME_ZONES = [
  'America/Sao_Paulo',
  'America/New_York',
  'America/Los_Angeles',
  'Europe/London',
  'Europe/Paris',
  'UTC',
];

async function resizeImageToCompactDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const maxSide = 220;
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas unavailable'));
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.8));
      };
      img.onerror = () => reject(new Error('Invalid image file'));
      img.src = String(reader.result);
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

export function HouseView({
  state,
  activeResident,
  inviteCode,
  onlineResidentIds,
  runtimeStatus,
  legacyBackup,
  getLegacyFinanceBackupJson,
  isInstallable,
  isInstalled,
  isIOS,
  onPromptInstall,
  onOpenIOSGuide,
  onSubscribePush,
  onUnsubscribePush,
  onSendTestPush,
  onUpdateMyProfile,
  onUpdateHouseSettings,
  onChangeLanguage,
  isHouseOwner,
  userEmail,
  onResetDemo,
}: HouseViewProps) {
  const { t, i18n } = useTranslation();
  const locale = i18n.language;

  // Avatar & Shade State
  const [displayName, setDisplayName] = useState(activeResident.name);
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig>(
    activeResident.avatarConfig
  );
  const [shadeIntensity, setShadeIntensity] = useState<ShadeIntensity>(
    activeResident.shadeIntensity
  );
  const [muteShade, setMuteShade] = useState<boolean>(
    activeResident.muteShadeNotifications
  );

  // House & Penalty Rules State
  const [houseName, setHouseName] = useState(state.houseName);
  const [tagline, setTagline] = useState(state.tagline);
  const [timeZone, setTimeZone] = useState(state.timeZone);
  const [weeklyGoal, setWeeklyGoal] = useState(
    state.preferences.weeklyPointsGoal
  );
  const [penaltiesEnabled, setPenaltiesEnabled] = useState(
    state.penaltySettings.enabled
  );
  const [graceMinutes, setGraceMinutes] = useState(
    state.penaltySettings.gracePeriodMinutes
  );
  const [cooldownHours, setCooldownHours] = useState(
    state.penaltySettings.reminderFrequencyHours
  );
  const [maxPokes, setMaxPokes] = useState(
    state.penaltySettings.maxPokesPerOccurrence
  );

  // Security & UI State
  const [copiedCode, setCopiedCode] = useState(false);
  const [pushBusy, setPushBusy] = useState(false);
  const [pushPermission, setPushPermission] = useState(() =>
    getBrowserPushPermission()
  );
  const [confirmResetOpen, setConfirmResetOpen] = useState(false);

  const residentMap = useMemo(() => {
    const map = new Map<string, Resident>();
    state.residents.forEach((r) => map.set(r.id, r));
    return map;
  }, [state.residents]);

  const handlePhotoUpload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compactUrl = await resizeImageToCompactDataUrl(file);
      setAvatarConfig((prev) => ({ ...prev, customPhotoUrl: compactUrl }));
    } catch {
      // Keep current avatar on invalid image
    }
  };

  const handleSaveAvatarAndShade = async (e: FormEvent) => {
    e.preventDefault();
    await onUpdateMyProfile({
      name: displayName.trim() || activeResident.name,
      color: avatarConfig.accentColor,
      shadeIntensity,
      muteShadeNotifications: muteShade,
      avatarConfig: {
        ...avatarConfig,
        customPhotoUrl: avatarConfig.customPhotoUrl || '',
      },
    });
  };

  const handleSaveRules = async (e: FormEvent) => {
    e.preventDefault();
    await onUpdateHouseSettings({
      houseName: houseName.trim() || state.houseName,
      tagline: tagline.trim() || state.tagline,
      timeZone,
      preferences: {
        weeklyPointsGoal: Number(weeklyGoal) || 150,
      },
      penaltySettings: {
        enabled: penaltiesEnabled,
        gracePeriodMinutes: Number(graceMinutes) || 60,
        reminderFrequencyHours: Number(cooldownHours) || 12,
        maxPokesPerOccurrence: Number(maxPokes) || 2,
      },
    });
  };

  const handleCopyInvite = async () => {
    try {
      await navigator.clipboard.writeText(inviteCode);
      setCopiedCode(true);
      window.setTimeout(() => setCopiedCode(false), 2000);
    } catch {
      // Ignore clipboard failure
    }
  };

  const handlePushToggle = async () => {
    setPushBusy(true);
    try {
      if (activeResident.pushEnabled) {
        await onUnsubscribePush();
      } else {
        await onSubscribePush();
      }
      setPushPermission(getBrowserPushPermission());
    } catch {
      setPushPermission(getBrowserPushPermission());
    } finally {
      setPushBusy(false);
    }
  };

  const handleTestPush = async () => {
    setPushBusy(true);
    try {
      await onSendTestPush();
    } finally {
      setPushBusy(false);
    }
  };

  const handleDownloadLegacyBackup = () => {
    const raw = getLegacyFinanceBackupJson();
    if (!raw) return;
    const blob = new Blob([raw], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'haus-of-hunz-legacy-finances-backup.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3.5">
        <ThreeDIcon kind="residents" size="lg" />
        <div>
          <h1 className="font-editorial text-2xl sm:text-3xl font-bold text-[#38216B]">
            {t('house.pageTitle')}
          </h1>
          <p className="text-xs sm:text-sm text-[#7965A5]">
            {t('house.pageSubtitle')}
          </p>
        </div>
      </div>

      {/* 1. Sync & Backend Status + Live Presence */}
      <ClayCard className="p-5 sm:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl btn-3d-lavender inline-flex items-center justify-center shrink-0">
              <Radio className="w-5 h-5" />
            </span>
            <div>
              <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                {t('house.syncCardTitle')}
              </h2>
              <p className="text-xs font-semibold text-[#4C269A]">
                {runtimeStatus.wsConnected
                  ? t('house.syncLive')
                  : t('house.syncConnecting')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 surface-inset px-3 py-2 rounded-2xl">
            <span className="text-xs font-semibold text-[#7965A5]">
              {t('house.inviteCodeLabel')}:
            </span>
            <span className="font-mono-num text-sm font-bold text-[#4C269A]">
              {inviteCode}
            </span>
            <button
              type="button"
              onClick={() => void handleCopyInvite()}
              className="btn-3d-cloud min-h-[32px] px-2.5 py-1 rounded-xl text-xs font-semibold inline-flex items-center gap-1"
            >
              {copiedCode ? (
                <>
                  <Check className="w-3.5 h-3.5 text-[#1C7C54]" />
                  <span>{t('house.copiedInviteBtn')}</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>{t('house.copyInviteBtn')}</span>
                </>
              )}
            </button>
          </div>
        </div>

        <p className="text-xs text-[#7965A5] leading-relaxed surface-inset rounded-2xl p-3.5">
          {t('house.syncPersistenceNote')}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {state.residents.map((resident) => {
            const isOnline = onlineResidentIds.includes(resident.id);
            return (
              <div
                key={resident.id}
                className="surface-inset rounded-2xl p-3.5 flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar
                    resident={resident}
                    size="sm"
                    showOnlineDot={isOnline}
                  />
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-[#38216B] truncate">
                      {resident.name}{' '}
                      {resident.id === activeResident.id &&
                        `(${t('common.you')})`}
                    </p>
                    <p className="text-xs text-[#7965A5] truncate">
                      {resident.email}
                    </p>
                  </div>
                </div>
                <span
                  className={`text-[11px] font-bold px-2.5 py-1 rounded-full shrink-0 ${
                    isOnline
                      ? 'bg-[#E6F7EE] text-[#1C7C54]'
                      : 'bg-white/70 text-[#7965A5]'
                  }`}
                >
                  {isOnline ? t('house.onlineNow') : t('house.offlineNow')}
                </span>
              </div>
            );
          })}
        </div>
      </ClayCard>

      {/* 2. Avatar Studio & Poke & Shade Preferences */}
      <form
        onSubmit={(e) => void handleSaveAvatarAndShade(e)}
        className="grid grid-cols-1 lg:grid-cols-12 gap-5"
      >
        <ClayCard className="lg:col-span-7 p-5 sm:p-6 space-y-5">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-[#9672E8]" />
            <div>
              <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                {t('house.avatarStudioTitle')}
              </h2>
              <p className="text-xs text-[#7965A5]">
                {t('house.avatarStudioSubtitle')}
              </p>
            </div>
          </div>

          {/* Live Avatar Preview + Photo Upload */}
          <div className="surface-inset rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center gap-4">
            <Avatar
              resident={activeResident}
              overrideConfig={avatarConfig}
              fallbackName={displayName}
              size="xl"
            />
            <div className="flex-1 space-y-3">
              <div>
                <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                  {t('house.displayNameLabel')}
                </label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-white/85 border border-[#C5A6F5]/40 text-sm text-[#38216B]"
                />
              </div>
              <div className="flex flex-wrap gap-2">
                <label className="btn-3d-cloud min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{t('house.uploadPhotoBtn')}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => void handlePhotoUpload(e)}
                    className="hidden"
                  />
                </label>
                {avatarConfig.customPhotoUrl && (
                  <button
                    type="button"
                    onClick={() =>
                      setAvatarConfig((prev) => ({
                        ...prev,
                        customPhotoUrl: undefined,
                      }))
                    }
                    className="btn-3d-cloud min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-semibold text-[#B33981]"
                  >
                    {t('house.clearPhotoBtn')}
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Customizer Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.skinToneLabel')}
              </label>
              <select
                value={avatarConfig.skinTone}
                onChange={(e) =>
                  setAvatarConfig((p) => ({
                    ...p,
                    skinTone: e.target.value as SkinTone,
                  }))
                }
                className="w-full min-h-[44px] px-3 py-2 rounded-2xl surface-inset text-sm text-[#38216B]"
              >
                {SKIN_TONES.map((s) => (
                  <option key={s} value={s}>
                    {t(`house.avatarOptions.skinTones.${s}`)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.hairStyleLabel')}
              </label>
              <select
                value={avatarConfig.hairStyle}
                onChange={(e) =>
                  setAvatarConfig((p) => ({
                    ...p,
                    hairStyle: e.target.value as HairStyle,
                  }))
                }
                className="w-full min-h-[44px] px-3 py-2 rounded-2xl surface-inset text-sm text-[#38216B]"
              >
                {HAIR_STYLES.map((h) => (
                  <option key={h} value={h}>
                    {t(`house.avatarOptions.hairStyles.${h}`)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.facialHairLabel')}
              </label>
              <select
                value={avatarConfig.facialHair}
                onChange={(e) =>
                  setAvatarConfig((p) => ({
                    ...p,
                    facialHair: e.target.value as FacialHair,
                  }))
                }
                className="w-full min-h-[44px] px-3 py-2 rounded-2xl surface-inset text-sm text-[#38216B]"
              >
                {FACIAL_HAIRS.map((f) => (
                  <option key={f} value={f}>
                    {t(`house.avatarOptions.facialHair.${f}`)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.clothingLabel')}
              </label>
              <select
                value={avatarConfig.clothing}
                onChange={(e) =>
                  setAvatarConfig((p) => ({
                    ...p,
                    clothing: e.target.value as ClothingStyle,
                  }))
                }
                className="w-full min-h-[44px] px-3 py-2 rounded-2xl surface-inset text-sm text-[#38216B]"
              >
                {CLOTHING_STYLES.map((c) => (
                  <option key={c} value={c}>
                    {t(`house.avatarOptions.clothing.${c}`)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.accessoryLabel')}
              </label>
              <select
                value={avatarConfig.accessory}
                onChange={(e) =>
                  setAvatarConfig((p) => ({
                    ...p,
                    accessory: e.target.value as AccessoryStyle,
                  }))
                }
                className="w-full min-h-[44px] px-3 py-2 rounded-2xl surface-inset text-sm text-[#38216B]"
              >
                {ACCESSORIES.map((a) => (
                  <option key={a} value={a}>
                    {t(`house.avatarOptions.accessories.${a}`)}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.expressionLabel')}
              </label>
              <select
                value={avatarConfig.expression}
                onChange={(e) =>
                  setAvatarConfig((p) => ({
                    ...p,
                    expression: e.target.value as AvatarExpression,
                  }))
                }
                className="w-full min-h-[44px] px-3 py-2 rounded-2xl surface-inset text-sm text-[#38216B]"
              >
                {EXPRESSIONS.map((ex) => (
                  <option key={ex} value={ex}>
                    {t(`house.avatarOptions.expressions.${ex}`)}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold text-[#7965A5] mb-2">
              {t('house.accentColorLabel')}
            </p>
            <div className="flex flex-wrap gap-2.5">
              {ACCENT_SWATCHES.map((hex) => (
                <button
                  key={hex}
                  type="button"
                  onClick={() =>
                    setAvatarConfig((p) => ({ ...p, accentColor: hex }))
                  }
                  style={{ backgroundColor: hex }}
                  aria-label={hex}
                  className={`w-10 h-10 rounded-full border-2 transition-transform ${
                    avatarConfig.accentColor === hex
                      ? 'border-[#38216B] scale-110 shadow-md'
                      : 'border-white'
                  }`}
                />
              ))}
            </div>
          </div>
        </ClayCard>

        {/* Poke & Shade Consent & Intensity */}
        <ClayCard className="lg:col-span-5 p-5 sm:p-6 flex flex-col justify-between gap-5">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <ThreeDIcon kind="shade" size="sm" />
              <div>
                <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                  {t('house.shadePrefsTitle')}
                </h2>
                <p className="text-xs text-[#7965A5]">
                  {t('house.shadePrefsSubtitle')}
                </p>
              </div>
            </div>

            <label className="surface-inset rounded-2xl p-3.5 flex items-start justify-between gap-3 cursor-pointer">
              <div>
                <p className="text-sm font-semibold text-[#38216B]">
                  {t('house.muteShadeLabel')}
                </p>
                <p className="text-xs text-[#7965A5] mt-0.5">
                  {t('house.muteShadeDesc')}
                </p>
              </div>
              <input
                type="checkbox"
                checked={muteShade}
                onChange={(e) => setMuteShade(e.target.checked)}
                className="w-5 h-5 mt-1 accent-[#9672E8]"
              />
            </label>

            <div className="space-y-2">
              <p className="text-xs font-semibold text-[#7965A5]">
                {t('house.shadeIntensityLabel')}
              </p>
              {(
                [
                  'soft_serve',
                  'a_little_shady',
                  'full_ballroom',
                ] as ShadeIntensity[]
              ).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  onClick={() => setShadeIntensity(mode)}
                  className={`w-full text-left rounded-2xl p-3.5 border transition-all ${
                    shadeIntensity === mode
                      ? 'bg-[#FFF8FF] border-[#ED82BE] shadow-sm'
                      : 'surface-inset border-transparent'
                  }`}
                >
                  <p className="text-sm font-bold text-[#4C269A]">
                    {t(`house.shadeModes.${mode}.label`)}
                  </p>
                  <p className="text-xs text-[#7965A5] mt-0.5">
                    {t(`house.shadeModes.${mode}.desc`)}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <SiliconeButton type="submit" variant="lavender" className="w-full">
            {t('house.saveAvatarBtn')}
          </SiliconeButton>
        </ClayCard>
      </form>

      {/* 3. iPhone PWA & Web Push + Language */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <ClayCard className="lg:col-span-7 p-5 sm:p-6 space-y-4">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl btn-3d-pink inline-flex items-center justify-center shrink-0">
              <Smartphone className="w-5 h-5" />
            </span>
            <div>
              <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                {t('house.pushTitle')}
              </h2>
              <p className="text-xs text-[#7965A5]">
                {t('house.pushSubtitle')}
              </p>
            </div>
          </div>

          <div className="surface-inset rounded-2xl p-3.5 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="font-semibold text-[#7965A5]">
              {t('house.pushPermissionLabel')}:
            </span>
            <span className="font-bold text-[#4C269A]">
              {t(`house.pushPermissions.${pushPermission}`)}
            </span>
          </div>

          <div className="flex flex-wrap gap-2.5">
            {!isInstalled && (isInstallable || isIOS) && (
              <SiliconeButton
                variant="cloud"
                onClick={() => {
                  if (isInstallable) {
                    void onPromptInstall();
                  } else {
                    onOpenIOSGuide();
                  }
                }}
              >
                <Smartphone className="w-4 h-4" />
                <span>
                  {isIOS ? t('pwa.iosBtn') : t('pwa.installBtn')}
                </span>
              </SiliconeButton>
            )}

            <SiliconeButton
              variant={activeResident.pushEnabled ? 'cloud' : 'lavender'}
              disabled={pushBusy || pushPermission === 'unsupported'}
              onClick={() => void handlePushToggle()}
            >
              {activeResident.pushEnabled ? (
                <>
                  <BellOff className="w-4 h-4" />
                  <span>{t('house.disablePushBtn')}</span>
                </>
              ) : (
                <>
                  <Bell className="w-4 h-4" />
                  <span>{t('house.enablePushBtn')}</span>
                </>
              )}
            </SiliconeButton>

            <SiliconeButton
              variant="pink"
              disabled={pushBusy || !activeResident.pushEnabled}
              onClick={() => void handleTestPush()}
            >
              <Send className="w-4 h-4" />
              <span>{t('house.testPushBtn')}</span>
            </SiliconeButton>
          </div>

          <p className="text-xs text-[#7965A5] leading-relaxed">
            {t('house.pushFallbackNote')}
          </p>
        </ClayCard>

        {/* Language Selector */}
        <ClayCard className="lg:col-span-5 p-5 sm:p-6 space-y-4">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-2xl btn-3d-lavender inline-flex items-center justify-center shrink-0">
              <Globe className="w-5 h-5" />
            </span>
            <div>
              <h2 className="font-editorial text-xl font-bold text-[#38216B]">
                {t('house.languageTitle')}
              </h2>
              <p className="text-xs text-[#7965A5]">
                {t('house.languageSubtitle')}
              </p>
            </div>
          </div>

          <div className="space-y-2.5 pt-2">
            {(['en-US', 'pt-BR'] as SupportedLocale[]).map((loc) => {
              const active = locale === loc;
              return (
                <button
                  key={loc}
                  type="button"
                  onClick={() => onChangeLanguage(loc)}
                  className={`w-full min-h-[48px] px-4 py-3 rounded-2xl flex items-center justify-between text-sm font-semibold transition-all ${
                    active
                      ? 'btn-3d-lavender'
                      : 'btn-3d-cloud text-[#38216B]'
                  }`}
                >
                  <span>
                    {loc === 'en-US'
                      ? t('house.languages.enUS')
                      : t('house.languages.ptBR')}
                  </span>
                  {active && <Check className="w-4 h-4" />}
                </button>
              );
            })}
          </div>
        </ClayCard>
      </div>

      {/* 4. Deadlines, Penalties & House Rules */}
      <ClayCard className="p-5 sm:p-6 space-y-4">
        <div className="flex items-center gap-3">
          <Sliders className="w-5 h-5 text-[#9672E8]" />
          <div>
            <h2 className="font-editorial text-xl font-bold text-[#38216B]">
              {t('house.penaltyConfigTitle')}
            </h2>
            <p className="text-xs text-[#7965A5]">
              {t('house.penaltyConfigSubtitle')}
            </p>
          </div>
        </div>

        <form onSubmit={(e) => void handleSaveRules(e)} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.houseNameLabel')}
              </label>
              <input
                type="text"
                value={houseName}
                onChange={(e) => setHouseName(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-2xl surface-inset text-sm text-[#38216B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.houseTaglineLabel')}
              </label>
              <input
                type="text"
                value={tagline}
                onChange={(e) => setTagline(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-2xl surface-inset text-sm text-[#38216B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.timezoneLabel')}
              </label>
              <select
                value={timeZone}
                onChange={(e) => setTimeZone(e.target.value)}
                className="w-full min-h-[44px] px-3 py-2 rounded-2xl surface-inset text-sm text-[#38216B]"
              >
                {TIME_ZONES.map((tz) => (
                  <option key={tz} value={tz}>
                    {tz}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.weeklyGoalLabel')}
              </label>
              <input
                type="number"
                min={20}
                max={1000}
                value={weeklyGoal}
                onChange={(e) => setWeeklyGoal(Number(e.target.value))}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-2xl surface-inset text-sm font-mono-num text-[#38216B]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 items-end">
            <label className="surface-inset rounded-2xl p-3 flex items-center justify-between gap-2 min-h-[46px] cursor-pointer">
              <span className="text-xs font-semibold text-[#38216B]">
                {t('house.penaltiesEnabledLabel')}
              </span>
              <input
                type="checkbox"
                checked={penaltiesEnabled}
                onChange={(e) => setPenaltiesEnabled(e.target.checked)}
                className="w-5 h-5 accent-[#9672E8]"
              />
            </label>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.graceMinutesLabel')}
              </label>
              <input
                type="number"
                min={0}
                max={720}
                value={graceMinutes}
                onChange={(e) => setGraceMinutes(Number(e.target.value))}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-2xl surface-inset text-sm font-mono-num text-[#38216B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.reminderHoursLabel')}
              </label>
              <input
                type="number"
                min={1}
                max={72}
                value={cooldownHours}
                onChange={(e) => setCooldownHours(Number(e.target.value))}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-2xl surface-inset text-sm font-mono-num text-[#38216B]"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                {t('house.maxPokesLabel')}
              </label>
              <input
                type="number"
                min={1}
                max={5}
                value={maxPokes}
                onChange={(e) => setMaxPokes(Number(e.target.value))}
                className="w-full min-h-[44px] px-3.5 py-2 rounded-2xl surface-inset text-sm font-mono-num text-[#38216B]"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <SiliconeButton type="submit" variant="lavender">
              {t('house.saveSettingsBtn')}
            </SiliconeButton>
          </div>
        </form>
      </ClayCard>

      {/* 5. Google Account, Legacy Finance Backup & Activity Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <ClayCard className="lg:col-span-5 p-5 sm:p-6 space-y-4">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-[#9672E8]" />
            <h2 className="font-editorial text-xl font-bold text-[#38216B]">
              {t('house.securityTitle')}
            </h2>
          </div>

          <div className="surface-inset rounded-2xl p-4 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-[#4C269A]">
              <Check className="w-4 h-4 text-[#1C7C54] shrink-0" />
              <span>{t('house.syncLive')}</span>
            </div>
            <p className="text-xs text-[#7965A5] leading-relaxed break-words">
              {t('house.googleConnectedNote', {
                email: userEmail || activeResident.email,
              })}
            </p>
          </div>

          {legacyBackup.archived && (
            <div className="surface-inset rounded-2xl p-3.5 space-y-2.5">
              <p className="text-xs text-[#4C269A] leading-relaxed">
                {t('house.legacyBackupNotice', {
                  expenses: legacyBackup.expenseCount,
                  settlements: legacyBackup.settlementCount,
                })}
              </p>
              <SiliconeButton
                variant="cloud"
                onClick={handleDownloadLegacyBackup}
                className="w-full text-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t('house.downloadBackupBtn')}</span>
              </SiliconeButton>
            </div>
          )}

          <div className="pt-2 border-t border-[#C5A6F5]/30 space-y-2">
            <SiliconeButton
              variant="pink"
              disabled={!isHouseOwner}
              onClick={() => setConfirmResetOpen(true)}
              className="w-full"
            >
              <RotateCcw className="w-4 h-4" />
              <span>{t('house.restoreDefaultsBtn')}</span>
            </SiliconeButton>
            {!isHouseOwner && (
              <p className="text-[11px] text-[#7965A5] text-center">
                {t('house.ownerOnlyResetNote')}
              </p>
            )}
          </div>
        </ClayCard>

        <ClayCard className="lg:col-span-7 p-5 sm:p-6 space-y-4">
          <h2 className="font-editorial text-xl font-bold text-[#38216B]">
            {t('house.activityTitle')}
          </h2>

          {state.activityLog.length === 0 ? (
            <p className="text-xs text-[#7965A5] surface-inset rounded-2xl p-4">
              {t('house.emptyActivity')}
            </p>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto pr-1">
              {state.activityLog.slice(0, 25).map((log) => {
                const actor = residentMap.get(log.actorId);
                return (
                  <div
                    key={log.id}
                    className="surface-inset rounded-2xl px-3.5 py-2.5 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Avatar resident={actor} size="xs" />
                      <p className="text-xs sm:text-sm text-[#38216B] truncate">
                        {log.summary}
                      </p>
                    </div>
                    <span className="font-mono-num text-[11px] text-[#7965A5] shrink-0">
                      {formatLocalizedDateTime(
                        log.createdAt,
                        locale,
                        state.timeZone
                      )}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </ClayCard>
      </div>

      <ConfirmModal
        open={confirmResetOpen}
        title={t('house.resetTitle')}
        description={t('house.resetDesc')}
        confirmLabel={t('house.resetConfirm')}
        onConfirm={() => {
          void onResetDemo();
          setConfirmResetOpen(false);
        }}
        onCancel={() => setConfirmResetOpen(false)}
      />
    </div>
  );
}
