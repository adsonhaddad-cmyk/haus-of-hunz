import { FormEvent, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowLeftRight,
  CalendarClock,
  Check,
  ChevronDown,
  ChevronUp,
  Edit3,
  PauseCircle,
  PlayCircle,
  Plus,
  Repeat,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import {
  HouseholdState,
  HouseholdTask,
  Resident,
  TaskCategory,
  TaskFrequency,
  TaskPriority,
} from '../types/household';
import {
  formatLocalizedDate,
  formatLocalizedTime24or12,
  getTodayYMD,
} from '../utils/dates';
import {
  checkPokeEligibility,
  evaluateTaskOverdue,
  getNextRotationResidentId,
} from '../utils/gameEngine';
import { Avatar } from './Avatar';
import {
  ClayCard,
  ConfirmModal,
  EmptyState,
  SiliconeButton,
} from './ui/ClayPrimitives';
import { Mascot } from './ui/Mascots';
import { ThreeDIcon } from './ui/ThreeDIcons';

interface TasksViewProps {
  state: HouseholdState;
  activeResident: Resident;
  onlineResidentIds: string[];
  onCompleteTask: (taskId: string) => Promise<void>;
  onAddTask: (payload: {
    title: string;
    description?: string;
    category: TaskCategory;
    points: number;
    priority: TaskPriority;
    frequency: TaskFrequency;
    customIntervalDays?: number;
    assignedToId: string;
    participantIds: string[];
    dueDate: string;
    dueTime: string;
  }) => Promise<void>;
  onUpdateTask: (
    taskId: string,
    updates: {
      title?: string;
      description?: string;
      category?: TaskCategory;
      points?: number;
      priority?: TaskPriority;
      frequency?: TaskFrequency;
      customIntervalDays?: number;
      assignedToId?: string;
      participantIds?: string[];
      dueDate?: string;
      dueTime?: string;
    }
  ) => Promise<void>;
  onPauseTask: (
    taskId: string,
    pausedReason?: string,
    pausedUntil?: string
  ) => Promise<void>;
  onResumeTask: (taskId: string) => Promise<void>;
  onSendPoke: (taskId: string) => Promise<void>;
  onProposeSwap: (taskId: string, note?: string) => Promise<void>;
  onDeleteTask: (taskId: string) => Promise<void>;
}

type TaskFilter = 'mine' | 'all' | 'overdue' | 'paused' | 'completed';

const CATEGORIES: TaskCategory[] = [
  'Limpeza',
  'Cozinha',
  'Organização',
  'Manutenção',
  'Geral',
];

const FREQUENCIES: TaskFrequency[] = [
  'once',
  'daily',
  'weekly',
  'biweekly',
  'monthly',
  'custom',
];

const PRIORITIES: TaskPriority[] = ['alta', 'media', 'normal'];

function formatDelayShort(minutes: number): string {
  if (minutes < 60) return `${minutes}m`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
}

export function TasksView({
  state,
  activeResident,
  onlineResidentIds,
  onCompleteTask,
  onAddTask,
  onUpdateTask,
  onPauseTask,
  onResumeTask,
  onSendPoke,
  onProposeSwap,
  onDeleteTask,
}: TasksViewProps) {
  const { t, i18n } = useTranslation();
  const locale = i18n.language;
  const nowMs = Date.now();

  const [filter, setFilter] = useState<TaskFilter>('all');
  const [expandedHistoryIds, setExpandedHistoryIds] = useState<
    Record<string, boolean>
  >({});

  // Create/Edit Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<HouseholdTask | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<TaskCategory>('Limpeza');
  const [priority, setPriority] = useState<TaskPriority>('media');
  const [points, setPoints] = useState<number>(20);
  const [frequency, setFrequency] = useState<TaskFrequency>('weekly');
  const [customIntervalDays, setCustomIntervalDays] = useState<number>(3);
  const [dueDate, setDueDate] = useState<string>(() =>
    getTodayYMD(state.timeZone)
  );
  const [dueTime, setDueTime] = useState<string>('20:00');
  const [participantIds, setParticipantIds] = useState<string[]>(() =>
    state.residents.map((r) => r.id)
  );
  const [assignedToId, setAssignedToId] = useState<string>(activeResident.id);

  // Swap Modal State
  const [swapTask, setSwapTask] = useState<HouseholdTask | null>(null);
  const [swapNote, setSwapNote] = useState('');

  // Pause Modal State
  const [pauseModalTask, setPauseModalTask] = useState<HouseholdTask | null>(
    null
  );
  const [pauseReason, setPauseReason] = useState('');

  // Delete Modal State
  const [confirmDeleteTask, setConfirmDeleteTask] =
    useState<HouseholdTask | null>(null);

  const residentMap = useMemo(() => {
    const map = new Map<string, Resident>();
    state.residents.forEach((r) => map.set(r.id, r));
    return map;
  }, [state.residents]);

  const filteredTasks = useMemo(() => {
    return state.tasks
      .filter((task) => {
        if (filter === 'mine') {
          return (
            task.status === 'pending' && task.assignedToId === activeResident.id
          );
        }
        if (filter === 'overdue') {
          return (
            task.status === 'pending' &&
            evaluateTaskOverdue(task, nowMs, state.penaltySettings).isOverdue
          );
        }
        if (filter === 'paused') return task.status === 'paused';
        if (filter === 'completed') return task.status === 'completed';
        return task.status !== 'completed';
      })
      .sort(
        (a, b) => new Date(a.dueAt).getTime() - new Date(b.dueAt).getTime()
      );
  }, [state.tasks, filter, activeResident.id, nowMs, state.penaltySettings]);

  const overdueCount = useMemo(
    () =>
      state.tasks.filter(
        (t) =>
          t.status === 'pending' &&
          evaluateTaskOverdue(t, nowMs, state.penaltySettings).isOverdue
      ).length,
    [state.tasks, nowMs, state.penaltySettings]
  );

  const openCreateModal = () => {
    setEditingTask(null);
    setTitle('');
    setDescription('');
    setCategory('Limpeza');
    setPriority('media');
    setPoints(20);
    setFrequency('weekly');
    setCustomIntervalDays(3);
    setDueDate(getTodayYMD(state.timeZone));
    setDueTime('20:00');
    const allIds = state.residents.map((r) => r.id);
    setParticipantIds(allIds);
    setAssignedToId(activeResident.id);
    setModalOpen(true);
  };

  const openEditModal = (task: HouseholdTask) => {
    setEditingTask(task);
    setTitle(task.title);
    setDescription(task.description || '');
    setCategory(task.category);
    setPriority(task.priority);
    setPoints(task.points);
    setFrequency(task.frequency);
    setCustomIntervalDays(task.customIntervalDays || 3);
    setDueDate(task.dueDate);
    setDueTime(task.dueTime || '20:00');
    setParticipantIds(
      task.participantIds.length > 0
        ? task.participantIds
        : state.residents.map((r) => r.id)
    );
    setAssignedToId(task.assignedToId);
    setModalOpen(true);
  };

  const handleToggleParticipant = (residentId: string) => {
    setParticipantIds((prev) => {
      if (prev.includes(residentId)) {
        if (prev.length === 1) return prev;
        const next = prev.filter((id) => id !== residentId);
        if (!next.includes(assignedToId)) {
          setAssignedToId(next[0]);
        }
        return next;
      }
      return [...prev, residentId];
    });
  };

  const handleSubmitChore = async (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    const payload = {
      title: title.trim(),
      description: description.trim() || undefined,
      category,
      priority,
      points: Number(points) || 20,
      frequency,
      customIntervalDays:
        frequency === 'custom' ? Number(customIntervalDays) || 3 : undefined,
      participantIds,
      assignedToId,
      dueDate,
      dueTime: dueTime || '20:00',
    };

    if (editingTask) {
      await onUpdateTask(editingTask.id, payload);
    } else {
      await onAddTask(payload);
    }
    setModalOpen(false);
  };

  const handleConfirmSwap = async (e: FormEvent) => {
    e.preventDefault();
    if (!swapTask) return;
    await onProposeSwap(swapTask.id, swapNote.trim() || undefined);
    setSwapTask(null);
    setSwapNote('');
  };

  const handleConfirmPause = async (e: FormEvent) => {
    e.preventDefault();
    if (!pauseModalTask) return;
    await onPauseTask(pauseModalTask.id, pauseReason.trim() || undefined);
    setPauseModalTask(null);
    setPauseReason('');
  };

  const filterButtons: { key: TaskFilter; label: string }[] = [
    { key: 'all', label: t('tasks.filters.all') },
    { key: 'mine', label: t('tasks.filters.mine') },
    {
      key: 'overdue',
      label:
        overdueCount > 0
          ? `${t('tasks.filters.overdue')} (${overdueCount})`
          : t('tasks.filters.overdue'),
    },
    { key: 'paused', label: t('tasks.filters.paused') },
    { key: 'completed', label: t('tasks.filters.completed') },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <ThreeDIcon kind="cleaning" size="lg" />
          <div>
            <h1 className="font-editorial text-2xl sm:text-3xl font-bold text-[#38216B]">
              {t('tasks.pageTitle')}
            </h1>
            <p className="text-xs sm:text-sm text-[#7965A5]">
              {t('tasks.pageSubtitle')}
            </p>
          </div>
        </div>

        <SiliconeButton
          variant="lavender"
          onClick={openCreateModal}
          ariaLabel={t('tasks.createChoreAria')}
        >
          <Plus className="w-4 h-4" />
          <span>{t('tasks.newChore')}</span>
        </SiliconeButton>
      </div>

      {/* Madame Deadline Penalty Rule Banner */}
      <ClayCard variant="glass" className="p-4 flex items-center gap-3.5">
        <Mascot
          id="madame-deadline"
          mood={overdueCount > 0 ? 'panicked' : 'idle'}
          size="sm"
        />
        <p className="text-xs sm:text-sm text-[#4C269A] font-medium leading-relaxed">
          {t('tasks.penaltyRuleBanner', {
            grace: state.penaltySettings.gracePeriodMinutes,
          })}
        </p>
      </ClayCard>

      {/* Filter Tabs */}
      <div className="flex flex-wrap gap-2">
        {filterButtons.map((btn) => (
          <button
            key={btn.key}
            type="button"
            onClick={() => setFilter(btn.key)}
            className={`min-h-[42px] px-4 py-2 rounded-2xl text-xs sm:text-sm font-semibold transition-all ${
              filter === btn.key
                ? 'btn-3d-lavender'
                : 'btn-3d-cloud text-[#4C269A]'
            }`}
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* Task List */}
      {filteredTasks.length === 0 ? (
        <EmptyState
          iconKind="cleaning"
          title={t('tasks.emptyTitle')}
          description={t('tasks.emptyDesc')}
          action={
            <SiliconeButton variant="lavender" onClick={openCreateModal}>
              <Plus className="w-4 h-4" />
              <span>{t('tasks.createChore')}</span>
            </SiliconeButton>
          }
        />
      ) : (
        <div className="space-y-4">
          {filteredTasks.map((task) => {
            const assignee = residentMap.get(task.assignedToId);
            const nextId = getNextRotationResidentId(
              task.participantIds,
              task.assignedToId,
              state.residents
            );
            const nextResident = residentMap.get(nextId);
            const overdueEval = evaluateTaskOverdue(
              task,
              nowMs,
              state.penaltySettings
            );

            const isMyChore = task.assignedToId === activeResident.id;
            const pokeEligibility =
              !isMyChore && assignee
                ? checkPokeEligibility(
                    task,
                    activeResident.id,
                    assignee,
                    state.pokes,
                    nowMs,
                    state.penaltySettings
                  )
                : null;

            const hasPendingSwap = state.swapRequests.some(
              (s) => s.taskId === task.id && s.status === 'pending'
            );

            const historyExpanded = Boolean(expandedHistoryIds[task.id]);

            return (
              <ClayCard key={task.id} className="p-4 sm:p-5 space-y-3.5">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#EADCF8] text-[#4C269A]">
                        {t(`tasks.categories.${task.category}`)}
                      </span>
                      <span className="text-[11px] font-semibold px-2.5 py-0.5 rounded-full bg-[#FFF8FF] text-[#7965A5] border border-[#C5A6F5]/40">
                        {task.frequency === 'custom'
                          ? t('tasks.everyNDays', {
                              days: task.customIntervalDays || 3,
                            })
                          : t(`tasks.frequencies.${task.frequency}`)}
                      </span>
                      <span className="font-mono-num text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-[#F7D5E9] text-[#9F2E71]">
                        {overdueEval.penaltyPoints > 0
                          ? `${overdueEval.netPoints}/${task.points} ${t('common.pts')}`
                          : `${task.points} ${t('common.pts')}`}
                      </span>
                    </div>

                    <h3 className="font-editorial text-lg sm:text-xl font-bold text-[#38216B]">
                      {task.title}
                    </h3>

                    {task.description && (
                      <p className="text-xs sm:text-sm text-[#7965A5]">
                        {task.description}
                      </p>
                    )}

                    {/* Deadline & Status Row */}
                    <div className="flex flex-wrap items-center gap-2.5 pt-1 text-xs">
                      <span className="inline-flex items-center gap-1.5 text-[#4C269A] font-medium">
                        <CalendarClock className="w-3.5 h-3.5 text-[#9672E8]" />
                        {t('tasks.dueLabel', {
                          date: formatLocalizedDate(task.dueDate, locale),
                          time: formatLocalizedTime24or12(
                            task.dueTime || '20:00',
                            locale
                          ),
                        })}
                      </span>

                      {task.status === 'paused' ? (
                        <span className="px-2.5 py-0.5 rounded-full bg-[#EAE2FC] text-[#4C269A] font-semibold">
                          {t('tasks.pausedBadge', {
                            reason: task.pausedReason
                              ? ` (${task.pausedReason})`
                              : '',
                          })}
                        </span>
                      ) : task.status === 'pending' && overdueEval.isOverdue ? (
                        <span className="px-2.5 py-0.5 rounded-full bg-[#FCE0F0] text-[#B33981] font-semibold">
                          {overdueEval.isWithinGrace
                            ? t('tasks.graceBadge', {
                                mins: overdueEval.delayMinutes,
                              })
                            : t('tasks.overdueBadge', {
                                delay: formatDelayShort(
                                  overdueEval.delayMinutes
                                ),
                                percent: overdueEval.penaltyPercent,
                              })}
                        </span>
                      ) : task.status === 'pending' ? (
                        <span className="px-2.5 py-0.5 rounded-full bg-[#E6F7EE] text-[#1C7C54] font-semibold">
                          {t('tasks.onTimeBadge')}
                        </span>
                      ) : null}
                    </div>
                  </div>

                  {/* Quick Edit & Delete */}
                  <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-start">
                    {task.status === 'pending' && (
                      <button
                        type="button"
                        onClick={() => {
                          setPauseModalTask(task);
                          setPauseReason('');
                        }}
                        aria-label={t('tasks.pauseChore')}
                        className="btn-3d-cloud min-h-[40px] min-w-[40px] rounded-xl inline-flex items-center justify-center text-[#7965A5]"
                      >
                        <PauseCircle className="w-4 h-4" />
                      </button>
                    )}
                    {task.status === 'paused' && (
                      <button
                        type="button"
                        onClick={() => void onResumeTask(task.id)}
                        aria-label={t('tasks.resumeChore')}
                        className="btn-3d-cloud min-h-[40px] min-w-[40px] rounded-xl inline-flex items-center justify-center text-[#4C269A]"
                      >
                        <PlayCircle className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => openEditModal(task)}
                      aria-label={t('tasks.editChoreAria', {
                        title: task.title,
                      })}
                      className="btn-3d-cloud min-h-[40px] min-w-[40px] rounded-xl inline-flex items-center justify-center text-[#7965A5]"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmDeleteTask(task)}
                      aria-label={t('tasks.deleteChoreAria', {
                        title: task.title,
                      })}
                      className="btn-3d-cloud min-h-[40px] min-w-[40px] rounded-xl inline-flex items-center justify-center text-[#B33981]"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Rotation & Action Bar */}
                <div className="pt-3 border-t border-[#C5A6F5]/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-3 text-xs text-[#7965A5]">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{t('tasks.turnOf')}</span>
                      <Avatar
                        resident={assignee}
                        size="xs"
                        showOnlineDot={
                          assignee
                            ? onlineResidentIds.includes(assignee.id)
                            : false
                        }
                      />
                      <span className="font-bold text-[#38216B]">
                        {assignee?.name ?? t('common.partnerFallback')}
                      </span>
                    </div>
                    {task.frequency !== 'once' && nextResident && (
                      <span className="inline-flex items-center gap-1 text-[#7965A5]">
                        <Repeat className="w-3.5 h-3.5 text-[#9672E8]" />
                        {t('tasks.nextUp', { name: nextResident.name })}
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {/* Poke & Shade button (ONLY for overdue chores assigned to other partner) */}
                    {task.status === 'pending' &&
                      !isMyChore &&
                      overdueEval.isOverdue &&
                      pokeEligibility && (
                        <SiliconeButton
                          variant="pink"
                          disabled={!pokeEligibility.allowed}
                          onClick={() => void onSendPoke(task.id)}
                          className="min-h-[42px] py-2 px-3.5 text-xs"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>
                            {pokeEligibility.allowed
                              ? `${t('tasks.throwShade')} (${pokeEligibility.pokesUsed}/${pokeEligibility.maxPokes})`
                              : pokeEligibility.reason === 'cooldown_active'
                                ? t('tasks.shadeCooldown', {
                                    hours: Math.max(
                                      1,
                                      Math.ceil(
                                        pokeEligibility.cooldownRemainingMs /
                                          3600000
                                      )
                                    ),
                                  })
                                : pokeEligibility.reason === 'max_pokes_reached'
                                  ? t('tasks.shadeMaxed')
                                  : t('tasks.shadeMuted')}
                          </span>
                        </SiliconeButton>
                      )}

                    {/* Swap Request Button */}
                    {task.status === 'pending' && state.residents.length > 1 && (
                      <SiliconeButton
                        variant="cloud"
                        disabled={hasPendingSwap}
                        onClick={() => {
                          setSwapTask(task);
                          setSwapNote('');
                        }}
                        className="min-h-[42px] py-2 px-3.5 text-xs"
                      >
                        <ArrowLeftRight className="w-3.5 h-3.5" />
                        <span>
                          {hasPendingSwap
                            ? t('tasks.swapPending')
                            : t('tasks.requestSwap')}
                        </span>
                      </SiliconeButton>
                    )}

                    {/* Serve & Complete Button */}
                    {task.status === 'pending' && (
                      <SiliconeButton
                        variant="lavender"
                        onClick={() => void onCompleteTask(task.id)}
                        className="min-h-[42px] py-2 px-4 text-xs"
                      >
                        <Check className="w-4 h-4" />
                        <span>{t('dashboard.markAsDone')}</span>
                      </SiliconeButton>
                    )}

                    {task.status === 'paused' && (
                      <SiliconeButton
                        variant="lavender"
                        onClick={() => void onResumeTask(task.id)}
                        className="min-h-[42px] py-2 px-4 text-xs"
                      >
                        <PlayCircle className="w-4 h-4" />
                        <span>{t('tasks.resumeChore')}</span>
                      </SiliconeButton>
                    )}
                  </div>
                </div>

                {/* History Toggle */}
                {task.history.length > 0 && (
                  <div>
                    <button
                      type="button"
                      onClick={() =>
                        setExpandedHistoryIds((prev) => ({
                          ...prev,
                          [task.id]: !prev[task.id],
                        }))
                      }
                      className="text-xs font-semibold text-[#7965A5] hover:text-[#4C269A] inline-flex items-center gap-1 min-h-[32px]"
                    >
                      <span>
                        {t('tasks.completionHistory', {
                          count: task.history.length,
                        })}
                      </span>
                      {historyExpanded ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>

                    {historyExpanded && (
                      <div className="mt-2 space-y-1.5">
                        {task.history.slice(0, 6).map((h) => {
                          const who = residentMap.get(h.completedById);
                          return (
                            <div
                              key={h.id}
                              className="surface-inset rounded-xl px-3 py-2 flex items-center justify-between text-xs"
                            >
                              <span className="text-[#38216B]">
                                {t('tasks.completedByLine', {
                                  name:
                                    who?.name ?? t('common.partnerFallback'),
                                  date: formatLocalizedDate(
                                    h.completedAt,
                                    locale
                                  ),
                                })}
                              </span>
                              <span className="font-mono-num font-bold text-[#4C269A]">
                                +{h.pointsAwarded} {t('common.pts')}
                                {h.penaltyPercent > 0 && (
                                  <span className="text-[#B33981] ml-1.5">
                                    (
                                    {t('tasks.penaltyNote', {
                                      percent: h.penaltyPercent,
                                    })}
                                    )
                                  </span>
                                )}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </ClayCard>
            );
          })}
        </div>
      )}

      {/* Create / Edit Chore Modal */}
      <AnimatePresence>
        {modalOpen && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setModalOpen(false)}
              className="fixed inset-0 bg-[#38216B]/35 backdrop-blur-xs"
            />
            <motion.div
              initial={{ opacity: 0, y: 24, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.98 }}
              className="relative z-10 w-full sm:max-w-lg max-h-[90vh] overflow-y-auto surface-clay rounded-t-[30px] sm:rounded-[30px] p-6"
            >
              <div className="flex items-center justify-between gap-3 mb-4">
                <h2 className="font-editorial text-2xl font-bold text-[#38216B]">
                  {editingTask
                    ? t('tasks.modalEditTitle')
                    : t('tasks.modalCreateTitle')}
                </h2>
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  aria-label={t('common.close')}
                  className="btn-3d-cloud min-h-[40px] min-w-[40px] rounded-full inline-flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form
                onSubmit={(e) => void handleSubmitChore(e)}
                className="space-y-4"
              >
                <div>
                  <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                    {t('tasks.fieldTitle')}
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={t('tasks.fieldTitlePlaceholder')}
                    required
                    className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                    {t('tasks.fieldDescription')}
                  </label>
                  <input
                    type="text"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder={t('tasks.fieldDescriptionPlaceholder')}
                    className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                      {t('tasks.fieldCategory')}
                    </label>
                    <select
                      value={category}
                      onChange={(e) =>
                        setCategory(e.target.value as TaskCategory)
                      }
                      className="w-full min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c} value={c}>
                          {t(`tasks.categories.${c}`)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                      {t('tasks.fieldPriority')}
                    </label>
                    <select
                      value={priority}
                      onChange={(e) =>
                        setPriority(e.target.value as TaskPriority)
                      }
                      className="w-full min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
                    >
                      {PRIORITIES.map((p) => (
                        <option key={p} value={p}>
                          {t(`tasks.priorities.${p}`)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                      {t('tasks.fieldPoints')}
                    </label>
                    <input
                      type="number"
                      min={5}
                      max={200}
                      step={5}
                      value={points}
                      onChange={(e) => setPoints(Number(e.target.value))}
                      className="w-full min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm font-mono-num text-[#38216B]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                      {t('tasks.fieldFrequency')}
                    </label>
                    <select
                      value={frequency}
                      onChange={(e) =>
                        setFrequency(e.target.value as TaskFrequency)
                      }
                      className="w-full min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
                    >
                      {FREQUENCIES.map((f) => (
                        <option key={f} value={f}>
                          {t(`tasks.frequencies.${f}`)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                      {t('tasks.fieldDueDate')}
                    </label>
                    <input
                      type="date"
                      value={dueDate}
                      onChange={(e) => setDueDate(e.target.value)}
                      required
                      className="w-full min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm font-mono-num text-[#38216B]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                      {t('tasks.fieldDueTime')}
                    </label>
                    <input
                      type="time"
                      value={dueTime}
                      onChange={(e) => setDueTime(e.target.value)}
                      required
                      className="w-full min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm font-mono-num text-[#38216B]"
                    />
                  </div>
                </div>

                {frequency === 'custom' && (
                  <div>
                    <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                      {t('tasks.fieldCustomDays')}
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={90}
                      value={customIntervalDays}
                      onChange={(e) =>
                        setCustomIntervalDays(Number(e.target.value))
                      }
                      className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl surface-inset text-sm font-mono-num text-[#38216B]"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-[#7965A5] mb-1.5">
                    {t('tasks.fieldParticipants')}
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {state.residents.map((resident) => {
                      const active = participantIds.includes(resident.id);
                      return (
                        <button
                          key={resident.id}
                          type="button"
                          onClick={() => handleToggleParticipant(resident.id)}
                          className={`min-h-[42px] px-3 py-1.5 rounded-2xl flex items-center gap-2 text-xs font-semibold transition-all ${
                            active
                              ? 'btn-3d-lavender'
                              : 'btn-3d-cloud text-[#7965A5]'
                          }`}
                        >
                          <Avatar resident={resident} size="xs" />
                          <span>{resident.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#7965A5] mb-1">
                    {t('tasks.fieldAssignee')}
                  </label>
                  <select
                    value={assignedToId}
                    onChange={(e) => setAssignedToId(e.target.value)}
                    className="w-full min-h-[46px] px-3 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
                  >
                    {state.residents
                      .filter((r) => participantIds.includes(r.id))
                      .map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name}
                        </option>
                      ))}
                  </select>
                </div>

                <div className="flex gap-3 pt-2">
                  <SiliconeButton
                    variant="cloud"
                    onClick={() => setModalOpen(false)}
                    className="flex-1"
                  >
                    {t('common.cancel')}
                  </SiliconeButton>
                  <SiliconeButton
                    type="submit"
                    variant="lavender"
                    className="flex-1"
                  >
                    {t('tasks.saveChore')}
                  </SiliconeButton>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Propose Swap Modal */}
      <AnimatePresence>
        {swapTask && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSwapTask(null)}
              className="fixed inset-0 bg-[#38216B]/35 backdrop-blur-xs"
            />
            <motion.div
              initial={{ opacity: 0, y: 24, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.98 }}
              className="relative z-10 w-full sm:max-w-md surface-clay rounded-t-[30px] sm:rounded-[30px] p-6 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-editorial text-xl font-bold text-[#38216B]">
                  {t('tasks.swapModalTitle')}
                </h3>
                <button
                  type="button"
                  onClick={() => setSwapTask(null)}
                  aria-label={t('common.close')}
                  className="btn-3d-cloud min-h-[40px] min-w-[40px] rounded-full inline-flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-sm text-[#7965A5]">
                {t('tasks.swapModalDesc', { title: swapTask.title })}
              </p>
              <form
                onSubmit={(e) => void handleConfirmSwap(e)}
                className="space-y-4"
              >
                <input
                  type="text"
                  value={swapNote}
                  onChange={(e) => setSwapNote(e.target.value)}
                  placeholder={t('tasks.swapNotePlaceholder')}
                  className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
                />
                <div className="flex gap-3">
                  <SiliconeButton
                    variant="cloud"
                    onClick={() => setSwapTask(null)}
                    className="flex-1"
                  >
                    {t('common.cancel')}
                  </SiliconeButton>
                  <SiliconeButton
                    type="submit"
                    variant="lavender"
                    className="flex-1"
                  >
                    {t('tasks.sendSwapBtn')}
                  </SiliconeButton>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Pause Chore Modal */}
      <AnimatePresence>
        {pauseModalTask && (
          <div
            role="dialog"
            aria-modal="true"
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setPauseModalTask(null)}
              className="fixed inset-0 bg-[#38216B]/35 backdrop-blur-xs"
            />
            <motion.div
              initial={{ opacity: 0, y: 24, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 16, scale: 0.98 }}
              className="relative z-10 w-full sm:max-w-md surface-clay rounded-t-[30px] sm:rounded-[30px] p-6 space-y-4"
            >
              <div className="flex items-center justify-between">
                <h3 className="font-editorial text-xl font-bold text-[#38216B]">
                  {t('tasks.pauseModalTitle')}
                </h3>
                <button
                  type="button"
                  onClick={() => setPauseModalTask(null)}
                  aria-label={t('common.close')}
                  className="btn-3d-cloud min-h-[40px] min-w-[40px] rounded-full inline-flex items-center justify-center"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-sm text-[#7965A5]">
                {t('tasks.pauseModalDesc', { title: pauseModalTask.title })}
              </p>
              <form
                onSubmit={(e) => void handleConfirmPause(e)}
                className="space-y-4"
              >
                <input
                  type="text"
                  value={pauseReason}
                  onChange={(e) => setPauseReason(e.target.value)}
                  placeholder={t('tasks.pauseReasonPlaceholder')}
                  className="w-full min-h-[46px] px-4 py-2.5 rounded-2xl surface-inset text-sm text-[#38216B]"
                />
                <div className="flex gap-3">
                  <SiliconeButton
                    variant="cloud"
                    onClick={() => setPauseModalTask(null)}
                    className="flex-1"
                  >
                    {t('common.cancel')}
                  </SiliconeButton>
                  <SiliconeButton
                    type="submit"
                    variant="lavender"
                    className="flex-1"
                  >
                    {t('common.pause')}
                  </SiliconeButton>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Confirm Delete Chore */}
      <ConfirmModal
        open={Boolean(confirmDeleteTask)}
        title={t('tasks.deleteTitle')}
        description={t('tasks.deleteDesc', {
          title: confirmDeleteTask?.title ?? '',
        })}
        confirmLabel={t('tasks.deleteConfirm')}
        onConfirm={() => {
          if (confirmDeleteTask) {
            void onDeleteTask(confirmDeleteTask.id);
          }
          setConfirmDeleteTask(null);
        }}
        onCancel={() => setConfirmDeleteTask(null)}
      />
    </div>
  );
}
