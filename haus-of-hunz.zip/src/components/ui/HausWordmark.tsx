import { useId } from 'react';

interface HausWordmarkProps {
  variant?: 'hero' | 'splash' | 'sidebar' | 'compact';
  tone?: 'light' | 'dark';
  showCrest?: boolean;
  showTagline?: boolean;
  tagline?: string;
  className?: string;
}

export function HausCrest({
  size = 'md',
  className = '',
}: {
  size?: 'xs' | 'sm' | 'md' | 'lg';
  className?: string;
}) {
  const uid = useId().replace(/:/g, '');
  const dims =
    size === 'xs'
      ? 'w-7 h-7'
      : size === 'sm'
        ? 'w-9 h-9'
        : size === 'lg'
          ? 'w-14 h-14'
          : 'w-11 h-11';

  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      aria-hidden="true"
      className={`${dims} shrink-0 drop-shadow-[0_6px_14px_rgba(76,38,154,0.28)] ${className}`}
    >
      <defs>
        <linearGradient id={`hausBg-${uid}`} x1="8" y1="6" x2="56" y2="58" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#D7BEFA" />
          <stop offset="52%" stopColor="#9672E8" />
          <stop offset="100%" stopColor="#5B31B3" />
        </linearGradient>
        <linearGradient id={`hausCrown-${uid}`} x1="18" y1="18" x2="46" y2="46" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FFF8FF" />
          <stop offset="100%" stopColor="#F7D5E9" />
        </linearGradient>
      </defs>
      <rect
        x="2"
        y="2"
        width="60"
        height="60"
        rx="18"
        fill={`url(#hausBg-${uid})`}
        stroke="rgba(255,248,255,0.65)"
        strokeWidth="1.5"
      />
      <circle cx="20" cy="18" r="11" fill="#F5B5DA" fillOpacity="0.32" />
      <path
        d="M17 31L32 18.5L47 31V44.5C47 46.709 45.209 48.5 43 48.5H21C18.791 48.5 17 46.709 17 44.5V31Z"
        fill={`url(#hausCrown-${uid})`}
      />
      <path
        d="M24 31.5L28 36.5L32 29L36 36.5L40 31.5L38.6 41.5H25.4L24 31.5Z"
        fill="#7E56DC"
      />
      <circle cx="32" cy="26.5" r="2.2" fill="#ED82BE" />
      <circle cx="23.5" cy="29.5" r="1.8" fill="#ED82BE" />
      <circle cx="40.5" cy="29.5" r="1.8" fill="#ED82BE" />
    </svg>
  );
}

export function HausWordmark({
  variant = 'sidebar',
  tone = 'dark',
  showCrest = true,
  showTagline = false,
  tagline,
  className = '',
}: HausWordmarkProps) {
  const isLight = tone === 'light';

  if (variant === 'compact') {
    return (
      <span
        aria-label="HAUS OF HUNZ"
        className={`inline-flex items-center gap-2 whitespace-nowrap shrink-0 select-none ${className}`}
      >
        {showCrest && <HausCrest size="xs" />}
        <span className="inline-flex items-baseline gap-1 font-editorial tracking-[0.06em] leading-none">
          <span
            className={`text-sm font-extrabold ${
              isLight ? 'text-[#FFF8FF]' : 'text-[#38216B]'
            }`}
          >
            HAUS
          </span>
          <span
            className={`text-[10px] italic font-semibold tracking-[0.14em] ${
              isLight ? 'text-[#F7D5E9]' : 'text-[#B33981]'
            }`}
          >
            of
          </span>
          <span
            className={`text-sm font-extrabold bg-clip-text text-transparent ${
              isLight
                ? 'bg-gradient-to-r from-[#FFF8FF] via-[#FFE3F4] to-[#E2D2FF]'
                : 'bg-gradient-to-r from-[#4C269A] via-[#7A4CE0] to-[#B33981]'
            }`}
          >
            HUNZ
          </span>
        </span>
      </span>
    );
  }

  if (variant === 'sidebar') {
    return (
      <div
        aria-label="HAUS OF HUNZ"
        className={`flex items-center gap-2.5 select-none ${className}`}
      >
        {showCrest && <HausCrest size="sm" />}
        <div className="min-w-0 leading-none">
          <div className="flex items-center gap-1.5">
            <span
              className={`font-editorial text-[13px] font-extrabold tracking-[0.16em] ${
                isLight ? 'text-[#FFF8FF]' : 'text-[#38216B]'
              }`}
            >
              HAUS
            </span>
            <span
              className={`font-editorial italic text-[10px] font-semibold tracking-[0.12em] ${
                isLight ? 'text-[#F7D5E9]' : 'text-[#B33981]'
              }`}
            >
              of
            </span>
          </div>
          <div
            className={`font-editorial text-[21px] font-extrabold tracking-[0.11em] bg-clip-text text-transparent mt-0.5 whitespace-nowrap ${
              isLight
                ? 'bg-gradient-to-r from-[#FFF8FF] via-[#FFE3F4] to-[#DEC9FF]'
                : 'bg-gradient-to-r from-[#38216B] via-[#6E45CC] to-[#C23B89]'
            }`}
          >
            HUNZ
          </div>
        </div>
      </div>
    );
  }

  const isSplash = variant === 'splash';

  return (
    <div
      aria-label="HAUS OF HUNZ"
      className={`flex flex-col ${
        isSplash ? 'items-center text-center' : 'items-start text-left'
      } select-none ${className}`}
    >
      <div
        className={`flex items-center ${
          isSplash ? 'flex-col gap-3' : 'gap-3'
        }`}
      >
        {showCrest && <HausCrest size={isSplash ? 'lg' : 'md'} />}
        <div className={isSplash ? 'space-y-0.5' : 'space-y-0'}>
          <div
            className={`flex items-center gap-2 ${
              isSplash ? 'justify-center' : 'justify-start'
            }`}
          >
            <span
              className={`font-editorial text-sm sm:text-base font-extrabold tracking-[0.26em] ${
                isLight
                  ? 'text-[#FFF8FF] drop-shadow-[0_2px_8px_rgba(32,12,72,0.5)]'
                  : 'text-[#38216B]'
              }`}
            >
              HAUS
            </span>
            <span
              aria-hidden="true"
              className={`h-[1px] w-4 ${
                isLight ? 'bg-[#F7D5E9]/70' : 'bg-[#9672E8]/45'
              }`}
            />
            <span
              className={`font-editorial italic text-xs sm:text-sm font-semibold tracking-[0.18em] ${
                isLight
                  ? 'text-[#FFE2F3] drop-shadow-[0_2px_8px_rgba(32,12,72,0.45)]'
                  : 'text-[#B33981]'
              }`}
            >
              OF
            </span>
            <span
              aria-hidden="true"
              className={`h-[1px] w-4 ${
                isLight ? 'bg-[#F7D5E9]/70' : 'bg-[#9672E8]/45'
              }`}
            />
          </div>

          <div
            className={`font-editorial ${
              isSplash
                ? 'text-4xl sm:text-5xl tracking-[0.14em]'
                : 'text-3xl sm:text-4xl tracking-[0.12em]'
            } font-extrabold leading-[0.98] bg-clip-text text-transparent ${
              isLight
                ? 'bg-gradient-to-r from-[#FFF8FF] via-[#FFE2F3] to-[#DFCEFF] drop-shadow-[0_4px_14px_rgba(32,12,72,0.62)]'
                : 'bg-gradient-to-r from-[#38216B] via-[#6E45CC] to-[#C23B89] drop-shadow-[0_3px_10px_rgba(150,114,232,0.18)]'
            }`}
          >
            HUNZ
          </div>
        </div>
      </div>

      {showTagline && tagline && (
        <p
          className={`mt-2 text-xs sm:text-sm font-medium tracking-wide ${
            isLight
              ? 'text-[#F4E8FF] drop-shadow-[0_1px_6px_rgba(32,12,72,0.55)]'
              : 'text-[#6A5499]'
          }`}
        >
          {tagline}
        </p>
      )}
    </div>
  );
}
