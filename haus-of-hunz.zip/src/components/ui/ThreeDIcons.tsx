import { ReactNode } from 'react';

export type ThreeDIconKind =
  | 'cleaning'
  | 'shopping'
  | 'shade'
  | 'residents'
  | 'calendar'
  | 'rewards'
  | 'notes'
  | 'achievements';

interface ThreeDIconProps {
  kind: ThreeDIconKind;
  size?: 'sm' | 'md' | 'lg';
  shape?: 'squircle' | 'circle';
  className?: string;
}

const TILE_GRADIENTS: Record<
  ThreeDIconKind,
  { bg: string; shadow: string }
> = {
  cleaning: {
    bg: 'linear-gradient(145deg, #D5A3F7 0%, #9E73EC 55%, #7E53D4 100%)',
    shadow: '0 10px 20px -5px rgba(126, 83, 212, 0.42)',
  },
  shopping: {
    bg: 'linear-gradient(145deg, #FFD9A0 0%, #FFA97A 58%, #EE8462 100%)',
    shadow: '0 10px 20px -5px rgba(238, 132, 98, 0.42)',
  },
  shade: {
    bg: 'linear-gradient(145deg, #FBBEE2 0%, #ED82BE 55%, #C95297 100%)',
    shadow: '0 10px 20px -5px rgba(201, 82, 151, 0.42)',
  },
  residents: {
    bg: 'linear-gradient(145deg, #A9C2FF 0%, #8EA8F5 55%, #657CE0 100%)',
    shadow: '0 10px 20px -5px rgba(101, 124, 224, 0.42)',
  },
  calendar: {
    bg: 'linear-gradient(145deg, #C7B8FF 0%, #9672E8 100%)',
    shadow: '0 10px 20px -5px rgba(150, 114, 232, 0.38)',
  },
  rewards: {
    bg: 'linear-gradient(145deg, #FFE2AE 0%, #F7B16D 100%)',
    shadow: '0 10px 20px -5px rgba(247, 177, 109, 0.42)',
  },
  notes: {
    bg: 'linear-gradient(145deg, #F9CBE8 0%, #EC93C8 100%)',
    shadow: '0 10px 20px -5px rgba(236, 147, 200, 0.4)',
  },
  achievements: {
    bg: 'linear-gradient(145deg, #FDE2A6 0%, #F2A463 55%, #DF7D4A 100%)',
    shadow: '0 10px 20px -5px rgba(223, 125, 74, 0.4)',
  },
};

const SIZE_MAP: Record<NonNullable<ThreeDIconProps['size']>, string> = {
  sm: 'w-10 h-10',
  md: 'w-12 h-12',
  lg: 'w-14 h-14',
};

const SVG_SIZE_MAP: Record<NonNullable<ThreeDIconProps['size']>, string> = {
  sm: 'w-5 h-5',
  md: 'w-6 h-6',
  lg: 'w-7 h-7',
};

function renderIconSvg(kind: ThreeDIconKind, svgClass: string): ReactNode {
  switch (kind) {
    case 'cleaning':
      return (
        <svg viewBox="0 0 32 32" className={svgClass} fill="none" aria-hidden="true">
          <defs>
            <linearGradient id="clay-clean" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#F4E6FF" />
            </linearGradient>
          </defs>
          <path
            d="M16 4l2.2 6.3L24.5 12.5l-6.3 2.2L16 21l-2.2-6.3-6.3-2.2 6.3-2.2L16 4z"
            fill="url(#clay-clean)"
          />
          <circle cx="24" cy="22.5" r="3.2" fill="#FFF8FF" fillOpacity="0.92" />
          <circle cx="8.5" cy="23.5" r="2" fill="#FFF8FF" fillOpacity="0.8" />
        </svg>
      );
    case 'shopping':
      return (
        <svg viewBox="0 0 32 32" className={svgClass} fill="none" aria-hidden="true">
          <path
            d="M8.5 12.5h15c1.1 0 1.9 1 1.7 2.1l-1.5 8.2a2.5 2.5 0 01-2.5 2H10.8a2.5 2.5 0 01-2.5-2l-1.5-8.2c-.2-1.1.6-2.1 1.7-2.1z"
            fill="#FFF8FF"
          />
          <path
            d="M11.5 12.5V10a4.5 4.5 0 019 0v2.5"
            stroke="#FFF8FF"
            strokeWidth="2.4"
            strokeLinecap="round"
          />
          <circle cx="13" cy="18.5" r="1.3" fill="#EE8462" />
          <circle cx="19" cy="18.5" r="1.3" fill="#EE8462" />
        </svg>
      );
    case 'shade':
      return (
        <svg viewBox="0 0 32 32" className={svgClass} fill="none" aria-hidden="true">
          <path
            d="M16 25c6-3.2 10-8.6 10-14.5A4.5 4.5 0 0021.5 6H16v19z"
            fill="#FFF8FF"
          />
          <path
            d="M16 25c-6-3.2-10-8.6-10-14.5A4.5 4.5 0 0110.5 6H16v19z"
            fill="#FFE3F3"
          />
          <path
            d="M16 6v20"
            stroke="#C95297"
            strokeWidth="1.8"
            strokeLinecap="round"
          />
        </svg>
      );
    case 'residents':
      return (
        <svg viewBox="0 0 32 32" className={svgClass} fill="none" aria-hidden="true">
          <path
            d="M6.5 15.2L16 7l9.5 8.2v9a2.3 2.3 0 01-2.3 2.3H8.8a2.3 2.3 0 01-2.3-2.3v-9z"
            fill="#FFF8FF"
          />
          <path
            d="M16 14.2c1.1-1.3 3.2-1.1 4 .4.7 1.3.1 2.9-1.2 4L16 21.2l-2.8-2.6c-1.3-1.1-1.9-2.7-1.2-4 .8-1.5 2.9-1.7 4-.4z"
            fill="#ED82BE"
          />
        </svg>
      );
    case 'calendar':
      return (
        <svg viewBox="0 0 32 32" className={svgClass} fill="none" aria-hidden="true">
          <rect x="6" y="7.5" width="20" height="18" rx="4" fill="#FFF8FF" />
          <path
            d="M10.5 5.5v3.5M21.5 5.5v3.5"
            stroke="#FFF8FF"
            strokeWidth="2.4"
            strokeLinecap="round"
          />
          <rect x="10" y="14" width="4" height="4" rx="1.2" fill="#9672E8" />
          <rect x="17.5" y="14" width="4" height="4" rx="1.2" fill="#C5A6F5" />
        </svg>
      );
    case 'rewards':
      return (
        <svg viewBox="0 0 32 32" className={svgClass} fill="none" aria-hidden="true">
          <path
            d="M16 5.5l3.1 6.3 6.9 1-5 4.8 1.2 6.9L16 21.2l-6.2 3.3 1.2-6.9-5-4.8 6.9-1L16 5.5z"
            fill="#FFF8FF"
          />
        </svg>
      );
    case 'notes':
      return (
        <svg viewBox="0 0 32 32" className={svgClass} fill="none" aria-hidden="true">
          <path
            d="M8 6.5h16a2 2 0 012 2v11l-6 6H8a2 2 0 01-2-2v-15a2 2 0 012-2z"
            fill="#FFF8FF"
          />
          <path d="M20 19.5h6l-6 6v-6z" fill="#F5B5DA" />
          <path
            d="M10.5 12h11M10.5 16h7"
            stroke="#EC93C8"
            strokeWidth="2"
            strokeLinecap="round"
          />
        </svg>
      );
    case 'achievements':
      return (
        <svg viewBox="0 0 32 32" className={svgClass} fill="none" aria-hidden="true">
          <path
            d="M10 7h12v6.5a6 6 0 01-12 0V7z"
            fill="#FFF8FF"
          />
          <path
            d="M10 9.5H7.2a1.8 1.8 0 00-1.7 2.2c.4 1.8 1.9 3.3 4.5 3.5M22 9.5h2.8a1.8 1.8 0 011.7 2.2c-.4 1.8-1.9 3.3-4.5 3.5"
            stroke="#FFF8FF"
            strokeWidth="2.1"
            strokeLinecap="round"
          />
          <path
            d="M16 19.5v4.5M12 24.5h8"
            stroke="#FFF8FF"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
      );
  }
}

export function ThreeDIcon({
  kind,
  size = 'md',
  shape = 'squircle',
  className = '',
}: ThreeDIconProps) {
  const style = TILE_GRADIENTS[kind];
  const radiusClass = shape === 'circle' ? 'rounded-full' : 'rounded-[18px]';

  return (
    <span
      style={{
        background: style.bg,
        boxShadow: `${style.shadow}, inset 0 2px 3px rgba(255,255,255,0.65), inset 0 -3px 6px rgba(56,33,107,0.18)`,
      }}
      className={`${SIZE_MAP[size]} ${radiusClass} border border-white/50 inline-flex items-center justify-center shrink-0 select-none ${className}`}
    >
      {renderIconSvg(kind, SVG_SIZE_MAP[size])}
    </span>
  );
}
