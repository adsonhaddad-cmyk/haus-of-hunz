import { ReactNode } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { ThreeDIcon, ThreeDIconKind } from './ThreeDIcons';

interface ClayCardProps {
  children: ReactNode;
  variant?: 'clay' | 'glass';
  className?: string;
}

export function ClayCard({
  children,
  variant = 'clay',
  className = '',
}: ClayCardProps) {
  const variantClass = variant === 'glass' ? 'surface-glass' : 'surface-clay';
  return (
    <div className={`${variantClass} rounded-[28px] ${className}`}>
      {children}
    </div>
  );
}

interface SiliconeButtonProps {
  children: ReactNode;
  variant?: 'lavender' | 'pink' | 'cloud';
  type?: 'button' | 'submit' | 'reset';
  disabled?: boolean;
  onClick?: () => void;
  ariaLabel?: string;
  className?: string;
}

export function SiliconeButton({
  children,
  variant = 'lavender',
  type = 'button',
  disabled = false,
  onClick,
  ariaLabel,
  className = '',
}: SiliconeButtonProps) {
  const variantClass =
    variant === 'pink'
      ? 'btn-3d-pink'
      : variant === 'cloud'
        ? 'btn-3d-cloud'
        : 'btn-3d-lavender';

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      aria-label={ariaLabel}
      className={`${variantClass} min-h-[44px] px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold inline-flex items-center justify-center gap-2 transition-all duration-150 disabled:opacity-45 disabled:pointer-events-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#4C269A] focus-visible:ring-offset-2 whitespace-nowrap ${className}`}
    >
      {children}
    </button>
  );
}

interface ProgressBarProps {
  percent: number;
  color?: string;
  className?: string;
}

export function ClayProgressBar({
  percent,
  color = 'linear-gradient(90deg, #9672E8 0%, #F5B5DA 100%)',
  className = '',
}: ProgressBarProps) {
  const clamped = Math.max(4, Math.min(100, percent));
  return (
    <div
      className={`h-2.5 w-full rounded-full surface-inset overflow-hidden p-0.5 ${className}`}
    >
      <div
        className="h-full rounded-full transition-all duration-500 ease-out"
        style={{
          width: `${clamped}%`,
          background: color,
          boxShadow: 'inset 0 1px 2px rgba(255,255,255,0.6)',
        }}
      />
    </div>
  );
}

interface EmptyStateProps {
  iconKind: ThreeDIconKind;
  title: string;
  description: string;
  action?: ReactNode;
}

export function EmptyState({
  iconKind,
  title,
  description,
  action,
}: EmptyStateProps) {
  return (
    <div className="py-10 px-6 text-center rounded-[24px] surface-inset">
      <div className="flex justify-center mb-3">
        <ThreeDIcon kind={iconKind} size="lg" />
      </div>
      <p className="font-editorial text-lg font-bold text-[#38216B]">{title}</p>
      <p className="text-xs sm:text-sm text-[#7965A5] mt-1 max-w-sm mx-auto leading-relaxed">
        {description}
      </p>
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}

interface ConfirmModalProps {
  open: boolean;
  title: string;
  description: string;
  confirmLabel?: string;
  cancelLabel?: string;
  confirmTone?: 'pink' | 'lavender';
  onConfirm: () => void;
  onCancel: () => void;
}

export function ConfirmModal({
  open,
  title,
  description,
  confirmLabel,
  cancelLabel,
  confirmTone = 'pink',
  onConfirm,
  onCancel,
}: ConfirmModalProps) {
  const { t } = useTranslation();
  const resolvedConfirm = confirmLabel ?? t('common.confirm');
  const resolvedCancel = cancelLabel ?? t('common.cancel');

  return (
    <AnimatePresence>
      {open && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onCancel}
            className="fixed inset-0 bg-[#38216B]/35 backdrop-blur-xs"
          />
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 w-full sm:max-w-md surface-clay rounded-t-[30px] sm:rounded-[30px] p-6"
          >
            <div className="w-10 h-1.5 bg-[#C5A6F5]/60 rounded-full mx-auto mb-4 sm:hidden" />
            <div className="flex items-start justify-between gap-3">
              <h3 className="font-editorial text-xl font-bold text-[#38216B]">
                {title}
              </h3>
              <button
                type="button"
                onClick={onCancel}
                aria-label={t('common.close')}
                className="min-h-[40px] min-w-[40px] rounded-full btn-3d-cloud inline-flex items-center justify-center shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-sm text-[#7965A5] mt-2 leading-relaxed">
              {description}
            </p>
            <div className="mt-6 flex gap-3">
              <SiliconeButton
                variant="cloud"
                onClick={onCancel}
                className="flex-1"
              >
                {resolvedCancel}
              </SiliconeButton>
              <SiliconeButton
                variant={confirmTone}
                onClick={onConfirm}
                className="flex-1"
              >
                {resolvedConfirm}
              </SiliconeButton>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
