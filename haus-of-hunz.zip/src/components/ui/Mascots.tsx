import { motion } from 'motion/react';

export type MascotId =
  | 'miss-mop'
  | 'dusty-drama'
  | 'sir-scrub'
  | 'grocery-diva'
  | 'madame-deadline';

export type MascotMood = 'idle' | 'celebrating' | 'shady' | 'panicked' | 'proud';

interface MascotProps {
  id: MascotId;
  mood?: MascotMood;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const SIZE_PX: Record<NonNullable<MascotProps['size']>, string> = {
  sm: 'w-14 h-14',
  md: 'w-20 h-20',
  lg: 'w-24 h-24',
  xl: 'w-28 h-28',
};

function getMotionPreset(mood: MascotMood) {
  switch (mood) {
    case 'celebrating':
      return {
        animate: { y: [0, -7, 0], rotate: [0, -4, 4, 0], scale: [1, 1.05, 1] },
        transition: { duration: 1.5, repeat: Infinity, ease: 'easeInOut' as const },
      };
    case 'panicked':
      return {
        animate: { x: [-2, 2, -2, 2, 0], rotate: [-3, 3, -3, 0] },
        transition: { duration: 0.75, repeat: Infinity, ease: 'easeInOut' as const },
      };
    case 'shady':
      return {
        animate: { rotate: [0, -4, 0], y: [0, -2, 0] },
        transition: { duration: 2.2, repeat: Infinity, ease: 'easeInOut' as const },
      };
    case 'proud':
      return {
        animate: { y: [0, -4, 0], scale: [1, 1.03, 1] },
        transition: { duration: 2.4, repeat: Infinity, ease: 'easeInOut' as const },
      };
    default:
      return {
        animate: { y: [0, -3, 0] },
        transition: { duration: 3, repeat: Infinity, ease: 'easeInOut' as const },
      };
  }
}

export function Mascot({
  id,
  mood = 'idle',
  size = 'md',
  className = '',
}: MascotProps) {
  const preset = getMotionPreset(mood);

  return (
    <motion.div
      animate={preset.animate}
      transition={preset.transition}
      className={`${SIZE_PX[size]} inline-flex items-center justify-center shrink-0 select-none ${className}`}
      aria-hidden="true"
    >
      {id === 'miss-mop' && <MissMopSvg mood={mood} />}
      {id === 'dusty-drama' && <DustyDramaSvg mood={mood} />}
      {id === 'sir-scrub' && <SirScrubSvg mood={mood} />}
      {id === 'grocery-diva' && <GroceryDivaSvg mood={mood} />}
      {id === 'madame-deadline' && <MadameDeadlineSvg mood={mood} />}
    </motion.div>
  );
}

function MissMopSvg({ mood }: { mood: MascotMood }) {
  const isShady = mood === 'shady' || mood === 'panicked';
  const isHappy = mood === 'celebrating' || mood === 'proud';
  return (
    <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-[0_10px_14px_rgba(76,38,154,0.22)]">
      <defs>
        <linearGradient id="mop-handle" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#FFF8FF" />
          <stop offset="45%" stopColor="#D7BEF9" />
          <stop offset="100%" stopColor="#8A63E2" />
        </linearGradient>
        <linearGradient id="mop-fringe" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FBBCE1" />
          <stop offset="55%" stopColor="#C5A6F5" />
          <stop offset="100%" stopColor="#8861E0" />
        </linearGradient>
        <radialGradient id="mop-face" cx="40%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#FFF8FF" />
          <stop offset="65%" stopColor="#F5D9F0" />
          <stop offset="100%" stopColor="#D8B6F5" />
        </radialGradient>
      </defs>
      {/* Glossy Mop Handle */}
      <rect x="55" y="6" width="10" height="38" rx="5" fill="url(#mop-handle)" stroke="#FFF8FF" strokeWidth="1.5" />
      <circle cx="60" cy="8" r="6" fill="#ED82BE" stroke="#FFF8FF" strokeWidth="1.5" />

      {/* Glamorous Bow Collar */}
      <path d="M40 34 C32 24, 52 26, 58 35 C64 26, 84 24, 76 34 C72 41, 63 39, 60 36 C57 39, 44 41, 40 34 Z" fill="#ED82BE" stroke="#FFF8FF" strokeWidth="1.5" />
      <circle cx="60" cy="35" r="5" fill="#FFF8FF" />

      {/* Mop Fringe Skirt */}
      <path
        d="M22 68 C22 46, 38 36, 60 36 C82 36, 98 46, 98 68 L104 96 C104 104, 96 108, 90 103 C85 109, 77 109, 73 103 C68 110, 52 110, 47 103 C43 109, 35 109, 30 103 C24 108, 16 104, 16 96 Z"
        fill="url(#mop-fringe)"
        stroke="#FFF8FF"
        strokeWidth="2"
      />
      {/* Fringe Highlight Ribs */}
      <path d="M32 76 L28 100 M46 78 L45 102 M60 80 L60 104 M74 78 L75 102 M88 76 L92 100" stroke="#FFF8FF" strokeOpacity="0.45" strokeWidth="3" strokeLinecap="round" />

      {/* Sculpted Face Medallion */}
      <ellipse cx="60" cy="64" rx="26" ry="22" fill="url(#mop-face)" stroke="#FFF8FF" strokeWidth="2" />

      {/* Blush Cheeks */}
      <ellipse cx="42" cy="69" rx="5.5" ry="3" fill="#ED82BE" fillOpacity="0.45" />
      <ellipse cx="78" cy="69" rx="5.5" ry="3" fill="#ED82BE" fillOpacity="0.45" />

      {/* Dramatic Lashes & Eyes */}
      <path d="M41 56 L36 51 M45 55 L42 49 M49 56 L49 50" stroke="#38216B" strokeWidth="2" strokeLinecap="round" />
      <path d="M71 56 L71 50 M75 55 L78 49 M79 56 L84 51" stroke="#38216B" strokeWidth="2" strokeLinecap="round" />
      <ellipse cx="47" cy="61" rx="4.2" ry={isShady ? '2.6' : '4.6'} fill="#38216B" />
      <ellipse cx="73" cy="61" rx="4.2" ry={isShady ? '3.2' : '4.6'} fill="#38216B" />
      <circle cx="48.5" cy="59.5" r="1.5" fill="#FFF8FF" />
      <circle cx="74.5" cy="59.5" r="1.5" fill="#FFF8FF" />

      {/* Shady Raised Brow */}
      {isShady ? (
        <>
          <path d="M40 53 L53 56" stroke="#4C269A" strokeWidth="2.4" strokeLinecap="round" />
          <path d="M67 52 Q74 47 80 53" stroke="#4C269A" strokeWidth="2.4" fill="none" strokeLinecap="round" />
        </>
      ) : null}

      {/* Mouth */}
      {isHappy ? (
        <path d="M51 72 Q60 80 69 72" stroke="#B33981" strokeWidth="2.8" fill="none" strokeLinecap="round" />
      ) : isShady ? (
        <path d="M52 74 Q61 71 69 75" stroke="#B33981" strokeWidth="2.6" fill="none" strokeLinecap="round" />
      ) : (
        <path d="M53 73 Q60 77 67 73" stroke="#B33981" strokeWidth="2.5" fill="none" strokeLinecap="round" />
      )}
    </svg>
  );
}

function DustyDramaSvg({ mood }: { mood: MascotMood }) {
  return (
    <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-[0_10px_14px_rgba(76,38,154,0.22)]">
      <defs>
        <radialGradient id="dusty-body" cx="38%" cy="32%" r="70%">
          <stop offset="0%" stopColor="#FCE4F4" />
          <stop offset="55%" stopColor="#C9A8F6" />
          <stop offset="100%" stopColor="#7C56D6" />
        </radialGradient>
      </defs>
      {/* Floating dust motes */}
      <circle cx="18" cy="40" r="4" fill="#F5B5DA" fillOpacity="0.85" />
      <circle cx="102" cy="46" r="5" fill="#C5A6F5" fillOpacity="0.85" />
      <circle cx="24" cy="92" r="3" fill="#FFC3A6" fillOpacity="0.9" />

      {/* Bunny Ears */}
      <ellipse cx="42" cy="30" rx="10" ry="22" transform="rotate(-14 42 30)" fill="url(#dusty-body)" stroke="#FFF8FF" strokeWidth="2" />
      <ellipse cx="78" cy="30" rx="10" ry="22" transform="rotate(14 78 30)" fill="url(#dusty-body)" stroke="#FFF8FF" strokeWidth="2" />
      <ellipse cx="43" cy="31" rx="5" ry="13" transform="rotate(-14 43 31)" fill="#F5B5DA" />
      <ellipse cx="77" cy="31" rx="5" ry="13" transform="rotate(14 77 31)" fill="#F5B5DA" />

      {/* Fluffy Cloud Body */}
      <path
        d="M28 74 C18 68, 22 50, 34 48 C40 36, 56 34, 62 38 C70 32, 86 38, 88 50 C100 54, 102 72, 90 78 C94 92, 80 104, 66 100 C56 106, 40 102, 36 94 C24 94, 20 82, 28 74 Z"
        fill="url(#dusty-body)"
        stroke="#FFF8FF"
        strokeWidth="2.2"
      />

      {/* Tiny Crooked Drama Crown */}
      <path d="M51 34 L54 22 L61 28 L68 20 L71 34 Z" fill="#FFC3A6" stroke="#FFF8FF" strokeWidth="1.5" />

      {/* Mischievous Side-Eye */}
      <ellipse cx="49" cy="65" rx="6.5" ry="7" fill="#FFF8FF" />
      <ellipse cx="72" cy="65" rx="6.5" ry="7" fill="#FFF8FF" />
      <circle cx={mood === 'panicked' ? 49 : 51} cy="65" r="3.4" fill="#38216B" />
      <circle cx={mood === 'panicked' ? 72 : 74} cy="65" r="3.4" fill="#38216B" />
      <circle cx="52" cy="63.5" r="1.2" fill="#FFF8FF" />
      <circle cx="75" cy="63.5" r="1.2" fill="#FFF8FF" />
      <path d="M42 56 L55 59" stroke="#38216B" strokeWidth="2.3" strokeLinecap="round" />
      <path d="M66 59 L79 56" stroke="#38216B" strokeWidth="2.3" strokeLinecap="round" />

      {/* Smirk / Gasp */}
      {mood === 'panicked' ? (
        <ellipse cx="60" cy="80" rx="5" ry="6" fill="#4C269A" />
      ) : (
        <path d="M52 79 Q60 85 70 77" stroke="#38216B" strokeWidth="2.6" fill="none" strokeLinecap="round" />
      )}
    </svg>
  );
}

function SirScrubSvg({ mood }: { mood: MascotMood }) {
  return (
    <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-[0_10px_14px_rgba(76,38,154,0.22)]">
      <defs>
        <linearGradient id="scrub-body" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#FFE1BD" />
          <stop offset="55%" stopColor="#F5B5DA" />
          <stop offset="100%" stopColor="#9672E8" />
        </linearGradient>
      </defs>
      {/* Suds bubbles */}
      <circle cx="24" cy="28" r="8" fill="#FFF8FF" fillOpacity="0.85" stroke="#C5A6F5" strokeWidth="1.5" />
      <circle cx="96" cy="24" r="6" fill="#FFF8FF" fillOpacity="0.85" stroke="#F5B5DA" strokeWidth="1.5" />
      <circle cx="102" cy="86" r="5" fill="#FFF8FF" fillOpacity="0.8" />

      {/* Plush Rounded Sponge Body */}
      <rect x="26" y="24" width="68" height="72" rx="22" fill="url(#scrub-body)" stroke="#FFF8FF" strokeWidth="2.5" />
      {/* Scrubbing Top Trim */}
      <rect x="28" y="26" width="64" height="16" rx="12" fill="#8EA8F5" fillOpacity="0.65" />
      {/* Sponge Pores */}
      <circle cx="38" cy="48" r="2.8" fill="#4C269A" fillOpacity="0.18" />
      <circle cx="82" cy="52" r="3" fill="#4C269A" fillOpacity="0.18" />
      <circle cx="37" cy="82" r="2.5" fill="#4C269A" fillOpacity="0.18" />

      {/* Eyes + Monocle */}
      <circle cx="48" cy="58" r="4.5" fill="#38216B" />
      <circle cx="72" cy="58" r="4.5" fill="#38216B" />
      <circle cx="49.5" cy="56.5" r="1.5" fill="#FFF8FF" />
      <circle cx="73.5" cy="56.5" r="1.5" fill="#FFF8FF" />
      <circle cx="72" cy="58" r="9.5" fill="#FFF8FF" fillOpacity="0.2" stroke="#FFC3A6" strokeWidth="2.2" />
      <path d="M81 62 Q86 74 82 86" stroke="#FFC3A6" strokeWidth="1.6" fill="none" />

      {/* Dapper Mustache & Smile */}
      <path d="M48 69 Q54 65 60 69 Q66 65 72 69" stroke="#4C269A" strokeWidth="3" fill="none" strokeLinecap="round" />
      {mood === 'celebrating' ? (
        <path d="M51 74 Q60 83 69 74" stroke="#B33981" strokeWidth="2.8" fill="none" strokeLinecap="round" />
      ) : null}

      {/* Bow Tie */}
      <path d="M47 88 L60 94 L47 100 Z M73 88 L60 94 L73 100 Z" fill="#4C269A" stroke="#FFF8FF" strokeWidth="1.4" />
      <circle cx="60" cy="94" r="3.5" fill="#ED82BE" />
    </svg>
  );
}

function GroceryDivaSvg({ mood }: { mood: MascotMood }) {
  return (
    <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-[0_10px_14px_rgba(216,105,170,0.28)]">
      <defs>
        <linearGradient id="diva-bag" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#FFE0CA" />
          <stop offset="50%" stopColor="#F8A8D6" />
          <stop offset="100%" stopColor="#9672E8" />
        </linearGradient>
      </defs>
      {/* Baguette & Greens Peeking Out */}
      <rect x="36" y="16" width="12" height="32" rx="6" transform="rotate(-12 36 16)" fill="#FFC3A6" stroke="#FFF8FF" strokeWidth="1.5" />
      <circle cx="76" cy="28" r="10" fill="#A9E5BB" stroke="#FFF8FF" strokeWidth="1.5" />

      {/* Tote Handles */}
      <path d="M44 42 V28 C44 18, 76 18, 76 28 V42" stroke="#FFF8FF" strokeWidth="5" fill="none" strokeLinecap="round" />

      {/* Glossy Handbag Tote Body */}
      <path
        d="M26 42 H94 L88 98 C87 104, 82 108, 76 108 H44 C38 108, 33 104, 32 98 Z"
        fill="url(#diva-bag)"
        stroke="#FFF8FF"
        strokeWidth="2.4"
      />

      {/* Cat-Eye Sunglasses */}
      <path d="M34 60 L55 63 C55 71, 47 74, 41 72 C36 70, 34 65, 34 60 Z" fill="#38216B" stroke="#FFF8FF" strokeWidth="1.8" />
      <path d="M86 60 L65 63 C65 71, 73 74, 79 72 C84 70, 86 65, 86 60 Z" fill="#38216B" stroke="#FFF8FF" strokeWidth="1.8" />
      <path d="M55 63 H65" stroke="#FFF8FF" strokeWidth="2" />
      <path d="M39 64 L45 63" stroke="#F5B5DA" strokeWidth="1.8" strokeLinecap="round" />
      <path d="M71 64 L77 63" stroke="#F5B5DA" strokeWidth="1.8" strokeLinecap="round" />

      {/* Glam Lips Smile */}
      <path
        d={mood === 'celebrating' ? 'M50 82 Q60 91 70 82' : 'M52 83 Q60 88 68 83'}
        stroke="#FFF8FF"
        strokeWidth="3.2"
        fill="none"
        strokeLinecap="round"
      />
      <circle cx="60" cy="48" r="4" fill="#FFF8FF" />
    </svg>
  );
}

function MadameDeadlineSvg({ mood }: { mood: MascotMood }) {
  const isPanicked = mood === 'panicked' || mood === 'shady';
  return (
    <svg viewBox="0 0 120 120" className="w-full h-full drop-shadow-[0_10px_14px_rgba(76,38,154,0.26)]">
      <defs>
        <radialGradient id="clock-outer" cx="35%" cy="30%" r="75%">
          <stop offset="0%" stopColor="#F9D2EB" />
          <stop offset="55%" stopColor="#A985F2" />
          <stop offset="100%" stopColor="#4C269A" />
        </radialGradient>
      </defs>
      {/* Alarm Bells */}
      <circle cx="30" cy="28" r="11" fill="#FFC3A6" stroke="#FFF8FF" strokeWidth="2" />
      <circle cx="90" cy="28" r="11" fill="#FFC3A6" stroke="#FFF8FF" strokeWidth="2" />
      <rect x="55" y="14" width="10" height="10" rx="4" fill="#ED82BE" stroke="#FFF8FF" strokeWidth="1.5" />

      {/* Clock Case */}
      <circle cx="60" cy="64" r="38" fill="url(#clock-outer)" stroke="#FFF8FF" strokeWidth="2.5" />
      <circle cx="60" cy="64" r="29" fill="#FFF8FF" />

      {/* Clock Ticks */}
      <circle cx="60" cy="40" r="2" fill="#9672E8" />
      <circle cx="84" cy="64" r="2" fill="#9672E8" />
      <circle cx="60" cy="88" r="2" fill="#9672E8" />
      <circle cx="36" cy="64" r="2" fill="#9672E8" />

      {/* Expressive Brows & Hands */}
      <path d="M44 50 L54 53" stroke="#4C269A" strokeWidth="2.2" strokeLinecap="round" />
      <path d="M76 50 L66 53" stroke="#4C269A" strokeWidth="2.2" strokeLinecap="round" />
      <circle cx="49" cy="58" r="3" fill="#38216B" />
      <circle cx="71" cy="58" r="3" fill="#38216B" />

      {/* Clock Hands */}
      <line
        x1="60"
        y1="66"
        x2={isPanicked ? '74' : '60'}
        y2={isPanicked ? '54' : '46'}
        stroke="#ED82BE"
        strokeWidth="3.2"
        strokeLinecap="round"
      />
      <line x1="60" y1="66" x2="77" y2="68" stroke="#4C269A" strokeWidth="2.6" strokeLinecap="round" />
      <circle cx="60" cy="66" r="3.5" fill="#4C269A" />

      {/* Dramatic Mouth */}
      {isPanicked ? (
        <ellipse cx="60" cy="79" rx="4.5" ry="5" fill="#B33981" />
      ) : (
        <path d="M54 78 Q60 82 66 78" stroke="#B33981" strokeWidth="2.3" fill="none" strokeLinecap="round" />
      )}
    </svg>
  );
}
