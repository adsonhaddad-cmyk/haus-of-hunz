import { AnimatePresence, motion } from 'motion/react';
import { Download, RefreshCw, Share, Smartphone, WifiOff, X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { SiliconeButton } from './ClayPrimitives';

export function OfflineBanner({ visible }: { visible: boolean }) {
  const { t } = useTranslation();
  if (!visible) return null;

  return (
    <div
      role="status"
      className="mx-3.5 sm:mx-6 lg:mx-8 mt-3 px-4 py-2.5 rounded-2xl bg-[#4C269A] text-[#FFF8FF] flex items-center gap-2.5 text-xs font-medium shadow-md"
    >
      <WifiOff className="w-4 h-4 text-[#FFC3A6] shrink-0" />
      <span>{t('pwa.offlineBanner')}</span>
    </div>
  );
}

export function UpdateAvailableBanner({
  visible,
  onRefresh,
}: {
  visible: boolean;
  onRefresh: () => void;
}) {
  const { t } = useTranslation();
  if (!visible) return null;

  return (
    <div className="mx-3.5 sm:mx-6 lg:mx-8 mt-3 px-4 py-2.5 rounded-2xl surface-clay flex items-center justify-between gap-3">
      <div className="flex items-center gap-2.5 text-xs font-semibold text-[#4C269A]">
        <RefreshCw className="w-4 h-4 text-[#9672E8]" />
        <span>{t('pwa.updateAvailable')}</span>
      </div>
      <SiliconeButton variant="lavender" onClick={onRefresh} className="min-h-[36px] py-1.5 px-3 text-xs">
        {t('pwa.updateBtn')}
      </SiliconeButton>
    </div>
  );
}

export function IOSInstallModal({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const { t } = useTranslation();

  return (
    <AnimatePresence>
      {open && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4"
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#38216B]/40 backdrop-blur-xs"
          />
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            className="relative z-10 w-full sm:max-w-md surface-clay rounded-t-[30px] sm:rounded-[30px] p-6"
          >
            <div className="w-10 h-1.5 bg-[#C5A6F5]/60 rounded-full mx-auto mb-4 sm:hidden" />
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <span className="w-10 h-10 rounded-2xl btn-3d-lavender inline-flex items-center justify-center shrink-0">
                  <Smartphone className="w-5 h-5" />
                </span>
                <h3 className="font-editorial text-xl font-bold text-[#38216B]">
                  {t('pwa.installTitle')}
                </h3>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label={t('common.close')}
                className="min-h-[40px] min-w-[40px] rounded-full btn-3d-cloud inline-flex items-center justify-center shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              <div className="surface-inset rounded-2xl p-3.5 text-sm text-[#38216B] flex items-start gap-3">
                <Share className="w-4 h-4 text-[#9672E8] shrink-0 mt-0.5" />
                <p>{t('pwa.iosStep1')}</p>
              </div>
              <div className="surface-inset rounded-2xl p-3.5 text-sm text-[#38216B] flex items-start gap-3">
                <Download className="w-4 h-4 text-[#ED82BE] shrink-0 mt-0.5" />
                <p>{t('pwa.iosStep2')}</p>
              </div>
              <div className="surface-inset rounded-2xl p-3.5 text-sm text-[#38216B]">
                <p>{t('pwa.iosStep3')}</p>
              </div>
            </div>

            <div className="mt-5">
              <SiliconeButton variant="lavender" onClick={onClose} className="w-full">
                {t('common.close')}
              </SiliconeButton>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
