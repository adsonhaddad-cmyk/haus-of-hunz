import { useState } from 'react';
import heroBallroomImg from '../../assets/images/house_hero_ballroom_1794694182411.jpg';

export function DreamyHomeHeroScene() {
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <div
      aria-hidden="true"
      className="relative w-full h-56 sm:h-64 lg:h-72 overflow-hidden select-none pointer-events-none"
    >
      {!imgFailed ? (
        <img
          src={heroBallroomImg}
          alt=""
          onError={() => setImgFailed(true)}
          className="w-full h-full object-cover object-center scale-[1.02]"
        />
      ) : (
        <div
          className="w-full h-full"
          style={{
            background:
              'linear-gradient(135deg, #9E82EB 0%, #CDA9F6 45%, #F6B8DC 78%, #FFC8AD 100%)',
          }}
        />
      )}

      {/* Atmospheric lavender twilight & cloud mist overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#4C269A]/70 via-[#7A54D1]/30 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-[#EADCF8]/95 via-[#EADCF8]/45 to-transparent" />
    </div>
  );
}
