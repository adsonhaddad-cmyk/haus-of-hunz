import { useState } from 'react';
import { AvatarConfig, Resident, SkinTone } from '../types/household';

interface AvatarProps {
  resident?: Resident;
  overrideConfig?: AvatarConfig;
  fallbackName?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showOnlineDot?: boolean;
  className?: string;
}

const SIZE_CLASSES: Record<NonNullable<AvatarProps['size']>, string> = {
  xs: 'w-7 h-7 text-[11px]',
  sm: 'w-9 h-9 text-xs',
  md: 'w-11 h-11 text-sm',
  lg: 'w-14 h-14 text-base',
  xl: 'w-24 h-24 text-xl',
};

const SKIN_HEX: Record<SkinTone, string> = {
  porcelain: '#FCE5D8',
  peach: '#F4C6AA',
  honey: '#DFA379',
  amber: '#BC7C51',
  chestnut: '#8A5236',
  espresso: '#5A3422',
};

const OUTFIT_HEX: Record<AvatarConfig['clothing'], [string, string]> = {
  lavender_sweater: ['#9672E8', '#6E45CC'],
  silk_blazer: ['#ED82BE', '#B33981'],
  sequin_top: ['#8EA8F5', '#4C269A'],
  hoodie: ['#C5A6F5', '#7965A5'],
  mesh_chic: ['#4C269A', '#38216B'],
};

export function CustomAvatarSvg({
  config,
  className = '',
}: {
  config: AvatarConfig;
  className?: string;
}) {
  const skin = SKIN_HEX[config.skinTone] || SKIN_HEX.honey;
  const [clothA, clothB] =
    OUTFIT_HEX[config.clothing] || OUTFIT_HEX.lavender_sweater;
  const hairColor = '#2F1B4E';

  return (
    <svg viewBox="0 0 100 100" className={className} aria-hidden="true">
      <defs>
        <linearGradient id={`bg-${config.accentColor}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#FFF8FF" />
          <stop offset="100%" stopColor={config.accentColor || '#C5A6F5'} />
        </linearGradient>
        <linearGradient id={`cloth-${config.clothing}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={clothA} />
          <stop offset="100%" stopColor={clothB} />
        </linearGradient>
      </defs>

      <circle cx="50" cy="50" r="50" fill={`url(#bg-${config.accentColor})`} />

      {/* Back Hair for longer styles */}
      {(config.hairStyle === 'sleek_bob' || config.hairStyle === 'waves') && (
        <path
          d="M24 52 C24 24, 76 24, 76 52 L78 78 C78 82, 22 82, 22 78 Z"
          fill={hairColor}
        />
      )}
      {config.hairStyle === 'updo' && (
        <circle cx="50" cy="18" r="13" fill={hairColor} />
      )}
      {config.hairStyle === 'curly_crown' && (
        <g fill={hairColor}>
          <circle cx="33" cy="27" r="10" />
          <circle cx="50" cy="21" r="12" />
          <circle cx="67" cy="27" r="10" />
          <circle cx="27" cy="39" r="8" />
          <circle cx="73" cy="39" r="8" />
        </g>
      )}

      {/* Shoulders / Outfit */}
      <path
        d="M16 100 C18 74, 34 68, 50 68 C66 68, 82 74, 84 100 Z"
        fill={`url(#cloth-${config.clothing})`}
      />
      {config.clothing === 'silk_blazer' && (
        <path d="M40 70 L50 92 L60 70 Z" fill="#FFF8FF" fillOpacity="0.9" />
      )}

      {/* Pearls Necklace Accessory */}
      {config.accessory === 'pearls' && (
        <g fill="#FFF8FF" stroke="#E8D8FA" strokeWidth="0.6">
          <circle cx="40" cy="72" r="2.6" />
          <circle cx="45" cy="75" r="2.8" />
          <circle cx="50" cy="76" r="3" />
          <circle cx="55" cy="75" r="2.8" />
          <circle cx="60" cy="72" r="2.6" />
        </g>
      )}

      {/* Neck & Head */}
      <rect x="43" y="57" width="14" height="14" rx="6" fill={skin} />
      <ellipse cx="50" cy="45" rx="20" ry="22" fill={skin} />

      {/* Ears & Hoops */}
      <circle cx="30" cy="46" r="4" fill={skin} />
      <circle cx="70" cy="46" r="4" fill={skin} />
      {config.accessory === 'hoops' && (
        <>
          <circle cx="29" cy="52" r="4.5" fill="none" stroke="#FFC3A6" strokeWidth="2" />
          <circle cx="71" cy="52" r="4.5" fill="none" stroke="#FFC3A6" strokeWidth="2" />
        </>
      )}

      {/* Front Hair */}
      {config.hairStyle === 'short_fade' && (
        <path
          d="M30 40 C30 20, 70 20, 70 40 C66 32, 34 32, 30 40 Z"
          fill={hairColor}
        />
      )}
      {config.hairStyle === 'buzz' && (
        <path
          d="M31 38 C32 22, 68 22, 69 38 C64 31, 36 31, 31 38 Z"
          fill={hairColor}
          fillOpacity="0.88"
        />
      )}
      {(config.hairStyle === 'sleek_bob' ||
        config.hairStyle === 'waves' ||
        config.hairStyle === 'updo') && (
        <path
          d="M30 39 C30 20, 70 20, 70 39 C62 29, 38 30, 30 39 Z"
          fill={hairColor}
        />
      )}

      {/* Crown or Headband */}
      {config.accessory === 'crown' && (
        <path
          d="M37 25 L41 13 L50 20 L59 13 L63 25 Z"
          fill="#FFC3A6"
          stroke="#FFF8FF"
          strokeWidth="1.4"
        />
      )}
      {config.accessory === 'headband' && (
        <path
          d="M31 33 Q50 24 69 33"
          stroke="#ED82BE"
          strokeWidth="4.2"
          fill="none"
          strokeLinecap="round"
        />
      )}

      {/* Eyes & Expressions */}
      {config.accessory === 'cat_eye_shades' ? (
        <g>
          <path d="M33 41 L47 43 C47 49, 41 51, 36 49 Z" fill="#38216B" stroke="#FFF8FF" strokeWidth="1.3" />
          <path d="M67 41 L53 43 C53 49, 59 51, 64 49 Z" fill="#38216B" stroke="#FFF8FF" strokeWidth="1.3" />
          <line x1="47" y1="43" x2="53" y2="43" stroke="#FFF8FF" strokeWidth="1.5" />
        </g>
      ) : (
        <g>
          <circle cx="42" cy="44" r="2.6" fill="#2A1747" />
          {config.expression === 'wink' ? (
            <path d="M55 44 Q58 41 61 44" stroke="#2A1747" strokeWidth="2.2" fill="none" strokeLinecap="round" />
          ) : (
            <circle cx="58" cy="44" r="2.6" fill="#2A1747" />
          )}
          <path
            d={
              config.expression === 'smirk'
                ? 'M37 38 L46 39 M54 37 Q58 34 63 38'
                : 'M37 38 Q42 36 46 38 M54 38 Q58 36 63 38'
            }
            stroke="#2A1747"
            strokeWidth="1.8"
            fill="none"
            strokeLinecap="round"
          />
        </g>
      )}

      {/* Facial Hair */}
      {config.facialHair === 'stubble' && (
        <path
          d="M35 51 C36 62, 64 62, 65 51 C60 57, 40 57, 35 51 Z"
          fill={hairColor}
          fillOpacity="0.22"
        />
      )}
      {config.facialHair === 'mustache' && (
        <path
          d="M42 52 Q46 49 50 52 Q54 49 58 52"
          stroke={hairColor}
          strokeWidth="2.8"
          fill="none"
          strokeLinecap="round"
        />
      )}
      {config.facialHair === 'beard' && (
        <path
          d="M33 49 C33 65, 67 65, 67 49 C63 58, 37 58, 33 49 Z"
          fill={hairColor}
          fillOpacity="0.88"
        />
      )}

      {/* Mouth */}
      {config.expression === 'gasp' ? (
        <ellipse cx="50" cy="56" rx="3.4" ry="4.2" fill="#B33981" />
      ) : config.expression === 'smirk' ? (
        <path d="M44 55 Q52 58 58 53" stroke="#8C2B62" strokeWidth="2.2" fill="none" strokeLinecap="round" />
      ) : config.expression === 'serene' ? (
        <path d="M45 55 Q50 57 55 55" stroke="#8C2B62" strokeWidth="2" fill="none" strokeLinecap="round" />
      ) : (
        <path d="M43 54 Q50 61 57 54" stroke="#8C2B62" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      )}
    </svg>
  );
}

export function Avatar({
  resident,
  overrideConfig,
  fallbackName = '?',
  size = 'md',
  showOnlineDot = false,
  className = '',
}: AvatarProps) {
  const [imgError, setImgError] = useState(false);
  const name = resident?.name ?? fallbackName;
  const config = overrideConfig ?? resident?.avatarConfig;
  const photoUrl = config?.customPhotoUrl || resident?.avatarUrl;
  const sizeClass = SIZE_CLASSES[size];

  return (
    <span className={`relative inline-flex shrink-0 ${className}`}>
      {photoUrl && !imgError ? (
        <img
          src={photoUrl}
          alt={name}
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          style={{
            boxShadow:
              '0 6px 14px -4px rgba(76, 38, 154, 0.28), 0 0 0 2px rgba(255, 248, 255, 0.92)',
          }}
          className={`${sizeClass} rounded-full object-cover bg-[#EADCF8]`}
        />
      ) : config ? (
        <span
          aria-label={name}
          style={{
            boxShadow:
              '0 6px 14px -4px rgba(76, 38, 154, 0.28), 0 0 0 2px rgba(255, 248, 255, 0.92)',
          }}
          className={`${sizeClass} rounded-full overflow-hidden inline-flex items-center justify-center bg-[#EADCF8]`}
        >
          <CustomAvatarSvg config={config} className="w-full h-full" />
        </span>
      ) : (
        <span
          aria-label={name}
          style={{
            background: `linear-gradient(145deg, ${resident?.color ?? '#9672E8'} 0%, #4C269A 100%)`,
          }}
          className={`${sizeClass} rounded-full inline-flex items-center justify-center font-semibold text-[#FFF8FF] border border-white/60`}
        >
          {name.slice(0, 2).toUpperCase()}
        </span>
      )}

      {showOnlineDot && (
        <span
          title="Online"
          className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-[#34D399] border-2 border-[#FFF8FF]"
        />
      )}
    </span>
  );
}
