import { useCallback, useEffect, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User as FirebaseUser,
} from 'firebase/auth';
import { useTranslation } from 'react-i18next';
import { auth, googleProvider } from '../firebase';
import { setAppLocale, SupportedLocale } from '../i18n';
import {
  addPinNoteFirestore,
  addShoppingItemFirestore,
  addTaskFirestore,
  bootstrapHouseOfChores,
  checkInviteCode,
  completeTaskFirestore,
  deletePinNoteFirestore,
  deleteShoppingItemFirestore,
  deleteTaskFirestore,
  getUserLink,
  joinHouseWithInviteCode,
  markAllNotificationsReadFirestore,
  pauseOrResumeTaskFirestore,
  proposeSwapFirestore,
  resetDemoDataFirestore,
  respondSwapFirestore,
  sendPokeFirestore,
  subscribeToHouseholdRealtime,
  updateHouseSettingsFirestore,
  updateMyProfileFirestore,
  updatePinNoteFirestore,
  updateShoppingItemFirestore,
  updateTaskFirestore,
  type HouseholdRealtimeMeta,
  type UserLinkDoc,
} from '../services/firestoreHouseholdService';
import {
  archiveLegacyFinancialDataIfPresent,
  getLegacyFinanceBackupJson,
  loadOfflineHouseholdCache,
  saveOfflineHouseholdCache,
} from '../services/householdRepository';
import {
  AuthUserSummary,
  AvatarConfig,
  BackendRuntimeStatus,
  HouseholdState,
  HousePreferences,
  HouseStyle,
  PenaltySettings,
  PokeRecord,
  ShadeIntensity,
  ShoppingCategory,
  ShoppingUnit,
  TaskCategory,
  TaskFrequency,
  TaskPriority,
  ToastMessage,
} from '../types/household';
import {
  subscribeBrowserPush,
  unsubscribeBrowserPush,
} from '../utils/pushClient';

export interface LegacyFinanceBackupInfo {
  archived: boolean;
  expenseCount: number;
  settlementCount: number;
}

export interface ActivePokeSpotlight {
  poke: PokeRecord;
  senderName: string;
}

export function useHouseStore() {
  const { t, i18n } = useTranslation();

  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [userLink, setUserLink] = useState<UserLinkDoc | null>(null);
  const [defaultInviteExists, setDefaultInviteExists] = useState<boolean | null>(null);

  const [state, setState] = useState<HouseholdState | null>(() =>
    loadOfflineHouseholdCache()
  );
  const [realtimeMeta, setRealtimeMeta] = useState<HouseholdRealtimeMeta>({
    householdOwnerUid: '',
    inviteCode: 'HOUSE-TENS',
    memberUids: [],
    members: [],
  });
  const [vapidPublicKey, setVapidPublicKey] = useState<string>('');
  const [onlineResidentIds, setOnlineResidentIds] = useState<string[]>([]);
  const [runtimeStatus, setRuntimeStatus] = useState<BackendRuntimeStatus>({
    mode: 'firebase-firestore',
    persistenceLabel: 'Firebase Cloud Firestore + Google Auth',
    persistentCloudConfigured: true,
    vapidConfigured: true,
    wsConnected: false,
    online: typeof navigator !== 'undefined' ? navigator.onLine : true,
    activeConnections: 0,
  });
  const [isInitializing, setIsInitializing] = useState(true);
  const [isMutating, setIsMutating] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [pokeSpotlight, setPokeSpotlight] =
    useState<ActivePokeSpotlight | null>(null);
  const [legacyBackup] = useState<LegacyFinanceBackupInfo>(() =>
    archiveLegacyFinancialDataIfPresent()
  );

  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimerRef = useRef<number | null>(null);
  const seenPokeIdsRef = useRef<Set<string> | null>(null);

  const pushToast = useCallback((toast: Omit<ToastMessage, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev, { ...toast, id }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 4500);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const dismissPokeSpotlight = useCallback(() => {
    setPokeSpotlight(null);
  }, []);

  const authedApiFetch = useCallback(
    async <T,>(url: string, options: RequestInit = {}): Promise<T> => {
      const current = auth.currentUser;
      if (!current) {
        throw new Error('Authentication required');
      }
      const idToken = await current.getIdToken();
      const headers = new Headers(options.headers || {});
      if (!headers.has('Content-Type') && options.body) {
        headers.set('Content-Type', 'application/json');
      }
      headers.set('Authorization', `Bearer ${idToken}`);
      if (userLink?.householdId) {
        headers.set('x-household-id', userLink.householdId);
      }
      if (userLink?.residentId) {
        headers.set('x-resident-id', userLink.residentId);
      }

      const res = await fetch(url, { ...options, headers });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(
          typeof data?.error === 'string'
            ? data.error
            : `Request failed (${res.status})`
        );
      }
      return data as T;
    },
    [userLink]
  );

  // 1. Firebase Auth State Listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setAuthError(null);
      setFirebaseUser(fbUser);

      if (!fbUser) {
        setUserLink(null);
        setDefaultInviteExists(null);
        setOnlineResidentIds([]);
        seenPokeIdsRef.current = null;
        setRuntimeStatus((prev) => ({ ...prev, wsConnected: false }));
        setIsInitializing(false);
        return;
      }

      setIsInitializing(true);
      try {
        const link = await getUserLink(fbUser.uid);
        if (link) {
          setUserLink(link);
        } else {
          setUserLink(null);
          const invite = await checkInviteCode('HOUSE-TENS');
          setDefaultInviteExists(Boolean(invite));
        }
      } catch (err) {
        setAuthError(
          err instanceof Error ? err.message : t('auth.invalidCredentials')
        );
      } finally {
        setIsInitializing(false);
      }
    });

    return () => unsub();
  }, [t]);

  // 2. Network Online / Offline Listener
  useEffect(() => {
    const handleOnline = () =>
      setRuntimeStatus((prev) => ({ ...prev, online: true }));
    const handleOffline = () =>
      setRuntimeStatus((prev) => ({ ...prev, online: false }));
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // 3. Realtime Cloud Firestore onSnapshot Subscription
  useEffect(() => {
    if (!firebaseUser || !userLink) return;

    seenPokeIdsRef.current = null;

    const unsub = subscribeToHouseholdRealtime({
      householdId: userLink.householdId,
      uid: firebaseUser.uid,
      userEmail: firebaseUser.email || '',
      onUpdate: (nextState, meta) => {
        setState(nextState);
        saveOfflineHouseholdCache(nextState);
        setRealtimeMeta(meta);
        setRuntimeStatus((prev) => ({
          ...prev,
          wsConnected: true,
          persistentCloudConfigured: true,
          activeConnections: meta.memberUids.length,
        }));

        // Detect newly arrived Poke & Shade targeted at the signed-in partner
        const currentPokeIds = new Set(nextState.pokes.map((p) => p.id));
        if (seenPokeIdsRef.current === null) {
          seenPokeIdsRef.current = currentPokeIds;
        } else {
          const newPokes = nextState.pokes.filter(
            (p) => !seenPokeIdsRef.current!.has(p.id)
          );
          seenPokeIdsRef.current = currentPokeIds;

          const incomingForMe = newPokes.find(
            (p) => p.toResidentId === userLink.residentId
          );
          if (incomingForMe) {
            const senderName =
              nextState.residents.find(
                (r) => r.id === incomingForMe.fromResidentId
              )?.name || t('common.partnerFallback');
            setPokeSpotlight({ poke: incomingForMe, senderName });
            pushToast({
              title: t('toasts.pokeReceivedTitle'),
              subtitle: incomingForMe.message,
              tone: 'pink',
            });
          }
        }
      },
    });

    return () => {
      unsub();
    };
  }, [firebaseUser, pushToast, t, userLink]);

  // 4. Optional WebSocket Presence Channel (authenticated with Firebase ID token)
  useEffect(() => {
    if (!firebaseUser || !userLink) {
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
      return;
    }

    let disposed = false;

    const connectPresence = async () => {
      if (disposed) return;
      try {
        const idToken = await firebaseUser.getIdToken();
        if (disposed) return;
        const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const url = `${proto}//${window.location.host}/ws?token=${encodeURIComponent(
          idToken
        )}&householdId=${encodeURIComponent(
          userLink.householdId
        )}&residentId=${encodeURIComponent(userLink.residentId)}`;

        const ws = new WebSocket(url);
        wsRef.current = ws;

        ws.onmessage = (event) => {
          try {
            const parsed = JSON.parse(event.data) as {
              type: string;
              payload?: { onlineResidentIds?: string[] };
            };
            if (
              parsed.type === 'presence:updated' &&
              Array.isArray(parsed.payload?.onlineResidentIds)
            ) {
              setOnlineResidentIds(parsed.payload.onlineResidentIds);
            }
          } catch {
            // Ignore malformed packets
          }
        };

        ws.onclose = () => {
          if (disposed) return;
          reconnectTimerRef.current = window.setTimeout(
            () => void connectPresence(),
            5000
          );
        };

        ws.onerror = () => {
          ws.close();
        };
      } catch {
        // Presence WS is optional; Firestore realtime remains active
      }
    };

    void connectPresence();

    return () => {
      disposed = true;
      if (reconnectTimerRef.current) {
        window.clearTimeout(reconnectTimerRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
        wsRef.current = null;
      }
    };
  }, [firebaseUser, userLink]);

  // Auth & Onboarding Actions
  const signInWithGoogle = useCallback(async () => {
    setAuthError(null);
    setIsMutating(true);
    try {
      await signInWithPopup(auth, googleProvider);
      return true;
    } catch (err) {
      const code =
        typeof err === 'object' && err !== null && 'code' in err
          ? String((err as { code?: string }).code)
          : '';
      if (code === 'auth/popup-blocked') {
        setAuthError(t('auth.googlePopupBlocked'));
      } else {
        setAuthError(
          err instanceof Error ? err.message : t('auth.invalidCredentials')
        );
      }
      return false;
    } finally {
      setIsMutating(false);
    }
  }, [t]);

  const launchHouse = useCallback(
    async (chosenResidentId: 'res-adson' | 'res-arty', displayName?: string) => {
      if (!firebaseUser) return false;
      setAuthError(null);
      setIsMutating(true);
      try {
        const link = await bootstrapHouseOfChores({
          user: firebaseUser,
          chosenResidentId,
          displayName,
        });
        setUserLink(link);
        return true;
      } catch (err) {
        setAuthError(
          err instanceof Error ? err.message : t('auth.registerError')
        );
        return false;
      } finally {
        setIsMutating(false);
      }
    },
    [firebaseUser, t]
  );

  const joinHouseWithInvite = useCallback(
    async (payload: {
      inviteCode: string;
      preferredSlot: 'res-arty' | 'res-adson' | 'custom';
      displayName?: string;
    }) => {
      if (!firebaseUser) return false;
      setAuthError(null);
      setIsMutating(true);
      try {
        const link = await joinHouseWithInviteCode({
          user: firebaseUser,
          inviteCode: payload.inviteCode,
          preferredSlot: payload.preferredSlot,
          displayName: payload.displayName,
        });
        setUserLink(link);
        return true;
      } catch (err) {
        setAuthError(
          err instanceof Error ? err.message : t('auth.registerError')
        );
        return false;
      } finally {
        setIsMutating(false);
      }
    },
    [firebaseUser, t]
  );

  const logout = useCallback(async () => {
    await signOut(auth);
    setUserLink(null);
    setPokeSpotlight(null);
  }, []);

  // Language switch (zero reload)
  const changeLanguage = useCallback(
    (locale: SupportedLocale) => {
      setAppLocale(locale);
      pushToast({
        title: t('toasts.languageChanged', {
          lang:
            locale === 'pt-BR'
              ? t('house.languages.ptBR')
              : t('house.languages.enUS'),
        }),
        tone: 'lavender',
      });
    },
    [pushToast, t]
  );

  const activeResident =
    state?.residents.find((r) => r.id === userLink?.residentId) ??
    state?.residents[0] ??
    null;

  const authUser: AuthUserSummary | null =
    firebaseUser && userLink && activeResident
      ? {
          userId: firebaseUser.uid,
          residentId: activeResident.id,
          householdId: userLink.householdId,
          name: activeResident.name,
          email: firebaseUser.email || '',
          handle: activeResident.handle,
        }
      : null;

  const effectiveMemberUids =
    realtimeMeta.memberUids.length > 0
      ? realtimeMeta.memberUids
      : firebaseUser
        ? [firebaseUser.uid]
        : [];

  // Guarded Mutation Wrapper
  const runMutation = useCallback(
    async <T,>(fn: () => Promise<T>): Promise<T> => {
      setIsMutating(true);
      try {
        return await fn();
      } catch (err) {
        pushToast({
          title: err instanceof Error ? err.message : t('common.retry'),
          tone: 'neutral',
        });
        throw err;
      } finally {
        setIsMutating(false);
      }
    },
    [pushToast, t]
  );

  const addTask = useCallback(
    async (payload: {
      title: string;
      description?: string;
      category: TaskCategory;
      points: number;
      priority: TaskPriority;
      frequency: TaskFrequency;
      customIntervalDays?: number;
      assignedToId: string;
      participantIds: string[];
      dueDate: string;
      dueTime: string;
    }) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        addTaskFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          payload
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const updateTask = useCallback(
    async (
      taskId: string,
      updates: {
        title?: string;
        description?: string;
        category?: TaskCategory;
        points?: number;
        priority?: TaskPriority;
        frequency?: TaskFrequency;
        customIntervalDays?: number;
        assignedToId?: string;
        participantIds?: string[];
        dueDate?: string;
        dueTime?: string;
      }
    ) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        updateTaskFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          taskId,
          updates
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const pauseTask = useCallback(
    async (taskId: string, pausedReason?: string, pausedUntil?: string) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        pauseOrResumeTaskFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          taskId,
          'pause',
          pausedReason,
          pausedUntil
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const resumeTask = useCallback(
    async (taskId: string) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        pauseOrResumeTaskFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          taskId,
          'resume'
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const reassignTask = useCallback(
    async (taskId: string, assignedToId: string) => {
      await updateTask(taskId, { assignedToId });
    },
    [updateTask]
  );

  const completeTask = useCallback(
    async (taskId: string) => {
      if (!state || !activeResident || !firebaseUser) return;
      const completion = await runMutation(() =>
        completeTaskFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          taskId
        )
      );

      const nextName =
        state.residents.find((r) => r.id === completion.nextResidentId)
          ?.name || t('common.partnerFallback');

      const subtitle =
        completion.updatedTask.frequency === 'once'
          ? t('toasts.choreCompletedOnceSub', {
              title: completion.updatedTask.title,
            })
          : t('toasts.choreCompletedSub', {
              title: completion.updatedTask.title,
              next: nextName,
            });

      pushToast({
        title:
          completion.penaltyPercent > 0
            ? t('toasts.choreCompletedLateTitle', {
                percent: completion.penaltyPercent,
              })
            : t('toasts.choreCompletedTitle'),
        subtitle,
        pointsBadge: `+${completion.pointsAwarded} ${t('common.pts')}`,
        tone: completion.penaltyPercent > 0 ? 'neutral' : 'lavender',
      });
    },
    [activeResident, effectiveMemberUids, firebaseUser, pushToast, runMutation, state, t]
  );

  const deleteTask = useCallback(
    async (taskId: string) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        deleteTaskFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          taskId
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const sendPoke = useCallback(
    async (taskId: string) => {
      if (!state || !activeResident || !firebaseUser) return;
      const res = await runMutation(() =>
        sendPokeFirestore({
          state,
          memberUids: effectiveMemberUids,
          actorResident: activeResident,
          actorUid: firebaseUser.uid,
          taskId,
          locale: i18n.language,
          dispatchPush: async (recipientId, title, body, tag) => {
            try {
              const pushRes = await authedApiFetch<{ delivered: boolean }>(
                '/api/push/poke',
                {
                  method: 'POST',
                  body: JSON.stringify({
                    householdId: state.householdId,
                    recipientId,
                    title,
                    body,
                    tag,
                  }),
                }
              );
              return Boolean(pushRes.delivered);
            } catch {
              return false;
            }
          },
        })
      );

      const recipientName =
        state.residents.find((r) => r.id === res.poke.toResidentId)?.name ||
        t('common.partnerFallback');

      pushToast({
        title: t('toasts.pokeSentTitle'),
        subtitle: t('toasts.pokeSentSub', {
          recipient: recipientName,
          title: res.poke.taskTitle,
        }),
        tone: 'pink',
      });
    },
    [
      activeResident,
      authedApiFetch,
      effectiveMemberUids,
      firebaseUser,
      i18n.language,
      pushToast,
      runMutation,
      state,
      t,
    ]
  );

  const proposeSwap = useCallback(
    async (taskId: string, note?: string) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        proposeSwapFirestore(
          state,
          effectiveMemberUids,
          activeResident,
          firebaseUser.uid,
          taskId,
          note
        )
      );
      pushToast({ title: t('toasts.swapSent'), tone: 'lavender' });
    },
    [activeResident, effectiveMemberUids, firebaseUser, pushToast, runMutation, state, t]
  );

  const respondSwap = useCallback(
    async (swapId: string, decision: 'accept' | 'decline' | 'cancel') => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        respondSwapFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          swapId,
          decision
        )
      );
      if (decision === 'accept') {
        pushToast({ title: t('toasts.swapAccepted'), tone: 'lavender' });
      } else if (decision === 'decline') {
        pushToast({ title: t('toasts.swapDeclined'), tone: 'neutral' });
      }
    },
    [activeResident, effectiveMemberUids, firebaseUser, pushToast, runMutation, state, t]
  );

  // Shopping Actions (Zero Financial Conversion)
  const addShoppingItem = useCallback(
    async (payload: {
      name: string;
      quantity: number;
      unit: ShoppingUnit;
      category: ShoppingCategory;
    }) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        addShoppingItemFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          payload
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const updateShoppingItem = useCallback(
    async (
      itemId: string,
      updates: {
        name?: string;
        quantity?: number;
        unit?: ShoppingUnit;
        category?: ShoppingCategory;
      }
    ) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        updateShoppingItemFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          itemId,
          updates
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const markShoppingBought = useCallback(
    async (itemId: string) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        updateShoppingItemFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          itemId,
          { action: 'mark_bought' }
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const restoreShoppingItem = useCallback(
    async (itemId: string) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        updateShoppingItemFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          itemId,
          { action: 'restore' }
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const deleteShoppingItem = useCallback(
    async (itemId: string) => {
      if (!state) return;
      await runMutation(() => deleteShoppingItemFirestore(state, itemId));
    },
    [runMutation, state]
  );

  // Pinboard Notes
  const addPinNote = useCallback(
    async (content: string, pinned = false) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        addPinNoteFirestore(
          state,
          effectiveMemberUids,
          activeResident.id,
          firebaseUser.uid,
          content,
          pinned
        )
      );
    },
    [activeResident, effectiveMemberUids, firebaseUser, runMutation, state]
  );

  const updatePinNote = useCallback(
    async (noteId: string, content: string) => {
      if (!state) return;
      await runMutation(() => updatePinNoteFirestore(state, noteId, { content }));
    },
    [runMutation, state]
  );

  const togglePinNote = useCallback(
    async (noteId: string) => {
      if (!state) return;
      await runMutation(() =>
        updatePinNoteFirestore(state, noteId, { togglePin: true })
      );
    },
    [runMutation, state]
  );

  const deletePinNote = useCallback(
    async (noteId: string) => {
      if (!state) return;
      await runMutation(() => deletePinNoteFirestore(state, noteId));
    },
    [runMutation, state]
  );

  const markAllNotificationsRead = useCallback(async () => {
    if (!state || !activeResident) return;
    await runMutation(() =>
      markAllNotificationsReadFirestore(state, activeResident.id)
    );
  }, [activeResident, runMutation, state]);

  const updateMyProfile = useCallback(
    async (payload: {
      name?: string;
      color?: string;
      shadeIntensity?: ShadeIntensity;
      muteShadeNotifications?: boolean;
      avatarConfig?: Partial<AvatarConfig>;
    }) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        updateMyProfileFirestore(state, activeResident, firebaseUser.uid, payload)
      );
      pushToast({ title: t('toasts.profileSaved'), tone: 'lavender' });
    },
    [activeResident, firebaseUser, pushToast, runMutation, state, t]
  );

  const updateHouseSettings = useCallback(
    async (payload: {
      houseName?: string;
      tagline?: string;
      houseStyle?: HouseStyle;
      timeZone?: string;
      preferences?: Partial<HousePreferences>;
      penaltySettings?: Partial<PenaltySettings>;
    }) => {
      if (!state || !activeResident || !firebaseUser) return;
      await runMutation(() =>
        updateHouseSettingsFirestore(
          state,
          effectiveMemberUids,
          activeResident,
          firebaseUser.uid,
          payload
        )
      );
      pushToast({ title: t('toasts.settingsSaved'), tone: 'lavender' });
    },
    [activeResident, effectiveMemberUids, firebaseUser, pushToast, runMutation, state, t]
  );

  // Web Push Actions (VAPID via Express + pushEnabled flag synced in Firestore)
  const subscribePush = useCallback(async () => {
    if (!state || !activeResident || !firebaseUser) return;
    let pubKey = vapidPublicKey;
    if (!pubKey) {
      const keyRes = await authedApiFetch<{ publicKey: string }>(
        '/api/push/vapid-public-key'
      );
      pubKey = keyRes.publicKey;
      setVapidPublicKey(pubKey);
    }
    const subscription = await subscribeBrowserPush(pubKey);
    await authedApiFetch('/api/push/subscribe', {
      method: 'POST',
      body: JSON.stringify({
        householdId: state.householdId,
        residentId: activeResident.id,
        subscription: subscription as unknown as Record<string, unknown>,
      }),
    });
    await updateMyProfileFirestore(state, activeResident, firebaseUser.uid, {
      pushEnabled: true,
    });
    pushToast({ title: t('toasts.pushEnabled'), tone: 'lavender' });
  }, [activeResident, authedApiFetch, firebaseUser, pushToast, state, t, vapidPublicKey]);

  const unsubscribePush = useCallback(async () => {
    if (!state || !activeResident || !firebaseUser) return;
    await unsubscribeBrowserPush();
    await authedApiFetch('/api/push/subscribe', {
      method: 'DELETE',
      body: JSON.stringify({
        householdId: state.householdId,
        residentId: activeResident.id,
      }),
    });
    await updateMyProfileFirestore(state, activeResident, firebaseUser.uid, {
      pushEnabled: false,
    });
    pushToast({ title: t('toasts.pushDisabled'), tone: 'neutral' });
  }, [activeResident, authedApiFetch, firebaseUser, pushToast, state, t]);

  const sendTestPush = useCallback(async () => {
    if (!state || !activeResident) return false;
    try {
      const res = await authedApiFetch<{ delivered: boolean; sent: number }>(
        '/api/push/test',
        {
          method: 'POST',
          body: JSON.stringify({
            householdId: state.householdId,
            residentId: activeResident.id,
          }),
        }
      );
      if (res.delivered) {
        pushToast({ title: t('toasts.pushTestSent'), tone: 'lavender' });
      }
      return true;
    } catch (err) {
      pushToast({
        title: t('toasts.pushTestFailed', {
          reason: err instanceof Error ? err.message : 'Unavailable',
        }),
        tone: 'neutral',
      });
      return false;
    }
  }, [activeResident, authedApiFetch, pushToast, state, t]);

  const resetDemoData = useCallback(async () => {
    if (!state || !activeResident || !firebaseUser) return;
    await runMutation(() =>
      resetDemoDataFirestore(
        state,
        effectiveMemberUids,
        activeResident,
        firebaseUser.uid,
        realtimeMeta.householdOwnerUid
      )
    );
    pushToast({ title: t('toasts.demoReset'), tone: 'neutral' });
  }, [
    activeResident,
    effectiveMemberUids,
    firebaseUser,
    pushToast,
    realtimeMeta.householdOwnerUid,
    runMutation,
    state,
    t,
  ]);

  const isHouseOwner =
    Boolean(firebaseUser?.uid) &&
    firebaseUser?.uid === realtimeMeta.householdOwnerUid;

  const needsOnboarding = Boolean(firebaseUser && !userLink);

  return {
    state,
    firebaseUser,
    authUser,
    activeResident,
    inviteCode: realtimeMeta.inviteCode,
    isHouseOwner,
    needsOnboarding,
    defaultInviteExists,
    onlineResidentIds,
    runtimeStatus,
    isInitializing,
    isMutating,
    authError,
    toasts,
    pokeSpotlight,
    legacyBackup,
    getLegacyFinanceBackupJson,
    dismissToast,
    dismissPokeSpotlight,
    signInWithGoogle,
    launchHouse,
    joinHouseWithInvite,
    logout,
    changeLanguage,
    addTask,
    updateTask,
    pauseTask,
    resumeTask,
    reassignTask,
    completeTask,
    deleteTask,
    sendPoke,
    proposeSwap,
    respondSwap,
    addShoppingItem,
    updateShoppingItem,
    markShoppingBought,
    restoreShoppingItem,
    deleteShoppingItem,
    addPinNote,
    updatePinNote,
    togglePinNote,
    deletePinNote,
    markAllNotificationsRead,
    updateMyProfile,
    updateHouseSettings,
    subscribePush,
    unsubscribePush,
    sendTestPush,
    resetDemoData,
  };
}
