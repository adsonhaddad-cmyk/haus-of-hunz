import type {
  AchievementBadge,
  HouseholdState,
  HouseholdTask,
  PenaltySettings,
  PointTransaction,
  PokeRecord,
  Resident,
  ShadeIntensity,
  TaskFrequency,
  WeeklyCeremonySummary,
  WeeklyStandingsEntry,
} from '../types/household.ts';
import {
  addDaysYMD,
  addMonthsYMD,
  computeDueAtIso,
  getISOWeekKey,
} from './dates.ts';

export const DEFAULT_PENALTY_SETTINGS: PenaltySettings = {
  enabled: true,
  gracePeriodMinutes: 60, // Up to 1 hour late = 0% penalty
  tiers: [
    { maxDelayMinutes: 360, deductionPercent: 10 }, // >1h to 6h
    { maxDelayMinutes: 1440, deductionPercent: 25 }, // >6h to 24h
    { maxDelayMinutes: 2880, deductionPercent: 50 }, // >24h to 48h
    { maxDelayMinutes: 9999999, deductionPercent: 75 }, // >48h
  ],
  reminderFrequencyHours: 12,
  maxPokesPerOccurrence: 2,
};

export function calculateNextDueDate(
  currentDueDate: string,
  frequency: TaskFrequency,
  customIntervalDays = 3
): string {
  switch (frequency) {
    case 'daily':
      return addDaysYMD(currentDueDate, 1);
    case 'weekly':
      return addDaysYMD(currentDueDate, 7);
    case 'biweekly':
      return addDaysYMD(currentDueDate, 14);
    case 'monthly':
      return addMonthsYMD(currentDueDate, 1);
    case 'custom':
      return addDaysYMD(currentDueDate, Math.max(1, customIntervalDays));
    case 'once':
    default:
      return currentDueDate;
  }
}

export function getNextRotationResidentId(
  participantIds: string[],
  currentAssignedId: string,
  residents: Resident[]
): string {
  const activeSet = new Set(residents.map((r) => r.id));
  const validPool = participantIds.filter((id) => activeSet.has(id));
  const pool = validPool.length > 0 ? validPool : residents.map((r) => r.id);

  if (pool.length === 0) return currentAssignedId;
  const idx = pool.indexOf(currentAssignedId);
  if (idx === -1) return pool[0];
  return pool[(idx + 1) % pool.length];
}

export interface OverdueEvaluation {
  isOverdue: boolean;
  isWithinGrace: boolean;
  delayMinutes: number;
  penaltyPercent: number;
  penaltyPoints: number;
  netPoints: number;
}

export function evaluateTaskOverdue(
  task: HouseholdTask,
  nowMs: number,
  penaltySettings: PenaltySettings = DEFAULT_PENALTY_SETTINGS
): OverdueEvaluation {
  if (task.status !== 'pending') {
    return {
      isOverdue: false,
      isWithinGrace: false,
      delayMinutes: 0,
      penaltyPercent: 0,
      penaltyPoints: 0,
      netPoints: task.points,
    };
  }

  const dueMs = new Date(task.dueAt).getTime();
  if (!Number.isFinite(dueMs) || nowMs <= dueMs) {
    return {
      isOverdue: false,
      isWithinGrace: false,
      delayMinutes: 0,
      penaltyPercent: 0,
      penaltyPoints: 0,
      netPoints: task.points,
    };
  }

  const delayMinutes = Math.max(1, Math.floor((nowMs - dueMs) / 60000));
  const grace = Math.max(0, penaltySettings.gracePeriodMinutes);

  if (!penaltySettings.enabled || delayMinutes <= grace) {
    return {
      isOverdue: true,
      isWithinGrace: true,
      delayMinutes,
      penaltyPercent: 0,
      penaltyPoints: 0,
      netPoints: task.points,
    };
  }

  // If task was reassigned before its deadline, avoid unfairly penalizing the new assignee
  if (task.reassignedBeforeDeadline) {
    return {
      isOverdue: true,
      isWithinGrace: true,
      delayMinutes,
      penaltyPercent: 0,
      penaltyPoints: 0,
      netPoints: task.points,
    };
  }

  const sortedTiers = [...penaltySettings.tiers].sort(
    (a, b) => a.maxDelayMinutes - b.maxDelayMinutes
  );

  let deductionPercent = 0;
  for (const tier of sortedTiers) {
    if (delayMinutes <= tier.maxDelayMinutes) {
      deductionPercent = tier.deductionPercent;
      break;
    }
  }
  if (deductionPercent === 0 && sortedTiers.length > 0) {
    deductionPercent = sortedTiers[sortedTiers.length - 1].deductionPercent;
  }

  const penaltyPoints = Math.round((task.points * deductionPercent) / 100);
  const netPoints = Math.max(0, task.points - penaltyPoints);

  return {
    isOverdue: true,
    isWithinGrace: false,
    delayMinutes,
    penaltyPercent: deductionPercent,
    penaltyPoints,
    netPoints,
  };
}

export interface TaskCompletionResult {
  completed: boolean;
  reason?: 'already_completed' | 'duplicate_occurrence' | 'paused';
  updatedTask: HouseholdTask;
  updatedResidents: Resident[];
  transaction?: PointTransaction;
  executorId: string;
  nextResidentId: string;
  basePoints: number;
  penaltyPercent: number;
  penaltyPoints: number;
  pointsAwarded: number;
  wasOverdue: boolean;
  delayMinutes: number;
}

export function applyTaskCompletion(
  task: HouseholdTask,
  residents: Resident[],
  existingLedger: PointTransaction[],
  executorId: string,
  nowIso: string,
  timeZone: string = 'America/Sao_Paulo',
  penaltySettings: PenaltySettings = DEFAULT_PENALTY_SETTINGS
): TaskCompletionResult {
  if (task.status === 'completed') {
    return {
      completed: false,
      reason: 'already_completed',
      updatedTask: task,
      updatedResidents: residents,
      executorId,
      nextResidentId: task.assignedToId,
      basePoints: task.points,
      penaltyPercent: 0,
      penaltyPoints: 0,
      pointsAwarded: 0,
      wasOverdue: false,
      delayMinutes: 0,
    };
  }

  if (task.status === 'paused') {
    return {
      completed: false,
      reason: 'paused',
      updatedTask: task,
      updatedResidents: residents,
      executorId,
      nextResidentId: task.assignedToId,
      basePoints: task.points,
      penaltyPercent: 0,
      penaltyPoints: 0,
      pointsAwarded: 0,
      wasOverdue: false,
      delayMinutes: 0,
    };
  }

  const occurrenceId =
    task.occurrenceId || `${task.id}::${task.dueDate}::${task.occurrenceSeq ?? 0}`;

  // Idempotent guard: check both lastCompletedOccurrenceKey and immutable pointLedger
  const alreadyInLedger = existingLedger.some(
    (tx) => tx.occurrenceId === occurrenceId && tx.type === 'completion'
  );
  if (
    alreadyInLedger ||
    task.lastCompletedOccurrenceKey === occurrenceId
  ) {
    return {
      completed: false,
      reason: 'duplicate_occurrence',
      updatedTask: task,
      updatedResidents: residents,
      executorId,
      nextResidentId: task.assignedToId,
      basePoints: task.points,
      penaltyPercent: 0,
      penaltyPoints: 0,
      pointsAwarded: 0,
      wasOverdue: false,
      delayMinutes: 0,
    };
  }

  const targetResidentId =
    residents.find((r) => r.id === executorId)?.id ??
    residents.find((r) => r.id === task.assignedToId)?.id ??
    residents[0]?.id ??
    executorId;

  const nowMs = new Date(nowIso).getTime();
  const overdueEval = evaluateTaskOverdue(task, nowMs, penaltySettings);

  const pointsAwarded = overdueEval.netPoints;
  const penaltyPoints = overdueEval.penaltyPoints;
  const penaltyPercent = overdueEval.penaltyPercent;

  const completionRecord = {
    id: `hist-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    occurrenceId,
    completedById: targetResidentId,
    completedAt: nowIso,
    basePoints: task.points,
    penaltyPercent,
    penaltyPoints,
    pointsAwarded,
    wasOverdue: overdueEval.isOverdue,
    delayMinutes: overdueEval.delayMinutes,
    occurrenceDate: task.dueDate,
  };

  const transaction: PointTransaction = {
    id: `tx-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    residentId: targetResidentId,
    taskId: task.id,
    taskTitle: task.title,
    occurrenceId,
    type: 'completion',
    basePoints: task.points,
    penaltyPercent,
    pointsDelta: pointsAwarded,
    penaltyDeducted: penaltyPoints,
    wasOverdue: overdueEval.isOverdue,
    delayMinutes: overdueEval.delayMinutes,
    weekKey: getISOWeekKey(nowIso),
    createdAt: nowIso,
  };

  const isOneTime = task.frequency === 'once';
  const nextSeq = (task.occurrenceSeq ?? 0) + 1;
  const nextResidentId = isOneTime
    ? task.assignedToId
    : getNextRotationResidentId(
        task.participantIds,
        task.assignedToId,
        residents
      );
  const nextDueDate = isOneTime
    ? task.dueDate
    : calculateNextDueDate(
        task.dueDate,
        task.frequency,
        task.customIntervalDays
      );
  const nextDueTime = task.dueTime || '20:00';
  const nextDueAt = isOneTime
    ? task.dueAt
    : computeDueAtIso(nextDueDate, nextDueTime, timeZone);

  const updatedTask: HouseholdTask = {
    ...task,
    status: isOneTime ? 'completed' : 'pending',
    assignedToId: nextResidentId,
    dueDate: nextDueDate,
    dueTime: nextDueTime,
    dueAt: nextDueAt,
    occurrenceSeq: nextSeq,
    occurrenceId: isOneTime
      ? occurrenceId
      : `${task.id}::${nextDueDate}::${nextSeq}`,
    reassignedBeforeDeadline: false,
    lastCompletedOccurrenceKey: occurrenceId,
    history: [completionRecord, ...task.history],
  };

  const nextLedger = [transaction, ...existingLedger];
  const updatedResidents = residents.map((r) => {
    const ledgerTotal = nextLedger
      .filter((tx) => tx.residentId === r.id)
      .reduce((sum, tx) => sum + tx.pointsDelta, 0);
    if (r.id === targetResidentId) {
      const nextStreak = overdueEval.isOverdue && penaltyPoints > 0 ? 1 : r.streak + 1;
      return { ...r, points: ledgerTotal, streak: nextStreak };
    }
    return { ...r, points: ledgerTotal };
  });

  return {
    completed: true,
    updatedTask,
    updatedResidents,
    transaction,
    executorId: targetResidentId,
    nextResidentId,
    basePoints: task.points,
    penaltyPercent,
    penaltyPoints,
    pointsAwarded,
    wasOverdue: overdueEval.isOverdue,
    delayMinutes: overdueEval.delayMinutes,
  };
}

export interface PokeEligibility {
  allowed: boolean;
  reason?:
    | 'not_overdue'
    | 'cannot_poke_self'
    | 'recipient_not_assigned'
    | 'cooldown_active'
    | 'max_pokes_reached'
    | 'recipient_muted';
  pokesUsed: number;
  maxPokes: number;
  cooldownRemainingMs: number;
}

export function checkPokeEligibility(
  task: HouseholdTask,
  senderId: string,
  recipient: Resident,
  pokes: PokeRecord[],
  nowMs: number,
  penaltySettings: PenaltySettings = DEFAULT_PENALTY_SETTINGS
): PokeEligibility {
  const maxPokes = penaltySettings.maxPokesPerOccurrence || 2;
  const cooldownMs =
    (penaltySettings.reminderFrequencyHours || 12) * 3600 * 1000;

  if (task.assignedToId !== recipient.id) {
    return {
      allowed: false,
      reason: 'recipient_not_assigned',
      pokesUsed: 0,
      maxPokes,
      cooldownRemainingMs: 0,
    };
  }

  if (senderId === recipient.id) {
    return {
      allowed: false,
      reason: 'cannot_poke_self',
      pokesUsed: 0,
      maxPokes,
      cooldownRemainingMs: 0,
    };
  }

  if (task.status !== 'pending' || nowMs <= new Date(task.dueAt).getTime()) {
    return {
      allowed: false,
      reason: 'not_overdue',
      pokesUsed: 0,
      maxPokes,
      cooldownRemainingMs: 0,
    };
  }

  if (recipient.muteShadeNotifications) {
    return {
      allowed: false,
      reason: 'recipient_muted',
      pokesUsed: 0,
      maxPokes,
      cooldownRemainingMs: 0,
    };
  }

  const occurrencePokes = pokes
    .filter((p) => p.occurrenceId === task.occurrenceId)
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );

  if (occurrencePokes.length >= maxPokes) {
    return {
      allowed: false,
      reason: 'max_pokes_reached',
      pokesUsed: occurrencePokes.length,
      maxPokes,
      cooldownRemainingMs: 0,
    };
  }

  if (occurrencePokes.length > 0) {
    const lastPokeMs = new Date(occurrencePokes[0].createdAt).getTime();
    const elapsed = nowMs - lastPokeMs;
    if (elapsed < cooldownMs) {
      return {
        allowed: false,
        reason: 'cooldown_active',
        pokesUsed: occurrencePokes.length,
        maxPokes,
        cooldownRemainingMs: cooldownMs - elapsed,
      };
    }
  }

  return {
    allowed: true,
    pokesUsed: occurrencePokes.length,
    maxPokes,
    cooldownRemainingMs: 0,
  };
}

export function buildShadeMessage(
  intensity: ShadeIntensity,
  recipientName: string,
  taskTitle: string,
  locale: string = 'en-US',
  variantSeed = 0
): string {
  const isPt = locale === 'pt-BR';
  if (isPt) {
    const pool: Record<ShadeIntensity, string[]> = {
      soft_serve: [
        `${recipientName}, meu bem, "${taskTitle}" está esperando o momento de brilhar.`,
        `Oi ${recipientName} ✨ Só um lembrete carinhoso: "${taskTitle}" ainda te espera.`,
      ],
      a_little_shady: [
        `${recipientName}, amor: "${taskTitle}" está esperando mais tempo que nota de jurado no ballroom.`,
        `Não é querendo jogar shade, ${recipientName}, mas "${taskTitle}" não vai se fazer sozinha.`,
      ],
      full_ballroom: [
        `A categoria é: RESPONSABILIDADE REALNESS. E ${recipientName}, "${taskTitle}" não está dando nota 10.`,
        `${recipientName}, queride! O prazo saiu da sala e "${taskTitle}" está pedindo um bis dramático.`,
      ],
    };
    const options = pool[intensity];
    return options[Math.abs(variantSeed) % options.length];
  }

  const pool: Record<ShadeIntensity, string[]> = {
    soft_serve: [
      `${recipientName}, sweetie, "${taskTitle}" is waiting for its moment.`,
      `Gentle reminder, ${recipientName}: "${taskTitle}" is ready for your magic touch.`,
    ],
    a_little_shady: [
      `${recipientName}, darling — "${taskTitle}" has been waiting longer than a ballroom judge's score.`,
      `${recipientName}, "${taskTitle}" isn't going to handle itself, gorgeous.`,
    ],
    full_ballroom: [
      `Category is: RESPONSIBILITY REALNESS. And ${recipientName}, "${taskTitle}" is not giving tens.`,
      `Baby, the deadline has left the building! ${recipientName}, "${taskTitle}" needs a comeback performance.`,
    ],
  };
  const options = pool[intensity];
  return options[Math.abs(variantSeed) % options.length];
}

export function evaluateResidentAchievements(
  resident: Resident,
  state: Pick<HouseholdState, 'tasks' | 'pointLedger' | 'pokes' | 'residents'>
): AchievementBadge[] {
  const myTransactions = state.pointLedger.filter(
    (tx) => tx.residentId === resident.id && tx.type === 'completion'
  );
  const completedTotal = myTransactions.length;
  const cleaningDone = state.tasks
    .filter((t) => t.category === 'Limpeza')
    .reduce(
      (sum, t) =>
        sum + t.history.filter((h) => h.completedById === resident.id).length,
      0
    );
  const kitchenDone = state.tasks
    .filter((t) => t.category === 'Cozinha')
    .reduce(
      (sum, t) =>
        sum + t.history.filter((h) => h.completedById === resident.id).length,
      0
    );
  const overdueCleared = myTransactions.filter((tx) => tx.wasOverdue).length;
  const onTimeCount = myTransactions.filter(
    (tx) => !tx.wasOverdue || tx.penaltyDeducted === 0
  ).length;
  const zeroPenaltyStreak =
    onTimeCount >= 5 &&
    myTransactions.slice(0, 5).every((tx) => tx.penaltyDeducted === 0);

  const pokedOccurrencesToMe = new Set(
    state.pokes
      .filter((p) => p.toResidentId === resident.id)
      .map((p) => p.occurrenceId)
  );
  const redeemedAfterPoke = myTransactions.filter((tx) =>
    pokedOccurrencesToMe.has(tx.occurrenceId)
  ).length;

  const currentWeek = getISOWeekKey();
  const weeklyPoints = state.pointLedger
    .filter((tx) => tx.residentId === resident.id && tx.weekKey === currentWeek)
    .reduce((sum, tx) => sum + tx.pointsDelta, 0);

  const topWeeklyResident = [...state.residents]
    .map((r) => ({
      id: r.id,
      pts: state.pointLedger
        .filter((tx) => tx.residentId === r.id && tx.weekKey === currentWeek)
        .reduce((sum, tx) => sum + tx.pointsDelta, 0),
    }))
    .sort((a, b) => b.pts - a.pts)[0];

  const isCurrentLeader =
    Boolean(topWeeklyResident) &&
    topWeeklyResident.id === resident.id &&
    topWeeklyResident.pts > 0;

  return [
    {
      id: 'ach-cleanliness-realness',
      titleKey: 'achievements.cleanlinessRealness.title',
      descKey: 'achievements.cleanlinessRealness.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: completedTotal >= 1,
      progressCurrent: Math.min(completedTotal, 1),
      progressTarget: 1,
      iconKey: 'mop',
    },
    {
      id: 'ach-mother-of-mop',
      titleKey: 'achievements.motherOfMop.title',
      descKey: 'achievements.motherOfMop.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: cleaningDone >= 3,
      progressCurrent: Math.min(cleaningDone, 3),
      progressTarget: 3,
      iconKey: 'crown',
    },
    {
      id: 'ach-kitchen-royalty',
      titleKey: 'achievements.kitchenRoyalty.title',
      descKey: 'achievements.kitchenRoyalty.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: kitchenDone >= 3,
      progressCurrent: Math.min(kitchenDone, 3),
      progressTarget: 3,
      iconKey: 'kitchen',
    },
    {
      id: 'ach-dust-exorcist',
      titleKey: 'achievements.dustExorcist.title',
      descKey: 'achievements.dustExorcist.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: overdueCleared >= 1,
      progressCurrent: Math.min(overdueCleared, 1),
      progressTarget: 1,
      iconKey: 'exorcist',
    },
    {
      id: 'ach-dish-diva',
      titleKey: 'achievements.dishDiva.title',
      descKey: 'achievements.dishDiva.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: resident.streak >= 3,
      progressCurrent: Math.min(resident.streak, 3),
      progressTarget: 3,
      iconKey: 'diva',
    },
    {
      id: 'ach-untouchable',
      titleKey: 'achievements.untouchable.title',
      descKey: 'achievements.untouchable.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: zeroPenaltyStreak,
      progressCurrent: Math.min(onTimeCount, 5),
      progressTarget: 5,
      iconKey: 'untouchable',
    },
    {
      id: 'ach-redemption-arc',
      titleKey: 'achievements.redemptionArc.title',
      descKey: 'achievements.redemptionArc.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: redeemedAfterPoke >= 1,
      progressCurrent: Math.min(redeemedAfterPoke, 1),
      progressTarget: 1,
      iconKey: 'redemption',
    },
    {
      id: 'ach-comeback-queen',
      titleKey: 'achievements.comebackQueen.title',
      descKey: 'achievements.comebackQueen.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: redeemedAfterPoke >= 1 && isCurrentLeader,
      progressCurrent: redeemedAfterPoke >= 1 && isCurrentLeader ? 1 : 0,
      progressTarget: 1,
      iconKey: 'comeback',
    },
    {
      id: 'ach-spotless',
      titleKey: 'achievements.spotless.title',
      descKey: 'achievements.spotless.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: weeklyPoints >= 100,
      progressCurrent: Math.min(weeklyPoints, 100),
      progressTarget: 100,
      iconKey: 'spotless',
    },
    {
      id: 'ach-house-icon',
      titleKey: 'achievements.houseIcon.title',
      descKey: 'achievements.houseIcon.desc',
      progressKey: 'achievements.progressFraction',
      unlocked: isCurrentLeader && completedTotal >= 2,
      progressCurrent: isCurrentLeader && completedTotal >= 2 ? 1 : 0,
      progressTarget: 1,
      iconKey: 'icon',
    },
  ];
}

export function buildWeeklyCeremonySummary(
  state: HouseholdState,
  targetWeekKey: string = getISOWeekKey()
): WeeklyCeremonySummary {
  const standings: WeeklyStandingsEntry[] = state.residents.map((resident) => {
    const txs = state.pointLedger.filter(
      (tx) => tx.residentId === resident.id && tx.weekKey === targetWeekKey
    );
    const earnedPoints = txs.reduce((sum, tx) => sum + tx.pointsDelta, 0);
    const completedCount = txs.filter((tx) => tx.type === 'completion').length;
    const overdueCount = txs.filter(
      (tx) => tx.type === 'completion' && tx.wasOverdue
    ).length;
    const onTimeCount = completedCount - overdueCount;
    const penaltyPoints = txs.reduce((sum, tx) => sum + tx.penaltyDeducted, 0);

    return {
      residentId: resident.id,
      earnedPoints,
      completedCount,
      onTimeCount,
      overdueCount,
      penaltyPoints,
    };
  });

  standings.sort((a, b) => {
    if (b.earnedPoints !== a.earnedPoints) {
      return b.earnedPoints - a.earnedPoints;
    }
    return b.onTimeCount - a.onTimeCount;
  });

  const first = standings[0];
  const second = standings[1];
  const isTie =
    Boolean(first && second) &&
    first.earnedPoints === second.earnedPoints &&
    first.earnedPoints > 0;

  return {
    weekKey: targetWeekKey,
    winnerId:
      !first || first.earnedPoints === 0 || isTie ? null : first.residentId,
    isTie,
    standings,
    totalCompleted: standings.reduce((s, e) => s + e.completedCount, 0),
    totalPenalties: standings.reduce((s, e) => s + e.penaltyPoints, 0),
  };
}
