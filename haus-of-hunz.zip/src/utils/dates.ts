export function getTodayYMD(timeZone?: string): string {
  try {
    if (timeZone) {
      const parts = new Intl.DateTimeFormat('en-CA', {
        timeZone,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
      }).formatToParts(new Date());
      const y = parts.find((p) => p.type === 'year')?.value;
      const m = parts.find((p) => p.type === 'month')?.value;
      const d = parts.find((p) => p.type === 'day')?.value;
      if (y && m && d) return `${y}-${m}-${d}`;
    }
  } catch {
    // Fallback to local date below
  }
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function addDaysYMD(ymd: string, days: number): string {
  const [y, m, d] = ymd.split('-').map(Number);
  const date = new Date(Date.UTC(y, (m || 1) - 1, d || 1));
  date.setUTCDate(date.getUTCDate() + days);
  const nextY = date.getUTCFullYear();
  const nextM = String(date.getUTCMonth() + 1).padStart(2, '0');
  const nextD = String(date.getUTCDate()).padStart(2, '0');
  return `${nextY}-${nextM}-${nextD}`;
}

export function addMonthsYMD(ymd: string, months: number): string {
  const [y, m, d] = ymd.split('-').map(Number);
  const date = new Date(Date.UTC(y, (m || 1) - 1 + months, d || 1));
  const nextY = date.getUTCFullYear();
  const nextM = String(date.getUTCMonth() + 1).padStart(2, '0');
  const nextD = String(date.getUTCDate()).padStart(2, '0');
  return `${nextY}-${nextM}-${nextD}`;
}

function getTimeZoneOffsetMs(dateUtc: Date, timeZone: string): number {
  try {
    const dtf = new Intl.DateTimeFormat('en-US', {
      timeZone,
      hour12: false,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    const parts = dtf.formatToParts(dateUtc);
    const get = (type: string) =>
      Number(parts.find((p) => p.type === type)?.value ?? '0');
    const year = get('year');
    const month = get('month');
    const day = get('day');
    const hour = get('hour') === 24 ? 0 : get('hour');
    const minute = get('minute');
    const second = get('second');
    const asUtc = Date.UTC(year, month - 1, day, hour, minute, second);
    return asUtc - dateUtc.getTime();
  } catch {
    return 0;
  }
}

/**
 * Converts a household local YYYY-MM-DD + HH:mm in a configured IANA timeZone
 * into an authoritative UTC ISO string.
 */
export function computeDueAtIso(
  dueDate: string,
  dueTime = '20:00',
  timeZone = 'America/Sao_Paulo'
): string {
  const [y, m, d] = dueDate.split('-').map(Number);
  const [hh, mm] = (dueTime || '20:00').split(':').map(Number);
  const wallUtcMs = Date.UTC(
    y || 2026,
    (m || 1) - 1,
    d || 1,
    Number.isFinite(hh) ? hh : 20,
    Number.isFinite(mm) ? mm : 0,
    0,
    0
  );
  const guess = new Date(wallUtcMs);
  const offset1 = getTimeZoneOffsetMs(guess, timeZone);
  const adjusted = new Date(wallUtcMs - offset1);
  const offset2 = getTimeZoneOffsetMs(adjusted, timeZone);
  const finalUtc = new Date(wallUtcMs - offset2);
  return finalUtc.toISOString();
}

export function getISOWeekKey(dateInput: Date | string = new Date()): string {
  const d =
    typeof dateInput === 'string' ? new Date(dateInput) : new Date(dateInput);
  const utc = new Date(
    Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())
  );
  const dayNum = utc.getUTCDay() || 7;
  utc.setUTCDate(utc.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(utc.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(
    ((utc.getTime() - yearStart.getTime()) / 86400000 + 1) / 7
  );
  return `${utc.getUTCFullYear()}-W${String(weekNo).padStart(2, '0')}`;
}

export function formatLocalizedDate(
  isoOrYmd: string,
  locale: string = 'en-US'
): string {
  if (!isoOrYmd) return '';
  const activeLocale = locale === 'pt-BR' ? 'pt-BR' : 'en-US';

  if (/^\d{4}-\d{2}-\d{2}$/.test(isoOrYmd)) {
    const [y, m, d] = isoOrYmd.split('-').map(Number);
    const localDate = new Date(y, m - 1, d);
    return new Intl.DateTimeFormat(activeLocale, {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric',
    }).format(localDate);
  }

  const date = new Date(isoOrYmd);
  if (Number.isNaN(date.getTime())) return '';
  return new Intl.DateTimeFormat(activeLocale, {
    month: '2-digit',
    day: '2-digit',
    year: 'numeric',
  }).format(date);
}

export function formatLocalizedDateTime(
  iso: string,
  locale: string = 'en-US',
  timeZone?: string
): string {
  if (!iso) return '';
  const activeLocale = locale === 'pt-BR' ? 'pt-BR' : 'en-US';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '';

  const now = new Date();
  const sameDay =
    date.getDate() === now.getDate() &&
    date.getMonth() === now.getMonth() &&
    date.getFullYear() === now.getFullYear();

  const timeStr = new Intl.DateTimeFormat(activeLocale, {
    hour: activeLocale === 'en-US' ? 'numeric' : '2-digit',
    minute: '2-digit',
    hour12: activeLocale === 'en-US',
    ...(timeZone ? { timeZone } : {}),
  }).format(date);

  if (sameDay) {
    return activeLocale === 'pt-BR' ? `Hoje, ${timeStr}` : `Today, ${timeStr}`;
  }

  const dateStr = new Intl.DateTimeFormat(activeLocale, {
    month: '2-digit',
    day: '2-digit',
    year: 'numeric',
    ...(timeZone ? { timeZone } : {}),
  }).format(date);

  return `${dateStr} · ${timeStr}`;
}

export function formatLocalizedTime24or12(
  hhmm: string,
  locale: string = 'en-US'
): string {
  const [hh, mm] = (hhmm || '20:00').split(':').map(Number);
  const d = new Date(2026, 0, 1, hh || 20, mm || 0, 0);
  const activeLocale = locale === 'pt-BR' ? 'pt-BR' : 'en-US';
  return new Intl.DateTimeFormat(activeLocale, {
    hour: activeLocale === 'en-US' ? 'numeric' : '2-digit',
    minute: '2-digit',
    hour12: activeLocale === 'en-US',
  }).format(d);
}
