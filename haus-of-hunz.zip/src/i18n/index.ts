import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { enUS } from './locales/en-US';
import { ptBR } from './locales/pt-BR';

export type SupportedLocale = 'en-US' | 'pt-BR';

const LOCALE_STORAGE_KEY = 'casaemdia_locale_v1';

export function getSavedLocale(): SupportedLocale {
  try {
    if (typeof window === 'undefined') return 'en-US';
    const raw = window.localStorage.getItem(LOCALE_STORAGE_KEY);
    if (raw === 'pt-BR' || raw === 'en-US') {
      return raw;
    }
  } catch {
    // Ignore storage read errors
  }
  return 'en-US';
}

export function applyHtmlLang(locale: SupportedLocale): void {
  if (typeof document !== 'undefined') {
    document.documentElement.lang = locale;
  }
}

const initialLocale = getSavedLocale();

i18n.use(initReactI18next).init({
  resources: {
    'en-US': { translation: enUS },
    'pt-BR': { translation: ptBR },
  },
  lng: initialLocale,
  fallbackLng: 'en-US',
  interpolation: {
    escapeValue: false,
  },
});

applyHtmlLang(initialLocale);

export function setAppLocale(locale: SupportedLocale): void {
  try {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(LOCALE_STORAGE_KEY, locale);
    }
  } catch {
    // Ignore storage errors
  }
  applyHtmlLang(locale);
  void i18n.changeLanguage(locale);
}

export default i18n;
