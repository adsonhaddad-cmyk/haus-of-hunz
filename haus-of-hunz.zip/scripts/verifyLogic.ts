import assert from 'node:assert/strict';
import i18n, { getSavedLocale } from '../src/i18n/index.ts';
import { enUS } from '../src/i18n/locales/en-US.ts';
import { ptBR } from '../src/i18n/locales/pt-BR.ts';
import { createInitialHouseholdState } from '../src/data/seedData.ts';
import {
  applyTaskCompletion,
  buildWeeklyCeremonySummary,
  calculateNextDueDate,
  checkPokeEligibility,
  DEFAULT_PENALTY_SETTINGS,
  evaluateResidentAchievements,
  evaluateTaskOverdue,
} from '../src/utils/gameEngine.ts';
import {
  computeDueAtIso,
  formatLocalizedDate,
  formatLocalizedDateTime,
  getISOWeekKey,
} from '../src/utils/dates.ts';
import { HouseholdTask, PokeRecord } from '../src/types/household.ts';

// 1. i18n Default Locale & Key Parity
assert.equal(getSavedLocale(), 'en-US');
assert.equal(i18n.language, 'en-US');

function collectKeys(obj: Record<string, unknown>, prefix = ''): string[] {
  const keys: string[] = [];
  for (const [k, v] of Object.entries(obj)) {
    const path = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      keys.push(...collectKeys(v as Record<string, unknown>, path));
    } else {
      keys.push(path);
    }
  }
  return keys.sort();
}

const enKeys = collectKeys(enUS as unknown as Record<string, unknown>);
const ptKeys = collectKeys(ptBR as unknown as Record<string, unknown>);
assert.deepEqual(
  enKeys,
  ptKeys,
  'en-US and pt-BR translation dictionaries must have identical key trees'
);

// Date & Time localization
assert.equal(formatLocalizedDate('2025-03-09', 'en-US'), '03/09/2025');
assert.equal(formatLocalizedDate('2025-03-09', 'pt-BR'), '09/03/2025');

const todayAtTwoPm = new Date();
todayAtTwoPm.setHours(14, 5, 0, 0);
const todayEn = formatLocalizedDateTime(todayAtTwoPm.toISOString(), 'en-US');
const todayPt = formatLocalizedDateTime(todayAtTwoPm.toISOString(), 'pt-BR');
assert.ok(todayEn.startsWith('Today, '));
assert.ok(/PM|AM/i.test(todayEn));
assert.ok(todayPt.startsWith('Hoje, 14:05'));

// 2. Timezone-aware dueAt & Overdue Penalty Tiers
const dueAt = computeDueAtIso('2026-11-10', '20:00', 'UTC');
assert.equal(dueAt, '2026-11-10T20:00:00.000Z');
const dueMs = new Date(dueAt).getTime();

const baseTask: HouseholdTask = {
  id: 'task-test-1',
  title: 'Deep clean kitchen',
  category: 'Cozinha',
  points: 40,
  priority: 'alta',
  frequency: 'daily',
  assignedToId: 'res-adson',
  participantIds: ['res-adson', 'res-arty'],
  dueDate: '2026-11-10',
  dueTime: '20:00',
  dueAt,
  occurrenceId: 'task-test-1::2026-11-10::1',
  occurrenceSeq: 1,
  status: 'pending',
  history: [],
  createdAt: '2026-11-09T10:00:00.000Z',
};

// Grace window (45m late -> 0% penalty)
const graceEval = evaluateTaskOverdue(
  baseTask,
  dueMs + 45 * 60000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(graceEval.isOverdue, true);
assert.equal(graceEval.isWithinGrace, true);
assert.equal(graceEval.penaltyPercent, 0);
assert.equal(graceEval.netPoints, 40);

// 2 hours late -> 10% penalty (36 pts)
const tier10Eval = evaluateTaskOverdue(
  baseTask,
  dueMs + 120 * 60000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(tier10Eval.penaltyPercent, 10);
assert.equal(tier10Eval.penaltyPoints, 4);
assert.equal(tier10Eval.netPoints, 36);

// 10 hours late -> 25% penalty (30 pts)
const tier25Eval = evaluateTaskOverdue(
  baseTask,
  dueMs + 600 * 60000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(tier25Eval.penaltyPercent, 25);
assert.equal(tier25Eval.netPoints, 30);

// 30 hours late -> 50% penalty (20 pts)
const tier50Eval = evaluateTaskOverdue(
  baseTask,
  dueMs + 30 * 3600000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(tier50Eval.penaltyPercent, 50);
assert.equal(tier50Eval.penaltyPoints, 20);
assert.equal(tier50Eval.netPoints, 20);

// 55 hours late -> 75% penalty (10 pts)
const tier75Eval = evaluateTaskOverdue(
  baseTask,
  dueMs + 55 * 3600000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(tier75Eval.penaltyPercent, 75);
assert.equal(tier75Eval.netPoints, 10);

// Reassigned before deadline fairness protection -> 0% penalty
const reassignedEval = evaluateTaskOverdue(
  { ...baseTask, reassignedBeforeDeadline: true },
  dueMs + 30 * 3600000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(reassignedEval.penaltyPercent, 0);
assert.equal(reassignedEval.netPoints, 40);

// 3. Idempotent Ledger Completion & Rotation
const seed = createInitialHouseholdState(new Date('2026-11-14T14:00:00.000Z'));
const adsonInitialPoints = seed.residents[0].points;
const res1 = applyTaskCompletion(
  baseTask,
  seed.residents,
  seed.pointLedger,
  'res-adson',
  new Date(dueMs + 30 * 3600000).toISOString(),
  'UTC',
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(res1.completed, true);
assert.equal(res1.pointsAwarded, 20);
assert.equal(res1.penaltyPoints, 20);
assert.equal(res1.updatedTask.assignedToId, 'res-arty');
assert.equal(res1.updatedTask.dueDate, '2026-11-11');
assert.equal(res1.updatedResidents[0].points, adsonInitialPoints + 20);

// Duplicate occurrence rejected cleanly
const dup = applyTaskCompletion(
  {
    ...baseTask,
    lastCompletedOccurrenceKey: res1.updatedTask.lastCompletedOccurrenceKey,
  },
  res1.updatedResidents,
  [res1.transaction!, ...seed.pointLedger],
  'res-adson',
  new Date(dueMs + 30 * 3600000 + 5000).toISOString(),
  'UTC',
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(dup.completed, false);
assert.equal(dup.reason, 'duplicate_occurrence');

// Paused chore cannot be completed
const pausedCheck = applyTaskCompletion(
  { ...baseTask, status: 'paused' },
  seed.residents,
  seed.pointLedger,
  'res-adson',
  new Date().toISOString(),
  'UTC',
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(pausedCheck.completed, false);
assert.equal(pausedCheck.reason, 'paused');

// Recurrence date helpers
assert.equal(calculateNextDueDate('2026-11-14', 'weekly'), '2026-11-21');
assert.equal(calculateNextDueDate('2026-11-14', 'biweekly'), '2026-11-28');
assert.equal(calculateNextDueDate('2026-11-14', 'monthly'), '2026-12-14');
assert.equal(calculateNextDueDate('2026-11-14', 'custom', 5), '2026-11-19');

// 4. Poke & Shade Rules (overdue-only, non-self, mute, 12h cooldown, max 2)
const adson = seed.residents[0];
const arty = seed.residents[1];

// Not overdue -> denied
const notOverduePoke = checkPokeEligibility(
  baseTask,
  arty.id,
  adson,
  [],
  dueMs - 1000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(notOverduePoke.allowed, false);
assert.equal(notOverduePoke.reason, 'not_overdue');

// Cannot poke self
const selfPoke = checkPokeEligibility(
  baseTask,
  adson.id,
  adson,
  [],
  dueMs + 3600000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(selfPoke.allowed, false);
assert.equal(selfPoke.reason, 'cannot_poke_self');

// Muted recipient
const mutedPoke = checkPokeEligibility(
  baseTask,
  arty.id,
  { ...adson, muteShadeNotifications: true },
  [],
  dueMs + 3600000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(mutedPoke.allowed, false);
assert.equal(mutedPoke.reason, 'recipient_muted');

// First valid poke
const poke1Time = dueMs + 2 * 3600000;
const firstValid = checkPokeEligibility(
  baseTask,
  arty.id,
  adson,
  [],
  poke1Time,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(firstValid.allowed, true);

const pokeRecord1: PokeRecord = {
  id: 'poke-1',
  taskId: baseTask.id,
  taskTitle: baseTask.title,
  occurrenceId: baseTask.occurrenceId,
  fromResidentId: arty.id,
  toResidentId: adson.id,
  intensity: 'a_little_shady',
  message: 'Test shade',
  deliveredViaPush: false,
  createdAt: new Date(poke1Time).toISOString(),
};

// Immediate second poke within 12h -> cooldown_active
const cooldownBlocked = checkPokeEligibility(
  baseTask,
  arty.id,
  adson,
  [pokeRecord1],
  poke1Time + 3 * 3600000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(cooldownBlocked.allowed, false);
assert.equal(cooldownBlocked.reason, 'cooldown_active');

// Second poke after 12h -> allowed
const poke2Time = poke1Time + 13 * 3600000;
const secondValid = checkPokeEligibility(
  baseTask,
  arty.id,
  adson,
  [pokeRecord1],
  poke2Time,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(secondValid.allowed, true);

// Third poke -> max_pokes_reached
const pokeRecord2: PokeRecord = {
  ...pokeRecord1,
  id: 'poke-2',
  createdAt: new Date(poke2Time).toISOString(),
};
const thirdBlocked = checkPokeEligibility(
  baseTask,
  arty.id,
  adson,
  [pokeRecord1, pokeRecord2],
  poke2Time + 24 * 3600000,
  DEFAULT_PENALTY_SETTINGS
);
assert.equal(thirdBlocked.allowed, false);
assert.equal(thirdBlocked.reason, 'max_pokes_reached');

// 5. Achievements (10 Ballroom Badges) & Weekly Ceremony Summary
const badges = evaluateResidentAchievements(adson, seed);
assert.equal(badges.length, 10);
assert.equal(badges.find((b) => b.id === 'ach-cleanliness-realness')?.unlocked, true);

const ceremony = buildWeeklyCeremonySummary(
  seed,
  getISOWeekKey(new Date('2026-11-14T14:00:00.000Z'))
);
assert.equal(ceremony.standings.length, 2);
assert.equal(ceremony.winnerId, 'res-adson');

console.log('ALL_HOUSE_OF_CHORES_LOGIC_TESTS_PASSED');
