import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function crc32(buf: Buffer): number {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c ^= buf[i];
    for (let k = 0; k < 8; k++) {
      c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
    }
  }
  return (c ^ 0xffffffff) >>> 0;
}

function pngChunk(type: string, data: Buffer): Buffer {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, 'ascii');
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePng(width: number, height: number, rgba: Uint8Array): Buffer {
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0;
    raw.set(
      rgba.subarray(y * stride, (y + 1) * stride),
      y * (stride + 1) + 1
    );
  }
  const compressed = zlib.deflateSync(raw, { level: 9 });
  return Buffer.concat([
    signature,
    pngChunk('IHDR', ihdr),
    pngChunk('IDAT', compressed),
    pngChunk('IEND', Buffer.alloc(0)),
  ]);
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function clamp(v: number, min = 0, max = 255): number {
  return Math.max(min, Math.min(max, Math.round(v)));
}

function renderIconPng(size: number, maskable: boolean): Buffer {
  const rgba = new Uint8Array(size * size * 4);
  const scale = maskable ? 0.72 : 0.92;
  const cx = size / 2;
  const cy = size / 2;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const v = y / size;
      // Dreamy lavender -> violet gradient + blush top glow
      let r = lerp(197, 76, (u * 0.45 + v * 0.55));
      let g = lerp(166, 38, (u * 0.45 + v * 0.55));
      let b = lerp(245, 154, (u * 0.45 + v * 0.55));

      // Blush highlight orb top-left
      const dGlow = Math.hypot(u - 0.25, v - 0.22);
      if (dGlow < 0.45) {
        const w = (1 - dGlow / 0.45) ** 2 * 0.42;
        r = lerp(r, 247, w);
        g = lerp(g, 213, w);
        b = lerp(b, 233, w);
      }

      // Periwinkle glow bottom-right
      const dGlow2 = Math.hypot(u - 0.82, v - 0.82);
      if (dGlow2 < 0.42) {
        const w = (1 - dGlow2 / 0.42) ** 2 * 0.28;
        r = lerp(r, 142, w);
        g = lerp(g, 168, w);
        b = lerp(b, 245, w);
      }

      // Normalized coordinates centered around (0,0) in [-1, 1] scaled for safe zone
      const nx = (x - cx) / (size * 0.5 * scale);
      const ny = (y - cy) / (size * 0.5 * scale);

      // Draw soft house silhouette in Cloud White (#FFF8FF) -> Blush (#F7D5E9)
      const inBody = nx >= -0.58 && nx <= 0.58 && ny >= -0.05 && ny <= 0.62;
      const roofTop = -0.62 + Math.abs(nx) * 0.98;
      const inRoof = Math.abs(nx) <= 0.68 && ny >= roofTop && ny <= -0.02;

      if (inBody || inRoof) {
        const houseTint = clamp((ny + 0.62) * 0.4, 0, 1);
        r = lerp(255, 248, houseTint);
        g = lerp(248, 224, houseTint);
        b = lerp(255, 244, houseTint);

        // Inner ballroom crown emblem inside the house
        const inCrownBase =
          nx >= -0.26 && nx <= 0.26 && ny >= 0.24 && ny <= 0.37;
        const crownSpike1 =
          nx >= -0.28 && nx <= -0.08 && ny >= 0.04 + Math.abs(nx + 0.18) * 1.6 && ny <= 0.26;
        const crownSpike2 =
          nx >= -0.11 && nx <= 0.11 && ny >= -0.02 + Math.abs(nx) * 1.9 && ny <= 0.26;
        const crownSpike3 =
          nx >= 0.08 && nx <= 0.28 && ny >= 0.04 + Math.abs(nx - 0.18) * 1.6 && ny <= 0.26;

        if (inCrownBase || crownSpike1 || crownSpike2 || crownSpike3) {
          r = 150;
          g = 114;
          b = 232;
        }

        // Crown jewels in Soft Pink
        const j1 = Math.hypot(nx, ny + 0.06) < 0.055;
        const j2 = Math.hypot(nx + 0.19, ny - 0.01) < 0.048;
        const j3 = Math.hypot(nx - 0.19, ny - 0.01) < 0.048;
        if (j1 || j2 || j3) {
          r = 237;
          g = 130;
          b = 190;
        }
      }

      const idx = (y * size + x) * 4;
      rgba[idx] = clamp(r);
      rgba[idx + 1] = clamp(g);
      rgba[idx + 2] = clamp(b);
      rgba[idx + 3] = 255;
    }
  }

  return encodePng(size, size, rgba);
}

const outDir = path.resolve(process.cwd(), 'public');
fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(path.join(outDir, 'apple-touch-icon.png'), renderIconPng(180, false));
fs.writeFileSync(path.join(outDir, 'pwa-192x192.png'), renderIconPng(192, false));
fs.writeFileSync(path.join(outDir, 'pwa-512x512.png'), renderIconPng(512, false));
fs.writeFileSync(path.join(outDir, 'pwa-maskable-512x512.png'), renderIconPng(512, true));
console.log('PWA_ICONS_GENERATED');
